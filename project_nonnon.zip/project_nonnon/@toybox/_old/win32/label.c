// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : static control is not suit for subclassing
//
//	if not SS_OWNERDRAW : default window procedure intercepts almost operation
//	SS_OWNERDRAW        : WM_SETTEXT is sent after WM_LBUTTONUP


// [Mechanism]
//
//	tab('\t') based layout like status bar control
//
//	""     :   left align
//	"\t"   : center align
//	"\t\t" :  right align
//
//	vertical alignment is always center like SS_CENTERIMAGE




#ifndef _H_NONNON_WIN32_WIN_SUBCLASS_LABEL
#define _H_NONNON_WIN32_WIN_SUBCLASS_LABEL




void
n_win_subclass_label_draw( HWND hgui )
{

	HDC hdc = GetDC( hgui );


	RECT rc;        GetClientRect( hgui, &rc );
	s32  x,y,sx,sy; n_win_rect_expand_size( &rc, &x, &y, &sx, &sy );


	// Double-Buffered Rendering : Begin

	HDC     hdc_old    = hdc;
	HDC     hdc_compat = CreateCompatibleDC( hdc );
	HBITMAP hbmp       = CreateCompatibleBitmap( hdc, sx, sy );
	HBITMAP hbmp_old   = SelectObject( hdc_compat, hbmp );

	SelectObject( hdc_compat, n_win_font_get( hgui ) );

	hdc = hdc_compat;


	// Erase Background

	n_win_clear( hwnd, hdc, &rc, COLOR_BTNFACE ); // COLOR_BTNSHADOW


	// Draw

	const bool enabled = IsWindowEnabled( hgui );

	{

		int          len = n_win_text_len( hgui ) + 1;
		n_posix_char  *s = n_string_new_fast( len );

		n_win_text_get( hgui, s, len - 1 );


		n_posix_char *s_alias = s;

		int dt = ( DT_SINGLELINE | DT_VCENTER );

		if ( s[ 0 ] == N_STRING_CHAR_TAB )
		{

			if ( ( len >= 2 )&&( s[ 1 ] == N_STRING_CHAR_TAB ) )
			{
				dt |= DT_RIGHT;
				s_alias = &s[ 2 ];
			} else {
				dt |= DT_CENTER;
			}	s_alias = &s[ 1 ];

		} else {

			dt |= DT_LEFT;

		}


		SetBkMode( hdc, TRANSPARENT );

		if ( enabled )
		{

			SetTextColor( hdc, GetSysColor( COLOR_BTNTEXT ) );
			DrawText( hdc, s_alias,-1, &rc, dt );

		} else {

			RECT r_f = { x+1,y+1,x+sx+1,y+sy+1 };
			SetTextColor( hdc, GetSysColor( COLOR_BTNHILIGHT ) );
			DrawText( hdc, s_alias,-1, &r_f, dt );

			RECT r_t = { x,y,x+sx,y+sy };
			SetTextColor( hdc, GetSysColor( COLOR_BTNSHADOW ) );
			DrawText( hdc, s_alias,-1, &r_t, dt );

		}


		n_memory_free( s );

	}


	// Double-Buffered Rendering : End

	BitBlt( hdc_old, 0,0,sx,sy, hdc, 0,0, SRCCOPY );

	SelectObject( hdc_compat, hbmp_old );
	DeleteObject( hbmp );
	DeleteDC( hdc_compat );


	ReleaseDC( hgui, hdc );


	return;
}

// internal

static WNDPROC n_win_subclass_label_pfunc = NULL;

LRESULT CALLBACK
n_win_subclass_label( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
n_win_hwndprintf_literal( GetParent( hwnd ), "%d", msg );

	const WNDPROC pfunc = n_win_subclass_label_pfunc;


	switch( msg ) {


	case WM_ERASEBKGND :

		return true;

	break;

	case WM_PAINT   :
	case WM_NCPAINT :
	case WM_SETTEXT :
	case WM_SETFONT :

		// [!] : SS_OWNERDRAW : WM_NCPAINT is only sent

		n_win_subclass_label_draw( hwnd );

		n_win_message_remove();

		return 0;

	break;


	} // switch



	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
}

void
n_win_subclass_label_init( HWND hgui, const n_posix_char *classname )
{

	if ( false == n_string_is_same_literal( "STATIC", classname ) ) { return; }


	n_win_subclass_label_pfunc = n_win_gui_subclass_set( hgui, n_win_subclass_label );


	return;
}


#endif // _H_NONNON_WIN32_WIN_SUBCLASS_LABEL

