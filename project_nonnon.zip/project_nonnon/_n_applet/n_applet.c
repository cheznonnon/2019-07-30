// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"

#include "../nonnon/project/macro.c"


#include <commctrl.h>




static bool sticky;


#include "../felis/_inetcpl.c"

#include "./calendar.c"
#include "./ie.c"
#include "./ie_mousegesture.c"
#include "./popup.c"

#include "./date.c"




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	n_posix_char *cmdline = n_win_commandline_new();


	sticky = false;


	if ( n_string_is_same_literal( "-calendar", cmdline ) )
	{

		return n_win_main( NULL, n_calendar_wndproc );

	} else
	if ( false == n_string_is_empty( cmdline ) )
	{

		sticky = true;

	}


	n_string_path_free( cmdline );


	return n_win_main( NULL, n_applet_date_wndproc );
}

