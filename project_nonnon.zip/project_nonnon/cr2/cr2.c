// CAR-RACE 2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
//#include "../nonnon/game/click.c"
#include "../nonnon/game/hmidiout.c"
#include "../nonnon/game/input.c"
//#include "../nonnon/game/map.c"
//#include "../nonnon/game/map_chara.c"
//#include "../nonnon/game/pmr.c"
//#include "../nonnon/game/progressbar.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"
//#include "../nonnon/game/transition.c"

#include "../nonnon/neutral/wav/all.c"




#define N_CR2_CHARA_MAX  ( 4 )
#define N_CR2_BULLET_MAX ( 8 )

#define N_CR2_CRASH_OFF  ( 0 )
#define N_CR2_CRASH_ON   ( 1 )


#define N_CR2_EVENT_U    ( 100 )
#define N_CR2_EVENT_D    ( 102 )
#define N_CR2_EVENT_L    ( 103 )
#define N_CR2_EVENT_R    ( 101 )
#define N_CR2_EVENT_UL   ( 104 )
#define N_CR2_EVENT_UR   ( 105 )
#define N_CR2_EVENT_DL   ( 106 )
#define N_CR2_EVENT_DR   ( 107 )


#define N_CR2_VK_N       ( 0 << 0 )
#define N_CR2_VK_U       ( 1 << 0 )
#define N_CR2_VK_D       ( 1 << 1 )
#define N_CR2_VK_L       ( 1 << 2 )
#define N_CR2_VK_R       ( 1 << 3 )


#define N_CR2_CRASH_HP_1 (  1 )
#define N_CR2_CRASH_HP_2 (  3 )
#define N_CR2_CRASH_HP_3 ( 10 )




typedef struct {

	int          zoom;

	n_bmp        bmp_map;
	n_bmp        bmp_evt;
	n_bmp        bmp_blt;
	n_bmp        bmp_blt_45u;
	n_bmp        bmp_blt_45d;

	n_game_sound snd_bgm;
	n_game_sound snd_crash[ N_CR2_CHARA_MAX ];
	n_game_sound snd_hit  [ N_CR2_CHARA_MAX ];

	n_game_input input;

	s32          x,y, sx,sy;
	s32          unit;

	n_bmp        chara_bmp[ N_CR2_CHARA_MAX ];
	n_bmp        chara_45u[ N_CR2_CHARA_MAX ];
	n_bmp        chara_45d[ N_CR2_CHARA_MAX ];
	n_game_chara chara_obj[ N_CR2_CHARA_MAX ];
	int          chara_mov[ N_CR2_CHARA_MAX ];
	int          chara_hit[ N_CR2_CHARA_MAX ];
	n_game_chara chara_blt[ N_CR2_BULLET_MAX ];

	s32          throttle_step[ N_CR2_CHARA_MAX ];
	s32          throttle_rand[ N_CR2_CHARA_MAX ];
	s32          throttle_min [ N_CR2_CHARA_MAX ];
	s32          throttle_max [ N_CR2_CHARA_MAX ];

	u32          throttle_timer;
	u32          throttle_msec;

	int          revolver_index;
	u32          revolver_timer;

} n_cr2;


static n_cr2 cr2;




void
n_cr2_bmp_randomdot( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );

	s32 tx = 0;
	s32 ty = 0;
	while( 1 )
	{

		if ( 0 == n_game_random( 50 ) )
		{
			n_bmp_ptr_set_fast( bmp, tx,ty, n_bmp_white_invisible );
		}


		tx++;
		if ( tx >= sx ) 
		{

			tx = 0;

			ty++;
			if ( ty >= sy ) { break; }
		}

	}


	return;
}




bool
n_cr2_chara_is_hit( const n_game_chara *a, const n_game_chara *b )
{

	bool ret = false;

	s32 bmpsx = N_BMP_SX( a->chara );
	s32 bmpsy = N_BMP_SY( a->chara );

	s32 sx = abs( a->x - b->x );
	s32 sy = abs( a->y - b->y );

	if ( bmpsx <= sx ) { return ret; }
	if ( bmpsy <= sy ) { return ret; }

	if ( ( sx == 0 )&&( sy == 0 ) ) { return true; }


	n_bmp *bmp_a, *bmp_b;
	if ( a->x < b->x )
	{
		bmp_a = a->chara;
		bmp_b = b->chara;
	} else {
		bmp_a = b->chara;
		bmp_b = a->chara;
	}


	s32 x = sx;
	s32 y = sy;
	while( 1 )
	{

		s32 ax,ay, bx,by;
		if ( a->x < b->x ) { ax = x; bx = x - sx; } else { ax = x - sx; bx = x; }
		if ( a->y < b->y ) { ay = y; by = y - sy; } else { ay = y - sy; by = y; }

		u32 clr_a = n_bmp_black; n_bmp_ptr_get( bmp_a, ax,ay, &clr_a );
		u32 clr_b = n_bmp_black; n_bmp_ptr_get( bmp_b, bx,by, &clr_b );

		if ( ( clr_a != n_bmp_black )&&( clr_b != n_bmp_black ) )
		{
			ret = true;
			break;
		}

		x++;
		if ( x >= ( bmpsx - sx ) )
		{
			x = sx;
			y++;
			if ( y >= ( bmpsy - sy ) ) { ret = false; break; }
		}
	}


	return ret;
}




#define n_cr2_midi_note_on(  ch, snd, note ) n_cr2_midi_note( ch, snd, note,  true )
#define n_cr2_midi_note_off( ch, snd, note ) n_cr2_midi_note( ch, snd, note, false )

void
n_cr2_midi_note( int channel, int sound, int note, bool is_on )
{

	int ch = 0;
	while( 1 )
	{

		int vol = 0;
		if ( is_on ) { vol = N_HMIDIOUT_VOLUME_MAX; }

		n_hmidiout_all( channel, sound, N_HMIDIOUT_PANPOT_CENTER, note, vol );

		ch++;
		if ( ch >= 4 ) { break; }
	}


	return;
}

#define N_CR2_SOUND_BULLET_NUMBER ( 127 )
#define N_CR2_SOUND_BULLET_PITCH  (  60 )

#define n_cr2_midi_bullet_on(  ch ) n_cr2_midi_note_on(  ch, N_CR2_SOUND_BULLET_NUMBER, N_CR2_SOUND_BULLET_PITCH )
#define n_cr2_midi_bullet_off( ch ) n_cr2_midi_note_off( ch, N_CR2_SOUND_BULLET_NUMBER, N_CR2_SOUND_BULLET_PITCH )




void
n_cr2_position_init( n_cr2 *p, int obj_number )
{

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		u32 color; n_bmp_ptr_get_fast( &p->bmp_evt, x,y, &color );
		if ( 255 == n_bmp_b( color ) )
		{
			if ( obj_number == n_bmp_r( color ) )
			{

				if ( obj_number == 0 )
				{

					p->x = x + ( p->unit / 2 ) - ( game.sx / 2 );
					p->y = y + ( p->unit / 2 ) - ( game.sy / 2 );

					s32 center_x = n_game_centering( game.sx, N_BMP_SX( &p->chara_bmp[ obj_number ] ) );
					s32 center_y = n_game_centering( game.sy, N_BMP_SY( &p->chara_bmp[ obj_number ] ) );

					n_game_chara_pos( &p->chara_obj[ obj_number ], center_x,center_y );

				} else {

					n_game_chara_pos( &p->chara_obj[ obj_number ], x,y );

				}

				break;
			}
		}

		x++;
		if ( x >= p->sx )
		{
			x = 0;

			y++;
			if ( y >= p->sy ) { break; }
		}
	}

	return;
}

#define n_cr2_vibrate_off( p ) n_cr2_vibrate( p, false )
#define n_cr2_vibrate_on(  p ) n_cr2_vibrate( p,  true )

void
n_cr2_vibrate( n_cr2 *p, bool is_on )
{

	int n,v;
	if ( is_on )
	{
		n = p->unit / 8;
		v = N_GAME_INPUT_XINPUT_VIBRATE_MAX;
		n_game_input_XInput_vibrate( &p->input, v, v );
	} else {
		n = v = 0;
		n_game_input_XInput_vibrate( &p->input, v, v );
	}

	n_game_screenshaker( n );


	return;
}

bool
n_cr2_offroad_color( n_cr2 *p, u32 color )
{

	bool ret = false;


	if ( 150 == n_bmp_g( color ) )
	{
		ret = true;
	}


	return ret;
}

bool
n_cr2_offroad( n_cr2 *p, int o )
{

	bool ret = false;


	s32 x,y;

	if ( o == 0 )
	{
		x = p->x + ( game.sx / 2 );
		y = p->y + ( game.sy / 2 );
	} else {
		x = p->chara_obj[ o ].x + ( p->unit / 2 );
		y = p->chara_obj[ o ].y + ( p->unit / 2 );
	}


	u32 color; n_bmp_ptr_get( &p->bmp_evt, x,y, &color );

	if ( n_cr2_offroad_color( p, color ) )
	{
		ret = true;
		p->throttle_step[ o ] = p->throttle_min[ o ];
		if ( o == 0 ) { n_cr2_vibrate_on ( p ); }
	} else {
		if ( o == 0 ) { n_cr2_vibrate_off( p ); }
	}


	return ret;
}

void
n_cr2_crash_effect( n_cr2 *p, s32 x, s32 y )
{

	s32 rr = n_game_random( (double) p->unit * 0.66 );
	if ( rr <= 0 ) { rr = 1; }

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, rr,rr ); n_bmp_flush( &bmp, n_bmp_white_invisible );

	s32 half_unit = p->unit / 2;

	s32 xx = x + half_unit - n_game_random( half_unit );
	s32 yy = y + half_unit - n_game_random(half_unit );

	u32 color_f = n_bmp_argb( 255, 10, 10, 10 );
	u32 color_t = n_bmp_argb( 128,200,  0,  0 );

	n_bmp_flush_gradient( &bmp, color_f, color_t, N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING );
	n_cr2_bmp_randomdot( &bmp );
	n_bmp_cornermask( &bmp, rr, 0, n_bmp_white_invisible );

	n_bmp_blendcopy( &bmp, &game.bmp, 0,0,rr,rr, xx,yy, (double) n_game_random( 100 ) * 0.01 );

	n_bmp_free( &bmp );


	return;
}

bool
n_cr2_crash_wall( n_cr2 *p, int i )
{

	bool ret = false;

	if ( p->chara_obj[ i ].data == N_CR2_CRASH_OFF )
	{

		s32 x,y;
		if ( i == 0 )
		{
			x = p->x + ( game.sx / 2 );
			y = p->y + ( game.sy / 2 );
		} else {
			x = p->chara_obj[ i ].x;
			y = p->chara_obj[ i ].y;
		}

		u32 color; n_bmp_ptr_get( &p->bmp_evt, x,y, &color );
		if ( color == n_bmp_rgb( 100, 100, 100 ) )
		{

			p->chara_obj[ i ].data = N_CR2_CRASH_ON;
			n_game_sound_loop( &p->snd_crash[ i ] );
			ret = true;

			if ( i == 1 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_1; } else
			if ( i == 2 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_2; } else
			if ( i == 3 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_3; }// else

		}

	}


	return ret;
}

bool
n_cr2_crash_rivals( n_cr2 *p, int i )
{

	bool ret = false;


	int o = 0;
	while( 1 )
	{

		if ( i != o )
		{

			n_game_chara *f = &p->chara_obj[ o ];
			n_game_chara *t = &p->chara_obj[ i ];

			if ( ( o == 0 )||( i == 0 ) )
			{
				t->x -= p->x;
				t->y -= p->y;
			}

			if ( n_cr2_chara_is_hit( f, t ) )
			{

				if ( p->chara_obj[ o ].data == N_CR2_CRASH_OFF )
				{
					n_game_sound_loop( &p->snd_crash[ o ] );

					if ( o == 1 ) { p->chara_hit[ o ] = N_CR2_CRASH_HP_1; } else
					if ( o == 2 ) { p->chara_hit[ o ] = N_CR2_CRASH_HP_2; } else
					if ( o == 3 ) { p->chara_hit[ o ] = N_CR2_CRASH_HP_3; }// else
				}

				if ( p->chara_obj[ i ].data == N_CR2_CRASH_OFF )
				{
					n_game_sound_loop( &p->snd_crash[ i ] );

					if ( i == 1 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_1; } else
					if ( i == 2 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_2; } else
					if ( i == 3 ) { p->chara_hit[ i ] = N_CR2_CRASH_HP_3; }// else
				}

				p->chara_obj[ o ].data = N_CR2_CRASH_ON;
				p->chara_obj[ i ].data = N_CR2_CRASH_ON;

				ret = true;

			}

			if ( ( o == 0 )||( i == 0 ) )
			{
				t->x += p->x;
				t->y += p->y;
			}

		}

		o++;
		if ( o >= N_CR2_CHARA_MAX ) { break; }
	}


	return ret;
}

bool
n_cr2_crash_bullet( n_cr2 *p, int i )
{

	bool ret = false;

	if ( i == 0 ) { return ret; }


	int j = 0;
	while( 1 )
	{

		if ( p->chara_blt[ j ].data != N_CR2_VK_N )
		{

			n_game_chara *f = &p->chara_blt[ j ];
			n_game_chara *t = &p->chara_obj[ i ];

//n_game_hwndprintf_literal( " %d %d %d %d ", f->x, f->y, t->x, t->y );

			u32 color; n_bmp_ptr_get( &p->bmp_evt, f->x,f->y, &color );
			if ( color == n_bmp_rgb( 100, 100, 100 ) )
			{
				p->chara_blt[ j ].data = N_CR2_VK_N;
				n_game_sound_loop( &p->snd_hit[ i ] );
			}

			if ( n_cr2_chara_is_hit( f, t ) )
			{

				p->chara_blt[ j ].data = N_CR2_VK_N;

				p->chara_hit[ i ]++;

				if ( i == 1 )
				{

					if ( p->chara_hit[ i ] >= N_CR2_CRASH_HP_1 )
					{
//n_game_hwndprintf_literal( " %d ", p->chara_hit[ i ] );

						p->chara_obj[ i ].data = N_CR2_CRASH_ON;
						n_game_sound_loop( &p->snd_crash[ i ] );
					}

				} else
				if ( i == 2 )
				{

					if ( p->chara_hit[ i ] >= N_CR2_CRASH_HP_2 )
					{
//n_game_hwndprintf_literal( " %d ", p->chara_hit[ i ] );

						p->chara_obj[ i ].data = N_CR2_CRASH_ON;
						n_game_sound_loop( &p->snd_crash[ i ] );
					} else {
						n_game_sound_loop( &p->snd_hit  [ i ] );
					}

				} else
				if ( i == 3 )
				{

					if ( p->chara_hit[ i ] >= N_CR2_CRASH_HP_3 )
					{
//n_game_hwndprintf_literal( " %d ", p->chara_hit[ i ] );

						p->chara_obj[ i ].data = N_CR2_CRASH_ON;
						n_game_sound_loop( &p->snd_crash[ i ] );
					} else {
						n_game_sound_loop( &p->snd_hit  [ i ] );
					}

				}// else

			} // if ( n_cr2_chara_is_hit( f, t ) )

		} // if ( p->chara_blt[ j ].data == N_CR2_VK_N )

		j++;
		if ( j >= N_CR2_BULLET_MAX ) { break; }
	}


	return ret;
}

bool
n_cr2_crash( n_cr2 *p )
{

	bool ret = false;


	int i = 0;
	while( 1 )
	{

		// With Wall

		ret |= n_cr2_crash_wall( p, i );


		// With Rivals

		ret |= n_cr2_crash_rivals( p, i );


		// With Rivals : Bullet (Gunfire)

		ret |= n_cr2_crash_bullet( p, i );


		i++;
		if ( i >= N_CR2_CHARA_MAX ) { break; }
	}


	return ret;
}

void
n_cr2_draw_single( n_cr2 *p, n_game_chara *c, int index, int direction, bool is_car )
{

	int mirror = 0;
	int rotate = 0;

	if ( ( direction & N_CR2_VK_U )&&( direction & N_CR2_VK_L ) )
	{
		if ( is_car )
		{
			c->chara = &p->chara_45u[ index ];
		} else {
			c->chara = &p->bmp_blt_45u;
		}

		mirror = N_BMP_COPY_MIRROR_NONE;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else
	if ( ( direction & N_CR2_VK_U )&&( direction & N_CR2_VK_R ) )
	{
		if ( is_car )
		{
			c->chara = &p->chara_45u[ index ];
		} else {
			c->chara = &p->bmp_blt_45u;
		}

		mirror = N_BMP_COPY_MIRROR_LEFTSIDE_RIGHT;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else
	if ( ( direction & N_CR2_VK_D )&&( direction & N_CR2_VK_L ) )
	{
		if ( is_car )
		{
			c->chara = &p->chara_45d[ index ];
		} else {
			c->chara = &p->bmp_blt_45d;
		}

		mirror = N_BMP_COPY_MIRROR_NONE;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else
	if ( ( direction & N_CR2_VK_D )&&( direction & N_CR2_VK_R ) )
	{
		if ( is_car )
		{
			c->chara = &p->chara_45d[ index ];
		} else {
			c->chara = &p->bmp_blt_45d;
		}

		mirror = N_BMP_COPY_MIRROR_LEFTSIDE_RIGHT;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else

	if ( direction & N_CR2_VK_U )
	{
		if ( is_car )
		{
			c->chara = &p->chara_bmp[ index ];
		} else {
			c->chara = &p->bmp_blt;
		}

		mirror = N_BMP_COPY_MIRROR_NONE;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else
	if ( direction & N_CR2_VK_D )
	{
		if ( is_car )
		{
			c->chara = &p->chara_bmp[ index ];
		} else {
			c->chara = &p->bmp_blt;
		}

		mirror = N_BMP_COPY_MIRROR_ROTATE180;
		rotate = N_BMP_COPY_ROTATE_NONE;
	} else
	if ( direction & N_CR2_VK_L )
	{
		if ( is_car )
		{
			c->chara = &p->chara_bmp[ index ];
		} else {
			c->chara = &p->bmp_blt;
		}

		mirror = N_BMP_COPY_MIRROR_NONE;
		rotate = N_BMP_COPY_ROTATE_LEFT;
	} else
	if ( direction & N_CR2_VK_R )
	{
		if ( is_car )
		{
			c->chara = &p->chara_bmp[ index ];
		} else {
			c->chara = &p->bmp_blt;
		}

		mirror = N_BMP_COPY_MIRROR_NONE;
		rotate = N_BMP_COPY_ROTATE_RIGHT;
	}

	n_game_chara_draw_full( c, 0, mirror, rotate, 0 );


	return;
}

void
n_cr2_draw( n_cr2 *p )
{

	n_bmp_fastcopy( &p->bmp_map, &game.bmp, p->x,p->y,game.sx,game.sy, 0,0 );

	int i = 0;
	while( 1 )
	{

		if ( i != 0 )
		{
			p->chara_obj[ i ].x -= p->x;
			p->chara_obj[ i ].y -= p->y;
		}

		n_cr2_draw_single( p, &p->chara_obj[ i ], i, p->chara_mov[ i ], true );

		if ( i != 0 )
		{
			p->chara_obj[ i ].x += p->x;
			p->chara_obj[ i ].y += p->y;
		}

		i++;
		if ( i >= N_CR2_CHARA_MAX ) { break; }
	}


	int j = 0;
	while( 1 )
	{

		if ( p->chara_blt[ j ].data != N_CR2_VK_N )
		{
			p->chara_blt[ j ].x -= p->x;
			p->chara_blt[ j ].y -= p->y;

			n_cr2_draw_single( p, &p->chara_blt[ j ], j, p->chara_blt[ j ].data, false );

			p->chara_blt[ j ].x += p->x;
			p->chara_blt[ j ].y += p->y;
		}

		j++;
		if ( j >= N_CR2_BULLET_MAX ) { break; }
	}


	return;
}

void
n_cr2_crash_draw( n_cr2 *p )
{

	int i = 0;
	while( 1 )
	{

		if ( p->chara_obj[ i ].data == N_CR2_CRASH_ON )
		{

			s32 x = p->chara_obj[ i ].x;
			s32 y = p->chara_obj[ i ].y;

			if ( i != 0 )
			{
				x -= p->x;
				y -= p->y;
			}

			int j = 0;
			while( 1 )
			{
				n_cr2_crash_effect( p, x,y );
				j++;
				if ( j >= 50 ) { break; }
			}

		}

		i++;
		if ( i >= N_CR2_CHARA_MAX ) { break; }
	}


	return;
}

void
n_cr2_reset( n_cr2 *p )
{

	p->throttle_timer = n_posix_tickcount();
	p->throttle_msec  = 100;


	int i = 0;
	while( 1 )
	{

		n_cr2_position_init( p, i );

		p->chara_obj[ i ].data = N_CR2_CRASH_OFF;
		p->chara_mov[ i ]      = N_CR2_VK_U;
		p->chara_hit[ i ]      = 0;

		n_game_chara_prv( &p->chara_obj[ i ] );


		i++;
		if ( i >= N_CR2_CHARA_MAX ) { break; }
	}


	p->throttle_step[ 0 ] =  4 * p->zoom;
	p->throttle_rand[ 0 ] =  4 * p->zoom;
	p->throttle_min [ 0 ] =  2 * p->zoom;
	p->throttle_max [ 0 ] = 12 * p->zoom;

	p->throttle_step[ 1 ] =  4 * p->zoom;
	p->throttle_rand[ 1 ] =  4 * p->zoom;
	p->throttle_min [ 1 ] =  4 * p->zoom;
	p->throttle_max [ 1 ] =  4 * p->zoom;

	p->throttle_step[ 2 ] =  6 * p->zoom;
	p->throttle_rand[ 2 ] =  6 * p->zoom;
	p->throttle_min [ 2 ] =  6 * p->zoom;
	p->throttle_max [ 2 ] =  6 * p->zoom;

	p->throttle_step[ 3 ] =  8 * p->zoom;
	p->throttle_rand[ 3 ] =  8 * p->zoom;
	p->throttle_min [ 3 ] =  8 * p->zoom;
	p->throttle_max [ 3 ] =  8 * p->zoom;


	int j = 0;
	while( 1 )
	{

		p->chara_blt[ j ].data = N_CR2_VK_N;

		j++;
		if ( j >= N_CR2_BULLET_MAX ) { break; }
	}

	return;
}

bool
n_cr2_npc_input( n_cr2 *p, int o )
{

	n_game_chara *c = &p->chara_obj[ o ];


	int instable = 0;
	if ( o == 1 )
	{
		instable = n_game_random( p->throttle_rand[ o ] ) - ( p->throttle_rand[ o ] / 2 );
	} else
	if ( o == 2 )
	{
		int rand = p->throttle_rand[ o ] / 2;
		instable = n_game_random( rand ) - ( rand / 2 );
	} else
	if ( o == 3 )
	{
		instable = 0;
	}


	// Offroad

	if ( n_cr2_offroad( p, o ) )
	{
		instable = p->zoom;
	}


	bool redraw = false;

	if ( p->chara_mov[ o ] & N_CR2_VK_U )
	{
		redraw = true;

		c->x += instable;
		c->y -= ( p->throttle_step[ o ] + n_game_random( p->throttle_rand[ o ] ) );
	}

	if ( p->chara_mov[ o ] & N_CR2_VK_D )
	{
		redraw = true;

		c->x += instable;
		c->y += ( p->throttle_step[ o ] + n_game_random( p->throttle_rand[ o ] ) );
	}

	if ( p->chara_mov[ o ] & N_CR2_VK_L )
	{
		redraw = true;

		c->x -= ( p->throttle_step[ o ] + n_game_random( p->throttle_rand[ o ] ) );
		c->y += instable;
	}

	if ( p->chara_mov[ o ] & N_CR2_VK_R )
	{
		redraw = true;

		c->x += ( p->throttle_step[ o ] + n_game_random( p->throttle_rand[ o ] ) );
		c->y += instable;
	}


	if ( redraw )
	{

		u32 color; n_bmp_ptr_get( &p->bmp_evt, c->x, c->y, &color );

		int event = n_bmp_r( color );

		if ( 255 == n_bmp_g( color ) )
		{
			if ( 0 == n_game_random( 5 ) )
			{
				if ( event == N_CR2_EVENT_L ) { p->chara_mov[ o ] = N_CR2_VK_L; }
			}
		} else {
			if ( event == N_CR2_EVENT_U  ) { p->chara_mov[ o ] = N_CR2_VK_U;              }
			if ( event == N_CR2_EVENT_D  ) { p->chara_mov[ o ] = N_CR2_VK_D;              }
			if ( event == N_CR2_EVENT_L  ) { p->chara_mov[ o ] = N_CR2_VK_L;              }
			if ( event == N_CR2_EVENT_R  ) { p->chara_mov[ o ] = N_CR2_VK_R;              }
			if ( event == N_CR2_EVENT_UL ) { p->chara_mov[ o ] = N_CR2_VK_U | N_CR2_VK_L; }
			if ( event == N_CR2_EVENT_UR ) { p->chara_mov[ o ] = N_CR2_VK_U | N_CR2_VK_R; }
			if ( event == N_CR2_EVENT_DL ) { p->chara_mov[ o ] = N_CR2_VK_D | N_CR2_VK_L; }
			if ( event == N_CR2_EVENT_DR ) { p->chara_mov[ o ] = N_CR2_VK_D | N_CR2_VK_R; }
		}

	}


	return redraw;
}




#define n_cr2_zero( p ) n_memory_zero( p, sizeof( n_cr2 ) )

void
n_cr2_init( n_cr2 *p ) 
{

	// Global

	n_bmp_safemode = false;


	// Zoom

	s32 desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	p->zoom = n_posix_max_s32( 1, desktop_sx / 512 / 2 );


	// Debug

	//p->zoom = 1;
	//int zoom_debug = 3;

	int zoom_debug = 1;


	// System

	n_game_title_literal( "CAR-RACE 2" );

	game.sx    = 320 * p->zoom * zoom_debug;
	game.sy    = 240 * p->zoom * zoom_debug;
	game.fps   = 30;
	game.color = n_bmp_white;

	n_game_dwm_onoff();

	n_game_window_fixed();

	if ( IsZoomed( game.hwnd ) ) { ShowWindow( game.hwnd, SW_RESTORE ); }


	n_hmidiout_init();


	// Resources

//u32 tick = n_posix_tickcount();

	n_game_rc_load_bmp_literal( &p->bmp_map, "CR2_BMP_MAP" );
	n_game_rc_load_bmp_literal( &p->bmp_evt, "CR2_BMP_EVT" );

	n_bmp_scaler_big( &p->bmp_map, 10 * p->zoom );
	n_bmp_scaler_big( &p->bmp_evt, 10 * p->zoom );

	s32 margin = n_posix_max_s32( game.sx, game.sy ) * 2;

	p->sx = N_BMP_SX( &p->bmp_map );
	p->sy = N_BMP_SY( &p->bmp_map );

	u32 color_bg = n_bmp_rgb( 0, 150, 100 );
	n_bmp_resizer( &p->bmp_map, p->sx + margin, p->sy + margin, color_bg, N_BMP_RESIZER_CENTER );
	n_bmp_resizer( &p->bmp_evt, p->sx + margin, p->sy + margin, color_bg, N_BMP_RESIZER_CENTER );

	p->sx = N_BMP_SX( &p->bmp_map );
	p->sy = N_BMP_SY( &p->bmp_map );

	{
		s32 size = margin / 2;
		s32 maxx = p->sx - size;
		s32 maxy = p->sy - size;

		n_bmp_box( &p->bmp_evt,    0,   0, size,size, n_bmp_rgb( N_CR2_EVENT_D, 150, 100 ) );
		n_bmp_box( &p->bmp_evt, maxx,   0, size,size, n_bmp_rgb( N_CR2_EVENT_L, 150, 100 ) );
		n_bmp_box( &p->bmp_evt,    0,maxy, size,size, n_bmp_rgb( N_CR2_EVENT_R, 150, 100 ) );
		n_bmp_box( &p->bmp_evt, maxx,maxy, size,size, n_bmp_rgb( N_CR2_EVENT_U, 150, 100 ) );
	}

	{

		// [!] : faster code

		s32         m = margin / 2;
		s32 margin_sx = p->sx - margin;
		s32 margin_sy = p->sy - margin;
		s32        fx = 0;
		s32        fy = 0;
		s32        tx = p->sx - m;
		s32        ty = p->sy - m;

		n_bmp_box( &p->bmp_evt,  m, fy, margin_sx,         m, n_bmp_rgb( N_CR2_EVENT_DL, 150, 100 ) );
		n_bmp_box( &p->bmp_evt,  m, ty, margin_sx,         m, n_bmp_rgb( N_CR2_EVENT_UR, 150, 100 ) );
		n_bmp_box( &p->bmp_evt, fx,  m,         m, margin_sy, n_bmp_rgb( N_CR2_EVENT_DR, 150, 100 ) );
		n_bmp_box( &p->bmp_evt, tx,  m,         m, margin_sy, n_bmp_rgb( N_CR2_EVENT_UL, 150, 100 ) );

	}
/*
	{
		// [!] : slower code

		s32 half_x = p->sx / 2;
		s32 half_y = p->sy / 2;
		s32 last_x = p->sx - 1;
		s32 last_y = p->sy - 1;

		n_bmp_fill( &p->bmp_evt, half_x,     0, n_bmp_rgb( N_CR2_EVENT_DL, 150, 100 ) );
		n_bmp_fill( &p->bmp_evt, half_x,last_y, n_bmp_rgb( N_CR2_EVENT_UR, 150, 100 ) );
		n_bmp_fill( &p->bmp_evt,      0,half_y, n_bmp_rgb( N_CR2_EVENT_DR, 150, 100 ) );
		n_bmp_fill( &p->bmp_evt, last_x,half_y, n_bmp_rgb( N_CR2_EVENT_UL, 150, 100 ) );
	}
*/
//n_bmp_save_literal( &p->bmp_evt, "ret.bmp" );


	n_game_chara_bulk_zero( p->chara_obj, N_CR2_CHARA_MAX );

	s32 bmpsx = 0;
	s32 bmpsy = 0;

	int i = 0;
	while( 1 )
	{

		n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "CR2_BMP_C_%d", i );
		n_game_rc_load_bmp( &p->chara_bmp[ i ], str );

		n_bmp_scaler_big( &p->chara_bmp[ i ], p->zoom );

		bmpsx = N_BMP_SX( &p->chara_bmp[ i ] );
		bmpsy = N_BMP_SY( &p->chara_bmp[ i ] );


		n_bmp_carboncopy( &p->chara_bmp[ i ], &p->chara_45u[ i ] );
		n_bmp_matrix_rotate( &p->chara_45u[ i ], -45, n_bmp_black, true );

		bmpsx = bmpsy = n_posix_min_s32( N_BMP_SX( &p->chara_45u[ i ] ), N_BMP_SY( &p->chara_45u[ i ] ) );
		n_bmp_resizer( &p->chara_45u[ i ], bmpsx,bmpsy, n_bmp_black, N_BMP_RESIZER_CENTER );

		n_bmp_carboncopy( &p->chara_45u[ i ], &p->chara_45d[ i ] );
		n_bmp_flush_mirror( &p->chara_45d[ i ], N_BMP_MIRROR_UPSIDE_DOWN );

		n_bmp_resizer( &p->chara_bmp[ i ], bmpsx,bmpsy, n_bmp_black, N_BMP_RESIZER_CENTER );
//if ( i == 0 ) { n_bmp_save_literal( &p->chara_bmp[ i ], "ret.bmp" ); }

		p->unit = bmpsx;

		n_game_chara_bmp( &p->chara_obj[ i ], &game.bmp, &p->chara_bmp[ i ], &p->bmp_map, game.color );
		n_game_chara_prv( &p->chara_obj[ i ] );
		n_game_chara_src( &p->chara_obj[ i ], 0,0, bmpsx,bmpsy, 0,0 );

		i++;
		if ( i >= N_CR2_CHARA_MAX ) { break; }
	}


	n_game_rc_load_bmp_literal( &p->bmp_blt, "CR2_BMP_BLT" );

	n_bmp_scaler_big( &p->bmp_blt, p->zoom );

	n_bmp_carboncopy( &p->bmp_blt, &p->bmp_blt_45u );
	n_bmp_matrix_rotate( &p->bmp_blt_45u, -45, n_bmp_black, true );

	n_bmp_resizer( &p->bmp_blt_45u, bmpsx,bmpsy, n_bmp_black, N_BMP_RESIZER_CENTER );

	n_bmp_carboncopy( &p->bmp_blt_45u, &p->bmp_blt_45d );
	n_bmp_flush_mirror( &p->bmp_blt_45d, N_BMP_MIRROR_UPSIDE_DOWN );

	n_bmp_resizer( &p->bmp_blt, bmpsx,bmpsy, n_bmp_black, N_BMP_RESIZER_CENTER );
//n_bmp_save_literal( &p->bmp_blt, "ret.bmp" );

	{

		int j = 0;
		while( 1 )
		{

			n_game_chara_bmp( &p->chara_blt[ j ], &game.bmp, &p->bmp_blt, &p->bmp_map, game.color );
			n_game_chara_prv( &p->chara_blt[ j ] );
			n_game_chara_src( &p->chara_blt[ j ], 0,0, bmpsx,bmpsy, 0,0 );

			j++;
			if ( j >= N_CR2_BULLET_MAX ) { break; }
		}

	}

	n_game_sound_zero( &p->snd_bgm );
	n_game_sound_init_literal( &p->snd_bgm, game.hwnd, "CR2_WAV_0" ); n_wav_smoother( &p->snd_bgm  .wav );

	{
		int i = 0;
		while( 1 )
		{

			n_game_sound_zero( &p->snd_crash[ i ] );
			n_game_sound_init_literal( &p->snd_crash[ i ], game.hwnd, "CR2_WAV_1" ); n_wav_smoother( &p->snd_crash[ i ].wav );

			n_game_sound_zero( &p->snd_hit[ i ] );
			n_game_sound_init_literal( &p->snd_hit  [ i ], game.hwnd, "CR2_WAV_2" ); n_wav_smoother( &p->snd_hit  [ i ].wav );

			i++;
			if ( i >= N_CR2_CHARA_MAX ) { break; }
		}
	}

//n_posix_debug_literal( "%d", (int) n_posix_tickcount() - tick );


	// Reset

	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );
	n_game_input_vk2button( &p->input, 'Z', 0 );
	n_game_input_vk2button( &p->input, 'X', 1 );
	n_game_input_vk2button( &p->input, 'X', 2 );
	n_game_input_vk2button( &p->input, 'Z', 3 );


	n_cr2_reset( p );


	return;
}

void
n_cr2_loop( n_cr2 *p )
{

	// Sound

	if ( n_game_sound_timer( &p->snd_bgm ) )
	{
		n_game_sound_loop( &p->snd_bgm );
	}


	// Init

	bool input = false;

	static bool init = false;

	if ( init == false )
	{
		init = input = true;
	}


	// Input

	bool redraw = false;


	s32 step_x = 0;
	s32 step_y = 0;


	static bool is_throttle_pressed = false;
	static bool is_gun_shot_pressed = false;


	if ( p->chara_obj[ 0 ].data == N_CR2_CRASH_OFF )
	{

		int o = 0;

		bool offroad = n_cr2_offroad( p, 0 );

		if ( n_game_input_loop( &p->input, 'Z' ) )
		{

			is_throttle_pressed = true;

			if ( offroad == false )
			{

				if ( n_game_timer( &p->throttle_timer, p->throttle_msec ) )
				{
					p->throttle_step[ o ]++;
					if ( p->throttle_step[ o ] > p->throttle_max[ o ] ) { p->throttle_step[ o ] = p->throttle_max[ o ]; }
				}

			}

		} else {

			is_throttle_pressed = false;

			if ( offroad == false )
			{

				if ( n_game_timer( &p->throttle_timer, p->throttle_msec ) )
				{
					p->throttle_step[ o ]--;
					if ( p->throttle_step[ o ] < p->throttle_min[ o ] ) { p->throttle_step[ o ] = p->throttle_min[ o ]; }
				}

			}

		}


		if ( n_game_input_loop( &p->input, 'X' ) )
		{

			is_gun_shot_pressed = true;

			if (
				( p->chara_blt[ p->revolver_index ].data == N_CR2_VK_N )
				&&
				( n_game_timer( &p->revolver_timer, 333 ) )
			)
			{
				p->chara_blt[ p->revolver_index ].data = p->chara_mov[ o ];
				n_game_chara_pos( &p->chara_blt[ p->revolver_index ], p->chara_obj[ o ].x + p->x, p->chara_obj[ o ].y + p->y );
				n_cr2_midi_bullet_on( p->revolver_index );
			}

			p->revolver_index++;
			if ( p->revolver_index >= N_CR2_BULLET_MAX ) { p->revolver_index = 0; }

		} else {

			is_gun_shot_pressed = false;

		}


		if ( n_game_input_loop( &p->input, VK_UP ) )
		{
			input = true;

			step_y = -p->throttle_step[ o ];
			p->chara_mov[ o ] = N_CR2_VK_U;

			if ( n_game_input_loop( &p->input, VK_LEFT ) )
			{
				step_x = -p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_L;
			} else
			if ( n_game_input_loop( &p->input, VK_RIGHT ) )
			{
				step_x = p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_R;
			}
		} else

		if ( n_game_input_loop( &p->input, VK_DOWN ) )
		{
			input = true;

			step_y = p->throttle_step[ o ];
			p->chara_mov[ o ] = N_CR2_VK_D;

			if ( n_game_input_loop( &p->input, VK_LEFT ) )
			{
				step_x = -p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_L;
			} else
			if ( n_game_input_loop( &p->input, VK_RIGHT ) )
			{
				step_x = p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_R;
			}
		} else

		if ( n_game_input_loop( &p->input, VK_LEFT ) )
		{
			input = true;

			step_x = -p->throttle_step[ o ];
			p->chara_mov[ o ] = N_CR2_VK_L;

			if ( n_game_input_loop( &p->input, VK_UP ) )
			{
				step_y = -p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_U;
			} else
			if ( n_game_input_loop( &p->input, VK_DOWN ) )
			{
				step_y = p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_D;
			}
		} else

		if ( n_game_input_loop( &p->input, VK_RIGHT ) )
		{
			input = true;

			step_x = p->throttle_step[ o ];
			p->chara_mov[ o ] = N_CR2_VK_R;

			if ( n_game_input_loop( &p->input, VK_UP ) )
			{
				step_y = -p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_U;
			} else
			if ( n_game_input_loop( &p->input, VK_DOWN ) )
			{
				step_y = p->throttle_step[ o ];
				p->chara_mov[ o ] |= N_CR2_VK_D;
			}
		}

	} else {

		if (
			( n_game_input_loop( &p->input, 'Z' ) )
			||
			( n_game_input_loop( &p->input, 'X' ) )
		)
		{

			// Reset

			if ( ( is_throttle_pressed == false )&&( is_gun_shot_pressed == false ) )
			{
				n_cr2_reset( p );

				n_posix_sleep( 100 );

				n_cr2_draw( p );

				n_game_refresh_on();
			}

		} else {

			is_throttle_pressed = false;
			is_gun_shot_pressed = false;

		}

	}


	// Gunfire

	int j = 0;
	while( 1 )
	{

		if ( p->chara_blt[ j ].data != N_CR2_VK_N )
		{

			if ( p->chara_blt[ j ].data & N_CR2_VK_U )
			{
				p->chara_blt[ j ].y -= p->throttle_max[ 0 ] * 2;
				if ( ( p->chara_blt[ j ].y + p->chara_blt[ j ].sy ) <     0 ) { p->chara_blt[ j ].data = N_CR2_VK_N; n_cr2_midi_bullet_off( j ); }
			} else
			if ( p->chara_blt[ j ].data & N_CR2_VK_D )
			{
				p->chara_blt[ j ].y += p->throttle_max[ 0 ] * 2;
				if ( ( p->chara_blt[ j ].y                        ) > p->sy ) { p->chara_blt[ j ].data = N_CR2_VK_N; n_cr2_midi_bullet_off( j ); }
			}

			if ( p->chara_blt[ j ].data & N_CR2_VK_L )
			{
				p->chara_blt[ j ].x -= p->throttle_max[ 0 ] * 2;
				if ( ( p->chara_blt[ j ].x + p->chara_blt[ j ].sx ) <     0 ) { p->chara_blt[ j ].data = N_CR2_VK_N; n_cr2_midi_bullet_off( j ); }
			} else
			if ( p->chara_blt[ j ].data & N_CR2_VK_R )
			{
				p->chara_blt[ j ].x += p->throttle_max[ 0 ] * 2;
				if ( ( p->chara_blt[ j ].x                        ) > p->sx ) { p->chara_blt[ j ].data = N_CR2_VK_N; n_cr2_midi_bullet_off( j ); }
			}

		}


		j++;
		if ( j >= N_CR2_BULLET_MAX ) { break; }
	}


	// Rivals #1 : Drunken (a green car)

	// [!] : Drunken never die

	//if ( p->chara_obj[ 1 ].data == N_CR2_CRASH_OFF )
	{
		redraw = n_cr2_npc_input( p, 1 );
	}

	// Rivals #2 : F*rr*r* (a red car)

	if ( p->chara_obj[ 2 ].data == N_CR2_CRASH_OFF )
	{
		redraw = n_cr2_npc_input( p, 2 );
	}

	// Rivals #3 : Kn*ght R*d*r (a black car)

	if ( p->chara_obj[ 3 ].data == N_CR2_CRASH_OFF )
	{
		redraw = n_cr2_npc_input( p, 3 );
	}


	if ( n_cr2_crash( p ) ) { redraw = true; }


	if ( input )
	{

		p->x += step_x;
		p->y += step_y;

		redraw = true;

	}

	if ( redraw )
	{

		n_cr2_draw( p );

		n_cr2_crash_draw( p );

		n_game_refresh_on();

	}


	return;
}

void
n_cr2_exit( n_cr2 *p )
{

	n_bmp_free( &p->bmp_map );
	n_bmp_free( &p->bmp_evt );

	n_bmp_free( &p->bmp_blt     );
	n_bmp_free( &p->bmp_blt_45u );
	n_bmp_free( &p->bmp_blt_45d );

	n_game_sound_exit( &p->snd_bgm );


	{
		int i = 0;
		while( 1 )
		{

			n_bmp_free       ( &p->chara_bmp[ i ] );
			n_bmp_free       ( &p->chara_45u[ i ] );
			n_bmp_free       ( &p->chara_45d[ i ] );
			n_game_sound_exit( &p->snd_crash[ i ] );
			n_game_sound_exit( &p->snd_hit  [ i ] );

			i++;
			if ( i >= N_CR2_CHARA_MAX ) { break; }
		}
	}


	n_game_input_exit( &p->input );


	n_hmidiout_exit();


	n_cr2_zero( p );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_cr2_zero( &cr2 );
	n_cr2_init( &cr2 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_cr2_exit( &cr2 );
		n_cr2_init( &cr2 );
		n_game_reset();
	}

	n_cr2_loop( &cr2 );


	return;
}

void
n_game_exit( void )
{

	n_cr2_exit( &cr2 );


	return;
}

#endif // #ifndef N_GAMECONSOLE


