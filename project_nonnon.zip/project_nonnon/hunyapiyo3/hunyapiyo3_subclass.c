// hunyapiyo3
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win_scroll.c"




#ifdef _WIN64
static bool    n_hunyapiyo3_subclass_onoff = false;
#else  // #ifndef _WIN64
static WNDPROC n_hunyapiyo3_subclass_pfunc = NULL;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_hunyapiyo3_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_hunyapiyo3_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{


	switch( msg ) {


	case WM_LBUTTONDOWN :

		if ( hunyapiyo3.phase == N_HUNYAPIYO3_PHASE_CLCK )
		{
			hunyapiyo3.phase = N_HUNYAPIYO3_PHASE_STRT;

			hunyapiyo3.countdown_font_size = 0;

			extern void n_hunyapiyo3_reset( n_hunyapiyo3* );
			n_hunyapiyo3_reset( &hunyapiyo3 );

			n_game_sound_loop( &hunyapiyo3.snd[ N_HUNYAPIYO3_SOUND_CLICK ] );
		}

	break;

	case WM_MOUSEWHEEL :
	{

		s32 cursor_x, cursor_y; n_win_cursor_position_relative( game.hwnd, &cursor_x, &cursor_y );

		s32 x = cursor_x / hunyapiyo3.unit;
		s32 y = cursor_y / hunyapiyo3.unit;

		if (
			( ( x >= 0 )&&( x < N_HUNYAPIYO3_MAP_SX ) )
			&&
			( ( y >= 0 )&&( y < N_HUNYAPIYO3_MAP_SY ) )
		)
		{
			int delta = n_win_scroll_wheeldelta( wparam, 1 );
			if ( delta > 0 )
			{
				int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

				hunyapiyo3.ret[ ret_pos ]++;
				if ( hunyapiyo3.ret[ ret_pos ] >= N_HUNYAPIYO3_RANDOM )
				{
					hunyapiyo3.ret[ ret_pos ] = -1;
				}
			} else
			if ( delta < 0 )
			{
				int ret_pos = x + ( N_HUNYAPIYO3_MAP_SX * y );

				hunyapiyo3.ret[ ret_pos ]--;
				if ( hunyapiyo3.ret[ ret_pos ] < -1 )
				{
					hunyapiyo3.ret[ ret_pos ] = N_HUNYAPIYO3_RANDOM - 1;
				}
			}
		}

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_hunyapiyo3_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_hunyapiyo3_subclass_init( n_hunyapiyo3 *p )
{

#ifdef _WIN64

	if ( n_hunyapiyo3_subclass_onoff ) { return; }

	SetWindowSubclass( game.hwnd, n_hunyapiyo3_subclass, 0, 0 );

	n_hunyapiyo3_subclass_onoff = true;

#else  // #ifdef _WIN64

	// [!] : once per session

	if ( n_hunyapiyo3_subclass_pfunc != NULL ) { return; }

	n_hunyapiyo3_subclass_pfunc = n_win_gui_subclass_set( game.hwnd, n_hunyapiyo3_subclass );

#endif // #ifdef _WIN64

	return;
}

void
n_hunyapiyo3_subclass_exit( n_hunyapiyo3 *p )
{

#ifdef _WIN64

	if ( n_hunyapiyo3_subclass_onoff == false ) { return; }

	RemoveWindowSubclass( game.hwnd, n_hunyapiyo3_subclass, 0 );

	n_hunyapiyo3_subclass_onoff = false;

#else  // #ifdef _WIN64

	if ( n_hunyapiyo3_subclass_pfunc == NULL ) { return; }

	n_win_gui_subclass_set( game.hwnd, n_hunyapiyo3_subclass_pfunc );

	n_hunyapiyo3_subclass_pfunc = NULL;

#endif // #ifdef _WIN64


	return;
}

