// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_paint_property_usedcolors( n_bmp *bmp )
{

	const s32 bmpsx = N_BMP_SX( bmp );
	const s32 bmpsy = N_BMP_SY( bmp );
	const s32 pixel = bmpsx * bmpsy;
	const s32 byte  = pixel * sizeof( u32 );


	u32 *pal   = n_memory_new_closed( byte );
	int  count = 0;

	n_memory_zero( pal, byte );


	// [!] : histogram

	s32 x,y;
	u32 color;

	x = y = 0;
	while( 1 )
	{//break;

		n_bmp_ptr_get_fast( bmp, x,y, &color );

		s32 i = 0;
		while( 2 )
		{

			// [Needed] : for the first color

			if ( i >= count )
			{
				pal[ i ] = color;
				count++;
				break;
			}


			if ( pal[ i ] == color )
			{
				break;
			}

			i++;

		}


		x++;
		if ( x >= bmpsx )
		{

			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}


	n_memory_free_closed( pal );


	{

		n_posix_char str[ 100 ];

		n_posix_sprintf_literal( str, "Used Colors : %d", count );

		n_paint_dialog_info( str );

	}


	return;
}


