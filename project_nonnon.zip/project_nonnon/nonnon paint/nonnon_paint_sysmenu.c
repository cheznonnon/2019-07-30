// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win_menu.c"




#define N_PAINT_SYSMENU_PREVIEW    0
#define N_PAINT_SYSMENU_LINE1      1
#define N_PAINT_SYSMENU_GRID       2
#define N_PAINT_SYSMENU_PIXELGRID  3
#define N_PAINT_SYSMENU_FRAME      4
#define N_PAINT_SYSMENU_LINE2      5
#define N_PAINT_SYSMENU_CLR_CANVAS 6
#define N_PAINT_SYSMENU_ALPHA      7
#define N_PAINT_SYSMENU_REPLACER   8
#define N_PAINT_SYSMENU_LINE3      9
#define N_PAINT_SYSMENU_INI2GDI    10
#define N_PAINT_SYSMENU_LINE4      11
#define N_PAINT_SYSMENU_GRAYCANVAS 12
#define N_PAINT_SYSMENU_LINE5      13
#define N_PAINT_SYSMENU_PROPERTY   14
#define N_PAINT_SYSMENU_LINE6      15




void
n_paint_sysmenu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int menu_start = 0;

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "1 : Preview"    ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_CHECK, false, false, n_posix_literal( "2 : Grid"       ) },
		{ N_WIN_MENU_CHECK, false, false, n_posix_literal( "3 : Pixel Grid" ) },
		{ N_WIN_MENU_CHECK, false, false, n_posix_literal( "4 : Frame"      ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "5 : Clear Canvas"   ) },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "6 : Alpha Tweaker"  ) },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "7 : Color Replacer" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "8 : Output ini2gdi.ini" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_CHECK, false, false, n_posix_literal( "9 : Gray Canvas" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_CHECK, false, false, n_posix_literal( "0 : Used Colors" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_NONE,  false, false, NULL }

	};


	if ( false == N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		menu[ N_PAINT_SYSMENU_CLR_CANVAS ].string = n_posix_literal( "5 : Clear Grabbed Area" );
	} else {
		menu[ N_PAINT_SYSMENU_CLR_CANVAS ].string = n_posix_literal( "5 : Clear Canvas" );
	}


	int ret = n_win_menu_system_proc( hwnd, msg, wparam, lparam, menu, menu_start );


	switch( ret ) {


	case N_PAINT_SYSMENU_PREVIEW :
	{

		static HWND hpreview = NULL;

		if ( IsWindow( hpreview ) )
		{
			n_win_message_send( hpreview, WM_CLOSE, 0,0 );
		} else {
			n_win_gui( hwnd_main, WINDOW, n_paint_preview_wndproc, &hpreview );
		}

	}
	break;

	case N_PAINT_SYSMENU_GRID :
	{

		n_win_menu_checkbox( menu, ret );


		bool prev = grid;

		grid = n_win_menu_is_on( menu, ret );

		if ( prev != grid ) { n_paint_refresh_all(); }

	}
	break;

	case N_PAINT_SYSMENU_PIXELGRID :
	{

		n_win_menu_checkbox( menu, ret );


		bool prev = pixelgrid;

		pixelgrid = n_win_menu_is_on( menu, ret );

		if ( prev != pixelgrid ) { n_paint_refresh_all(); }

	}
	break;

	case N_PAINT_SYSMENU_FRAME :
	{

		n_win_menu_checkbox( menu, ret );


		bool prev = frame;

		frame = n_win_menu_is_on( menu, ret );

		if ( prev != frame ) { n_paint_refresh_all(); }

	}
	break;

	case N_PAINT_SYSMENU_CLR_CANVAS :
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_clearcanvas_wndproc, &hpopup );
/*
		if ( n_paint_dialog_yesno( n_project_string_really_ok ) )
		{
			n_paint_filter( N_PAINT_FILTER_CLEAR );
		}
*/
	}
	break;

	case N_PAINT_SYSMENU_ALPHA :
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_alphatweaker_wndproc, &hpopup );

	}
	break;

	case N_PAINT_SYSMENU_REPLACER :
	{

		HWND hpopup;
		n_win_gui( hwnd_main, WINDOW, n_paint_colorreplacer_wndproc, &hpopup );

	}
	break;

	case N_PAINT_SYSMENU_INI2GDI :

		n_resource_save_literal( "NONNON_PAINT_INI2GDI", "DATA", "ini2gdi.ini" );

		n_explorer_refresh( false );

	break;

	case N_PAINT_SYSMENU_GRAYCANVAS :
	{

		n_win_menu_checkbox( menu, ret );


		bool prev = graycanvas;

		graycanvas = n_win_menu_is_on( menu, ret );

		if ( prev != graycanvas ) { n_paint_refresh_all(); }

	}
	break;

	case N_PAINT_SYSMENU_PROPERTY :

		n_win_cursor_add( NULL, IDC_WAIT );

		n_paint_property_usedcolors( &n_paint_bmp_data );

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	} // switch


	return;
}

