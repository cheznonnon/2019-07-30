// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DARKMODE
#define _H_NONNON_WIN32_WIN_DARKMODE




#include "../../neutral/bmp/all.c"


#include "../registry.c"


#include "../gdi/color.c"




static bool n_win_darkmode_onoff = false;




void
n_win_darkmode( void )
{

	u32 light_onoff = true;


	n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" );
	n_posix_char *section = n_posix_literal( "AppsUseLightTheme" );

	DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &light_onoff, sizeof( u32 ) );

	if ( ret != ERROR_SUCCESS ) { light_onoff = true; }


	n_win_darkmode_onoff = ( light_onoff == false );
//n_win_darkmode_onoff = true;


	return;
}

LRESULT
n_win_darkmode_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CTLCOLORSTATIC :

		if ( n_win_darkmode_onoff )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			return (LRESULT) GetStockObject( BLACK_BRUSH );
		}

	break;


	} // switch


	return 0;
}

HBRUSH
n_win_darkmode_brush_bg( int color_id_fallback )
{

	HBRUSH ret;

	if ( n_win_darkmode_onoff )
	{
		ret = GetStockObject( BLACK_BRUSH );
	} else {
		ret = GetSysColorBrush( color_id_fallback );
	}

	return ret;
}

COLORREF
n_win_darkmode_systemcolor( int color_id )
{

	COLORREF ret;

	if ( n_win_darkmode_onoff )
	{

		if ( color_id == COLOR_WINDOW        ) { ret = RGB(   0,  0,  0 ); } else
		if ( color_id == COLOR_WINDOWTEXT    ) { ret = RGB( 255,255,255 ); } else
		if ( color_id == COLOR_HIGHLIGHT     ) { ret = RGB( 150,150,150 ); } else
		if ( color_id == COLOR_HIGHLIGHTTEXT ) { ret = RGB( 255,255,255 ); } else
		if ( color_id == COLOR_BTNFACE       ) { ret = RGB(   0,  0,  0 ); } else
		if ( color_id == COLOR_BTNSHADOW     ) { ret = RGB( 100,100,100 ); } else
		if ( color_id == COLOR_GRAYTEXT      ) { ret = RGB( 200,200,200 ); } else
		if ( color_id == COLOR_BTNTEXT       ) { ret = RGB( 255,255,255 ); } else
		if ( color_id == COLOR_BTNHIGHLIGHT  ) { ret = RGB( 111,111,111 ); } else
		if ( color_id == COLOR_3DLIGHT       ) { ret = RGB( 222,222,222 ); } else
		if ( color_id == COLOR_3DDKSHADOW    ) { ret = RGB(  50, 50, 50 ); } else
		{ ret = GetSysColor( color_id ); }

	} else {

		ret = GetSysColor( color_id );

	}


	return ret;
}

u32
n_win_darkmode_systemcolor_rgb2pal( int color_id )
{

	COLORREF color = n_win_darkmode_systemcolor( color_id );
	u32      tmp   = n_gdi_colorref2argb( NULL, color );
	u32      ret   = n_bmp_alpha_visible_pixel( tmp );


	return ret;
}

void
n_win_darkmode_bmp_flush_reverse( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	s32 sx = N_BMP_SX( bmp );
	s32 sy = N_BMP_SY( bmp );

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		u32 color;

		n_bmp_ptr_get_fast( bmp, x,y, &color );

		color = n_bmp_grayscale_pixel( color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		color = n_bmp_argb( a,r,g,b );

		n_bmp_ptr_set_fast( bmp, x,y,  color );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}




#endif // _H_NONNON_WIN32_WIN_DARKMODE

