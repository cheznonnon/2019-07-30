// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_GUI
#define _H_NONNON_WIN32_WIN_GUI




#include "../sysinfo/version.c"


#include "./_debug.c"
#include "./icon.c"
#include "./stdfont.c"
#include "./style.c"
#include "./subclass.c"




#define N_WIN_GUI_WINDOW          0

#define N_WIN_GUI_BUTTON          1
#define N_WIN_GUI_FLATBUTTON      2
#define N_WIN_GUI_ICONBUTTON      3
#define N_WIN_GUI_FLATICONBUTTON  4
#define N_WIN_GUI_CHECK           5
#define N_WIN_GUI_ICONCHECK       6
#define N_WIN_GUI_RADIO           7
#define N_WIN_GUI_ICONRADIO       8
#define N_WIN_GUI_GROUP           9

#define N_WIN_GUI_COMBO          10

#define N_WIN_GUI_INPUT          11
#define N_WIN_GUI_EDITOR         12

#define N_WIN_GUI_LIST           13

#define N_WIN_GUI_HSCROLL        14
#define N_WIN_GUI_VSCROLL        15

#define N_WIN_GUI_CANVAS         16
#define N_WIN_GUI_CANVAS_BUTTON  17
#define N_WIN_GUI_LABEL          18
#define N_WIN_GUI_STATIC         19




#define n_win_gui_literal( a, b, c, d ) n_win_gui( a, b, n_posix_literal( c ), d )

bool
n_win_gui( HWND hwnd_parent, int type, void *data, HWND *hwnd_gui )
{

	// [ Mechanism ] : flicker prevention while window resizing
	//
	//	1 : don't use CS_HREDRAW | CS_VREDRAW
	//	2 : use WS_CLIPCHILDREN with parent window
	//	3 : use WS_CLIPSIBLINGS with child window
	//
	//	4 : XP : use WS_EX_COMPOSITED with all controls
	//
	//	5 : use static control as a parent window
	//
	//	6 : use subclass + double-buffering + WM_PRINTCLIENT


	const HINSTANCE hinst = GetModuleHandle( NULL );

	n_posix_char  str[ 256 ]; n_string_zero( str, 256 );
	n_posix_char  ico[ 256 ]; n_string_zero( ico, 256 );
	n_posix_char *class      = NULL;

	HWND  hwnd    = NULL;
	WORD  atom    = 0;
	DWORD style   = WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
	DWORD exstyle = 0;


	if ( type == N_WIN_GUI_WINDOW )
	{

		WNDCLASSEX wc;


		ZeroMemory( &wc, sizeof( WNDCLASSEX ) );

		wc.cbSize      = sizeof( WNDCLASSEX );
		wc.style       = CS_DBLCLKS;
		wc.lpfnWndProc = data;
		wc.hInstance   = hinst;

		int i = 0;
		while( 1 )
		{

			n_posix_sprintf_literal( str, "window #%d", i );

			UnregisterClass( str, hinst );

			wc.lpszClassName = str;

			atom = RegisterClassEx( &wc );

			if ( atom != 0 ) { break; }


			i++;
			if ( i >= SHRT_MAX ) { return true; }
 		}


		// [Mechanism]
		//
		//	WS_VISIBLE : cause flicker on Win2000
		//	WS_CHILD   : behave badly when child window

		style   = style & ~( WS_CHILD | WS_VISIBLE );
		exstyle = 0;
		data    = N_STRING_EMPTY;
		class   = str;

	} else

	if (
		( ( type == N_WIN_GUI_BUTTON     )||( type == N_WIN_GUI_FLATBUTTON     ) )
		||
		( ( type == N_WIN_GUI_ICONBUTTON )||( type == N_WIN_GUI_FLATICONBUTTON ) )
	)
	{

		class = n_posix_literal( "BUTTON" );
		style = style | BS_PUSHBUTTON;

		if ( ( type == N_WIN_GUI_FLATBUTTON )||( type == N_WIN_GUI_FLATICONBUTTON ) )
		{
			style = style | BS_FLAT;
		}

		if ( ( type == N_WIN_GUI_ICONBUTTON )||( type == N_WIN_GUI_FLATICONBUTTON ) )
		{
			n_string_copy( data, ico );
			data  = NULL;
			style = style | BS_ICON;
		}

	} else
	if ( ( type == N_WIN_GUI_CHECK )||( type == N_WIN_GUI_ICONCHECK ) )
	{

		class = n_posix_literal( "BUTTON" );
		style = style | BS_AUTOCHECKBOX;

		if ( type == N_WIN_GUI_ICONCHECK )
		{
			n_string_copy( data, ico );
			data  = NULL;
			style = style | BS_ICON | BS_PUSHLIKE;
		}

	} else
	if ( type == N_WIN_GUI_RADIO )
	{

		class = n_posix_literal( "BUTTON" );
		style = style | BS_AUTORADIOBUTTON;

		if ( type == N_WIN_GUI_ICONRADIO )
		{
			n_string_copy( data, ico );
			data  = NULL;
			style = style | BS_ICON | BS_PUSHLIKE;
		}

	} else
	if ( type == N_WIN_GUI_GROUP )
	{

		class = n_posix_literal( "BUTTON" );
		style = style | BS_GROUPBOX;

	} else

	if ( type == N_WIN_GUI_COMBO )
	{

		class = n_posix_literal( "COMBOBOX" );
		style = style | WS_VSCROLL;
		style = style | CBS_DROPDOWNLIST | CBS_SORT;

	} else

	if ( type == N_WIN_GUI_INPUT )
	{

		class   = n_posix_literal( "EDIT" );
		style   = style | ES_AUTOHSCROLL;
		exstyle = WS_EX_CLIENTEDGE;

	} else
	if ( type == N_WIN_GUI_EDITOR )
	{

		class   = n_posix_literal( "EDIT" );
		style   = style | WS_VSCROLL | WS_HSCROLL | ES_AUTOVSCROLL | ES_AUTOHSCROLL;
		style   = style | ES_MULTILINE | ES_WANTRETURN | ES_NOHIDESEL;
		exstyle = WS_EX_CLIENTEDGE;

	} else

	if ( type == N_WIN_GUI_LIST )
	{

		class   = n_posix_literal( "LISTBOX" );
		style   = style | LBS_STANDARD;
		exstyle = WS_EX_CLIENTEDGE;

	} else

	if ( type == N_WIN_GUI_HSCROLL )
	{

		class   = n_posix_literal( "SCROLLBAR" );
		style   = style | SBS_HORZ;

	} else
	if ( type == N_WIN_GUI_VSCROLL )
	{

		class   = n_posix_literal( "SCROLLBAR" );
		style   = style | SBS_VERT;

	} else
	if ( type == N_WIN_GUI_CANVAS )
	{

		// [!] : Win10 Technical Preview
		//
		//	static ownerdraw
		//	WM_MOUSEWHEEL is not sent

		// [!] : SS_NOTIFY is troublesome

		class  = n_posix_literal( "STATIC" );
		style   = style | SS_OWNERDRAW;

	} else
	if ( type == N_WIN_GUI_CANVAS_BUTTON )
	{

		// [x] : Button Ownerdraw
		//
		//	input will be taken up
		//	some problems can be resolved when using subclass
		//
		//	IME is off by default
		//	use ImmAssociateContext( hgui, ImmCreateContext() ); @ imm.h @ imm32.dll

		class  = n_posix_literal( "BUTTON" );
		style   = style | BS_OWNERDRAW;

	} else
	if ( type == N_WIN_GUI_LABEL )
	{

		class = n_posix_literal( "STATIC" );
		style = style | SS_LEFT | SS_CENTERIMAGE;

	} else
	if ( type == N_WIN_GUI_STATIC )
	{

		class  = n_posix_literal( "STATIC" );

	}// else


	if ( class == NULL ) { return true; }

	hwnd = CreateWindowEx
	(
		exstyle,
		class,
		data,
		style,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);


	if ( type != N_WIN_GUI_WINDOW )
	{

		n_win_font_default( hwnd, false );

		if ( ( type == N_WIN_GUI_INPUT )||( type == N_WIN_GUI_EDITOR ) )
		{
			n_win_subclass_edit_init( hwnd, class );
		}// else

	}


#ifndef _H_NONNON_WIN32_OLE_IDROPTARGET

	// [!] : for Windows95 without IE4

	DragAcceptFiles( hwnd, true );

#endif // #ifndef _H_NONNON_WIN32_OLE_IDROPTARGET


	if ( hwnd_gui != NULL ) { (*hwnd_gui) = hwnd; }


	return false;
}


#endif // _H_NONNON_WIN32_WIN_GUI

