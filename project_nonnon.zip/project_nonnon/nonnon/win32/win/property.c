// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : 64-bit : crash : you cannot use pointers




#ifndef _H_NONNON_WIN32_WIN_PROPERTY
#define _H_NONNON_WIN32_WIN_PROPERTY




#include "../../neutral/posix.c"




#define n_win_property_namespace_cch( h, n ) n_win_property_namespace( h, n, NULL )

size_t
n_win_property_namespace( HWND hgui, const n_posix_char *namespace, n_posix_char *str )
{

	const n_posix_char *base = n_posix_literal( "Nonnon.Win32.Property" );


	size_t cch = 0;

	if ( str == NULL )
	{
		n_posix_char str_hgui[ 100 ]; n_posix_sprintf_literal( str_hgui, "%x", (int) hgui );
		cch = n_posix_strlen( base ) + 1 + n_posix_strlen( str_hgui ) + 1 + n_posix_strlen( namespace );
	} else {
		cch = n_posix_sprintf_literal( str, "%s.%x.%s", base, (int) hgui, namespace );
	}


	return cch;
}

#define n_win_property_init         n_win_property_set
#define n_win_property_init_literal n_win_property_set_literal

#define n_win_property_exit_literal( h, s ) n_win_property_exit( h, n_posix_literal( s ) )

void
n_win_property_exit( HWND hgui, const n_posix_char *namespace )
{

	size_t        cch = n_win_property_namespace_cch( hgui, namespace );
	n_posix_char *str = n_string_new( cch ); n_win_property_namespace( hgui, namespace, str );

	GlobalFree( RemoveProp( hgui, str ) );

	n_string_free( str );


	return;
}

#define n_win_property_set_literal( h, s, v ) n_win_property_set( h, n_posix_literal( s ), v )

void
n_win_property_set( HWND hgui, const n_posix_char *namespace, int value )
{

	size_t        cch = n_win_property_namespace_cch( hgui, namespace );
	n_posix_char *str = n_string_new( cch ); n_win_property_namespace( hgui, namespace, str );


	HANDLE h = GetProp( hgui, str );
	if ( h == NULL )
	{
		h = GlobalAlloc( GHND, sizeof(int) );
	}


	int *i = GlobalLock( h );

	if ( i != NULL ) { (*i) = value; }

	GlobalUnlock( h );


	SetProp( hgui, str, h );


	n_string_free( str );


	return;
}

#define n_win_property_get_literal( h, s ) n_win_property_get( h, n_posix_literal( s ) )

int
n_win_property_get( HWND hgui, const n_posix_char *namespace )
{

	size_t        cch = n_win_property_namespace_cch( hgui, namespace );
	n_posix_char *str = n_string_new( cch ); n_win_property_namespace( hgui, namespace, str );


	int ret = 0;


	HANDLE h = GetProp( hgui, str );
	if ( h != NULL )
	{

		int *i = GlobalLock( h );
		if ( i != NULL ) { ret = (*i); }

		GlobalUnlock( h );

	}


	n_string_free( str );


	return ret;
}


#endif // _H_NONNON_WIN32_WIN_PROPERTY

