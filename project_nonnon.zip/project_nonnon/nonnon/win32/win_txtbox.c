// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Link ]
//
//		-limm32
//
//			for Input Method Editor support
//
//
//	[ Notification ]
//
//		[ WM_COMMAND ]
//
//			WPARAM : WM_*BUTTON* / WM_KEYDOWN / WM_SETFOCUS / WM_KILLFOCUS
//			LPARAM : HWND of Txtbox
//
//
//	[ Style ]
//
//		[ N_WIN_TXTBOX_STYLE_LISTBOX ]
//
//			listbox-like behavior
//
//		[ N_WIN_TXTBOX_STYLE_ONELINE ]
//
//			edit-like behavior : one liner
//
//		[ N_WIN_TXTBOX_STYLE_EDITBOX ]
//
//			edit-like behavior : multiple lines
//
//		[ N_WIN_TXTBOX_STYLE_HSCROLL/VSCROLL ]
//
//			scrollbar on/off
//
//		[ N_WIN_TXTBOX_STYLE_NO_BRDR ]
//
//			border will be off
//
//		[ N_WIN_TXTBOX_STYLE_NO_PDNG ]
//
//			padding will be off
//
//		[ N_WIN_TXTBOX_STYLE_STRIPED ]
//
//			striped background
//
//		[ N_WIN_TXTBOX_STYLE_VISIBLE ]
//
//			for drawing on a DWM transparent window
//
//		[ N_WIN_TXTBOX_STYLE_TRANSBG ]
//
//			for drawing on a DWM transparent window
//
//		[ N_WIN_TXTBOX_STYLE_FLATBDR ]
//
//			flat border in classic style
//			made for win32/win_combobox.c
//
//		[ N_WIN_TXTBOX_STYLE_CMB_BDR ]
//
//			combobox border
//			made for win32/win_combobox.c
//
//		[ N_WIN_TXTBOX_STYLE__DI_HDC ]
//
//			use di->hDC for game loop
//
//
//	[ Style Option ]
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_BOLDTXT ]
//
//			strings started with "[b]" will be bold
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ]
//
//			keep selection when out-of-bound area is clicked
//
//			+ this is listbox compatible behavior
//
//		[ N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ]
//
//			auto-highlight a hovered item
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ]
//
//			text will be centered when N_WIN_TXTBOX_OPTION_EDITBOX_ONELINE
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ]
//
//			input filename safe characters only
//
//		[ N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ]
//
//			input digit only
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ]
//
//			line number on/off
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ]
//
//			a cursor doesn't use ibeam
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ]
//
//			a caret will be disappeared when no focus
//
//		[ N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ]
//
//			editbox but edit functions off
//
//		[ N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ]
//
//			turn off focus-border-change
//
//		[ N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ]
//
//			a little different rendering between fast mode and slow mode
//
//
//	[ More Option ]
//
//		[ .placeholder ]
//
//			placeholder text for N_WIN_TXTBOX_OPTION_EDITBOX_ONELINE
//
//		[ .tab_mark ]
//
//			TAB Marker for N_WIN_TXTBOX_STYLE_EDITBOX
//			+ "auto" is special
//
//		[ .eol_mark ]
//
//			End-Of-Line Marker for N_WIN_TXTBOX_STYLE_EDITBOX
//			+ "auto" is special
//
//		[ .oneline_cache_onoff ]
//
//			currently, you need to set false manually at drawing 
//
//		[ .virtual_padding_pxl_sx ]
//
//			for text offset
//			currently, N_WIN_TXTBOX_STYLE_LISTBOX only supported
//
//		[ .mouse_input_stop_onoff ]
//
//			stop mouse input
//			for combobox slide
//
//
//	[ etc ]
//
//		[ middle button ]
//
//			delayed selection when focus is set
//
//		[ grayed background ]
//
//			use n_win_txtbox_grayed()
//
// 		[ when you use subclass ]
//
//			call n_win_txtbox_proc_menu_editbox( txtbox.hwnd, WM_CREATE, 0, 0, &txtbox );
//
//		[ initialization trouble shooter ]
//
//			check initialization order
//			call n_win_txtbox_init() before other controls




#ifndef _H_NONNON_WIN32_TXTBOX
#define _H_NONNON_WIN32_TXTBOX




#ifdef _MSC_VER

#pragma comment( lib, "imm32" )

#endif // #ifdef _MSC_VER




#include "../neutral/bmp/filter.c"
#include "../neutral/txt.c"


#include "./clipboard.c"
#include "./gdi/doublebuffer.c"
#include "./uxtheme.c"
#include "./win.c"
#include "./win_menu.c"
#include "./win_scrollbar.c"
#include "./win_smallbutton.c"




bool
n_win_txtbox_filename_is_safe_char( n_posix_char c )
{

	if ( c == n_posix_literal( '\t' ) ) { return false; }
	if ( c == n_posix_literal( '\\' ) ) { return false; }
	if ( c == n_posix_literal( '/'  ) ) { return false; }
	if ( c == n_posix_literal( ':'  ) ) { return false; }
	if ( c == n_posix_literal( '*'  ) ) { return false; }
	if ( c == n_posix_literal( '?'  ) ) { return false; }
	if ( c == n_posix_literal( '\"' ) ) { return false; }
	if ( c == n_posix_literal( '<'  ) ) { return false; }
	if ( c == n_posix_literal( '>'  ) ) { return false; }
	if ( c == n_posix_literal( '|'  ) ) { return false; }


	return true;
}

bool
n_win_txtbox_filename_is_safe( n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return false; }


	size_t space = 0;

	size_t i = 0;
	while( 1 )
	{
		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( i == 0 )
		{
			if ( str[ i ] == N_STRING_CHAR_SPACE ) { space++; }
		} else
		if ( ( space != 0 )&&( str[ i ] != N_STRING_CHAR_SPACE ) )
		{
			return false;
		}

		i++;
	}

	if ( space != 0 ) { return false; }


	i = 0;
	while( 1 )
	{
		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		bool ret = n_win_txtbox_filename_is_safe_char( str[ i ] );
		if ( ret == false ) { return false; }

		i++;
	}


	return true;
}

bool
n_win_txtbox_filename_is_digit( n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return false; }


	size_t i = 0;
	while( 1 )
	{
		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( false == n_string_is_digit( str, i ) )
		{
			return false;
		}

		i++;
	}


	return true;
}

// internal
bool
n_win_txtbox_is_fullwidth( n_posix_char c )
{

#ifdef UNICODE

	// [x] : why edit control uses too strict range
	//
	//	maybe compatibility with IME causes this 

	if ( c <= 127 )
	{

		// [!] : ASCII compatible code

		return false;

	} else
	if (
/*
		(						// 8448 - 8703
			( c == 8470 )
			||
			( ( c >=  8544 )&&( c <=  8578 ) )
		)
		||
		(						// 8704 - 8959
			( ( c >=  8704 )&&( c <=  8748 ) )
			||
			( c == 8750 )
		)
		||
		( ( c >=  8960 )&&( c <=  9215 ) )		// 8960 - 9215 
		||
		( ( c >=  9312 )&&( c <=  9471 ) )		// 9216 - 9471
		||
		(						// 9472 - 9727
			( ( c >=  9472 )&&( c <=  9475 ) )
			||
			( c == 9484 )
			||
			( ( c >=  9622 )&&( c <=  9633 ) )
			||
			( ( c >=  9670 )&&( c <=  9671 ) )
			||
			( ( c >=  9678 )&&( c <=  9679 ) )
		)
		||
*/
		( ( c >= 0x2600 )&&( c <= 0x26ff ) )		//  9728 -  9983
		||
		( ( c >= 0x2700 )&&( c <= 0x27ff ) )		//  9984 - 10239
		||
		( ( c >= 0x2e00 )&&( c <= 0x2eff ) )		// 11766 - 12031
		||
		( ( c >= 0x2f00 )&&( c <= 0x2fff ) )		// 12032 - 12287
		||
		( ( c >= 0x3000 )&&( c <= 0xd7ff ) )		// 12288 - 55295
		||
		( ( c >= 0xff00 )&&( c <= 0xff60 ) )		// 65280 - 65376 : 0xff61 or above : includes "half-width kana"
	)
	{
		return true;
	}


	wchar_t w[ 2 ] = { c, L'\0' };
	 char   a[ 3 ] = { '\0', '\0', '\0' };

	WideCharToMultiByte( CP_ACP, 0, w,2, a,3, NULL,NULL );

	if ( 1 < strlen( a ) ) { return true; } 

#endif // #ifdef UNICODE


	return false;
}




// internal
HFONT
n_win_txtbox_font_bold( HFONT hfont )
{

	LOGFONT lf = n_win_font_hfont2logfont( hfont );


	lf.lfWeight = FW_BOLD;


	return n_win_font_logfont2hfont( &lf );
}

// internal
void
n_win_txtbox_box_invert( HDC hdc, s32 x, s32 y, s32 sx, s32 sy, COLORREF color_fg, COLORREF color_bg )
{

	// [!] : InvertRect() only supports black and white


	if ( hdc == NULL ) { return; }


	// [!] : Classic Theme : alpha value causes black-out

	color_fg &= 0x00ffffff;
	color_bg &= 0x00ffffff;

	sx += x;
	sy += y;

	s32 start_x = x;
	while( 1 )
	{

		COLORREF color = GetPixel( hdc, x, y );

		if ( color != color_fg ) { color = color_fg; } else { color = color_bg; }

		SetPixelV( hdc, x, y, color );

		x++;
		if ( x >= sx )
		{
			x = start_x;
			y++;	
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_win_txtbox_frame( HDC hdc, RECT *r, s32 scale, COLORREF color )
{

	HGDIOBJ hp = SelectObject( hdc, CreatePen( PS_SOLID, scale, color ) );
	HGDIOBJ hb = SelectObject( hdc, GetStockObject( NULL_BRUSH ) );

	s32 fx,fy,tx,ty; n_win_rect_expand_range( r, &fx,&fy,&tx,&ty );
	Rectangle( hdc, fx,fy,tx,ty );

	DeleteObject( SelectObject( hdc, hp ) );
	DeleteObject( SelectObject( hdc, hb ) );


	return;
}

#define n_win_txtbox_caret_l( line, x, ret ) n_win_txtbox_caret( line, x,  ret, NULL, NULL )
#define n_win_txtbox_caret_m( line, x, ret ) n_win_txtbox_caret( line, x, NULL,  ret, NULL )
#define n_win_txtbox_caret_r( line, x, ret ) n_win_txtbox_caret( line, x, NULL, NULL,  ret )

s32
n_win_txtbox_caret( const n_posix_char *line, s32 x, s32 *ret_l, s32 *ret_m, s32 *ret_r )
{

	s32 l = 0;
	s32 m = 0;
	s32 r = 0;

#ifdef UNICODE

	l = m = r = x;

	if ( m != 0 )
	{
		l--;
		if ( n_unicode_surrogatepair_is_lo( line[ l ] ) ) { l--; }
	}
	if ( line[ m ] != N_STRING_CHAR_NUL )
	{
		r++;
		if ( n_unicode_surrogatepair_is_lo( line[ r ] ) ) { r++; }
	}

#else // #ifdef UNICODE

	while( 1 )
	{

		if ( line[ m ] == N_STRING_CHAR_NUL ) { break; }

		s32 unit = n_string_doublebyte_increment( line[ m ] );

		r = m + unit;

		if ( ( x >= m )&&( x < r ) ) { break; }

		l = m;
		m = r;

	}

#endif // #ifdef UNICODE

	if ( ret_l != NULL ) { (*ret_l) = l; }
	if ( ret_m != NULL ) { (*ret_m) = m; }
	if ( ret_r != NULL ) { (*ret_r) = r; }


	return m;
}

COLORREF
n_win_txtbox_color_hue_tweak( COLORREF color, int offset )
{

	int r = GetRValue( color );
	int g = GetGValue( color );
	int b = GetBValue( color );

	u32 ahsl = n_bmp_argb2ahsl( n_bmp_rgb( r,g,b ) );

	int h = n_bmp_h( ahsl ) + offset;
	int s = n_bmp_s( ahsl );
	int l = n_bmp_l( ahsl );

	color = n_bmp_ahsl2argb( n_bmp_hsl( h,s,l ) );

	r = n_bmp_r( color );
	g = n_bmp_g( color );
	b = n_bmp_b( color );


	return RGB( r,g,b );
}




#define N_WIN_TXTBOX_NAMESPACE     n_posix_literal( "Txtbox" )

#define N_WIN_TXTBOX_ALL           ( -1 )
#define N_WIN_TXTBOX_NOT_SELECTED  ( -1 )

#define N_WIN_TXTBOX_FOCUS_NONE    ( 0 )
#define N_WIN_TXTBOX_FOCUS_WAIT    ( 1 )
#define N_WIN_TXTBOX_FOCUS_GO      ( 2 )


#define N_WIN_TXTBOX_STYLE_LISTBOX          ( 1 <<  0 )
#define N_WIN_TXTBOX_STYLE_ONELINE          ( 1 <<  1 )
#define N_WIN_TXTBOX_STYLE_EDITBOX          ( 1 <<  2 )
#define N_WIN_TXTBOX_STYLE_HSCROLL          ( 1 <<  3 )
#define N_WIN_TXTBOX_STYLE_VSCROLL          ( 1 <<  4 )
#define N_WIN_TXTBOX_STYLE_NO_BRDR          ( 1 <<  5 )
#define N_WIN_TXTBOX_STYLE_NO_PDNG          ( 1 <<  6 )
#define N_WIN_TXTBOX_STYLE_STRIPED          ( 1 <<  7 )
#define N_WIN_TXTBOX_STYLE_VISIBLE          ( 1 <<  8 )
#define N_WIN_TXTBOX_STYLE_TRANSBG          ( 1 <<  9 )
#define N_WIN_TXTBOX_STYLE_FLATBDR          ( 1 << 10 )
#define N_WIN_TXTBOX_STYLE_CMB_BDR          ( 1 << 11 )
#define N_WIN_TXTBOX_STYLE__DI_HDC          ( 1 << 12 )

#define N_WIN_TXTBOX_OPTION_LISTBOX_BOLDTXT ( 1 <<  0 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ( 1 <<  1 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ( 1 <<  2 )
#define N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ( 1 <<  3 )
#define N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ( 1 <<  4 )
#define N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ( 1 <<  5 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ( 1 <<  6 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ( 1 <<  7 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ( 1 <<  8 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ( 1 <<  9 )
#define N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ( 1 << 10 )
#define N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ( 1 << 11 )


typedef struct {

	// Instance : you can control via methods

	HWND    hwnd;
	WNDPROC pfunc;
	n_txt   txt, txt_undo;
	int     style, style_option;
	bool    is_static_ownerdraw;

	n_win_scrollbar vscr, hscr;

	s32     scroll_pxl_tabbed_x, scroll_cch_tabbed_y;
	s32     select_cch_x, select_cch_y, select_cch_sx, select_cch_sy;
	s32       undo_cch_x,   undo_cch_y,   undo_cch_sx,   undo_cch_sy;
	s32     offset_pxl_y;

	bool    partial_selection_onoff;
	bool     updown_selection_onoff;
	bool    reverse_selection_onoff;
	bool    line_min_onoff, line_max_onoff;
	s32     line_min_cch_x, line_max_cch_x;
	bool    undo_line_min_onoff, undo_line_max_onoff;
	s32     undo_line_min_cch_x, undo_line_max_cch_x;
	s32     smallbutton_margin;
	bool    undo_onoff;


	// Optional

	n_posix_char *placeholder;
	n_posix_char *tab_mark;
	n_posix_char *eol_mark;

	s32           tabstop;

	bool          mouse_input_stop_onoff;


	// Internal : auto-filled by the system

	HDC      hdc;
	POINT    ime;
	s32      scale;
	s32             hover_cch_x,        hover_cch_y;
	s32              drag_cch_x,         drag_cch_y;
	s32             font_pxl_sx,        font_pxl_sy;
	s32                                 cell_pxl_sy;
	s32             caret_pxl_x,        caret_pxl_y;
	s32            caret_pxl_sx,       caret_pxl_sy;
	s32           canvas_pxl_sx,      canvas_pxl_sy;
	s32      canvas_real_pxl_sx;
	s32      page_pxl_tabbed_sx, page_cch_tabbed_sy;
	s32      last_pxl_tabbed_sx, last_cch_tabbed_sy;
	s32      virtual_padding_pxl_sx;
	s32      txt_maxwidth_y;
	int      shift_dragging;
	bool     is_captured;
	bool     is_dragging;
	bool     is_caret_tail;
	bool     is_hovered_linenum;
	s32      empty_line_selection;
	bool     menu_onoff;

	int      focus_phase;
	bool     focus_phase_is_first;

	bool     oneline_cache_onoff;
	s32      oneline_cache_f;
	s32      oneline_cache_t;

	bool     is_font_monospace;
	SIZE     size_halfwidth;
	SIZE     size_fullwidth;

	s32      prv_scr_x,  prv_scr_y;
	s32      prv_txt_sx, prv_txt_sy;
	s32      prv_sel_x,  prv_sel_y;
	s32      prv_sel_sx, prv_sel_sy;
	s32      prv_drag;
	s32      prv_caret;
	n_bmp    prv_bmp;

	HMENU    hmenu_editbox;
	HMENU    hmenu_linenum;

	n_uxtheme uxtheme;


	// Metrics : once per session

	bool     is_9x;
	bool     is_nt;
	bool     is_2k_or_later;
	bool     is_classic;
	s32         number_pxl_sx, number_pad_pxl_sx;
	s32         client_pxl_sx,     client_pxl_sy;
	s32         border_pxl_sx,     border_pxl_sy;
	s32            pad_pxl_sx,        pad_pxl_sy;
	s32      scrollbar_pxl_sx,  scrollbar_pxl_sy;
	COLORREF color_base__padding;
	COLORREF color_base_selected;
	COLORREF color_back_selected;
	COLORREF color_text_selected;
	COLORREF color_back_noselect;
	COLORREF color_text_noselect;
	COLORREF color_back_striping;
	COLORREF color_text_tab_mark;
	COLORREF color_text_eol_mark;
	COLORREF color_caret_focused;
	COLORREF color_caret_nofocus;
	COLORREF color_text_backgrnd;
	COLORREF color_back_linenum1;
	COLORREF color_back_linenum2;
	COLORREF color_back_linenum3;
	COLORREF color_text_linenum1;
	COLORREF color_text_linenum2;
	COLORREF color___placeholder;
	COLORREF color___dwm_contour;
	COLORREF color___dwm_textclr;
	COLORREF color___ime_watcher;
	COLORREF color_back_disabled;
	COLORREF color_back__enabled;
	COLORREF color_border_normal;
	COLORREF color_border__focus;
	COLORREF color_border___flat;
	UINT     drawtext_modes;

	bool     drag_onoff;
	UINT     drag_timer;
	DWORD    drag_msec;

	bool     ime_onoff;
	bool     ime_composition_onoff;

	bool     caret_onoff;
	UINT     caret_timer;
	DWORD    caret_msec;

	bool     input_onoff;
	UINT     input_timer;
	DWORD    input_msec;


	// Debug Center

	bool   debug_onoff;
	n_bmp *debug_bmp;

} n_win_txtbox;

#define n_win_txtbox_zero( p ) n_memory_zero( p, sizeof( n_win_txtbox ) )




#define n_win_txtbox_hwndprintf(         p, f, ... ) n_win_hwndprintf( n_win_hwnd_toplevel( ( p )->hwnd ), f, ##__VA_ARGS__ )
#define n_win_txtbox_hwndprintf_literal( p, f, ... ) n_win_txtbox_hwndprintf( p, n_posix_literal( f ), ##__VA_ARGS__ )

void
n_win_txtbox_refresh( n_win_txtbox *p )
{

	n_win_refresh( p->hwnd, false );


	return;
}

void
n_win_txtbox_message_redirect( n_win_txtbox *p, HWND hwnd, UINT msg )
{

	if ( p->is_static_ownerdraw )
	{
		n_win_message_send(               hwnd  , WM_COMMAND, msg, p->hwnd );
	} else {
		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );
	}

	return;
}

// internal
void
n_win_txtbox_debug_count( n_win_txtbox *p )
{

	static int i = 0;

	n_win_txtbox_hwndprintf_literal( p, "%d", i );

	i++;

	return;
}

// internal
void
n_win_txtbox_box( n_win_txtbox *p, HDC hdc, RECT *rect, COLORREF color )
{

	if (
		( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		&&
		( n_gdi_doublebuffer_instance.bpp == 32 )
	)
	{

		s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

		if ( color == p->color_back_selected )
		{
			// [!] : for contour
			 x -= p->scale;
			sx += p->scale * 2;
		}

		int a = 222; if ( color == 0 ) { a = 0; }
		int r = GetRValue( color );
		int g = GetGValue( color );
		int b = GetBValue( color );

		n_bmp_box( &n_gdi_doublebuffer_instance.bmp, x,y,sx,sy, n_bmp_argb( a,r,g,b ) );

	} else {

		n_win_box( NULL, hdc, rect, color );

	}


	return;
}

// internal
void
n_win_txtbox_DrawText( n_win_txtbox *p, const n_posix_char *str, int cch, RECT *rect, int dt )
{

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{

#ifdef UNICODE
		n_posix_char *s = n_string_carboncopy ( str );
#else  // #ifdef UNICODE
		     wchar_t *s = n_posix_ansi2unicode( str ); cch = -1;
#endif // #ifdef UNICODE


		//uxtheme.DrawThemeText( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt,0, rect );

		{

			// [!] : Win8 or later : effect will be ignored

			DTTOPTS dttopts; ZeroMemory( &dttopts, sizeof( DTTOPTS ) );

			dttopts.dwSize  = sizeof( DTTOPTS );
			dttopts.dwFlags = DTT_COMPOSITED;

			dttopts.dwFlags = dttopts.dwFlags | DTT_TEXTCOLOR;
			dttopts.crText  = p->color___dwm_contour;

			s32 x = -p->scale;
			s32 y = -p->scale;
			while( 1 )
			{//break;

				if ( ( x == 0 )&&( y == 0 ) )
				{
					//
				} else {
					RECT r = { rect->left + x, rect->top + y, rect->right + x, rect->bottom + y };
					p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt, &r, &dttopts );
				}

				x++;
				if ( x > p->scale )
				{
					x = -p->scale;

					y++;
					if ( y > p->scale ) { break; }
				}
			}

			dttopts.crText = p->color___dwm_textclr;

			p->uxtheme.DrawThemeTextEx( p->uxtheme.htheme, p->hdc, 0,0, s,cch, dt, rect, &dttopts );

		}


		n_string_free( s );

	} else {

		DrawText( p->hdc, str, cch, rect, dt );

	}


	return;
}

// internal
void
n_win_txtbox_combo_border( n_win_txtbox *p, RECT *rect )
{

	// [!] : for N_WIN_TXTBOX_STYLE_CMB_BDR

	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, p->hwnd, L"COMBOBOX" );

	if ( false )//( uxtheme.onoff )
	{

		// [x] : TxtBox overwrites themed background

		int part  = CP_DROPDOWNBUTTON;//CP_BACKGROUND;
		int state = CBB_NORMAL;

		// [x] : currently auto-focus is not available
		if ( n_win_is_hovered( p->hwnd ) ) { state = CBB_FOCUSED; }

		uxtheme.DrawThemeBackground( uxtheme.htheme, p->hdc, part, state, rect, NULL );

	} else {

		COLORREF outer = p->color_border___flat;
		if ( n_win_is_hovered( p->hwnd ) ) { outer = p->color_base_selected; }

		n_win_txtbox_frame( p->hdc, rect, p->scale, outer );

		n_win_rect_resize( rect, -p->scale, -p->scale );

		n_win_txtbox_frame( p->hdc, rect, p->scale, p->color_back__enabled );

		//DrawEdge( p->hdc, rect, EDGE_ETCHED, BF_RECT );

	}

	n_uxtheme_exit( &uxtheme, p->hwnd );


	return;
}
// internal
int
n_win_txtbox_nonascii_single( n_win_txtbox *p, const n_posix_char *str )
{

	// [ Mechanism ]
	//
	//	ANSI version is not applicable
	//	ANSI is safe with CJK characters
	//
	//	Unicode version needs some trick
	//	but below code is not perfect


	int ret = 0;

#ifdef UNICODE

	SIZE size;

	if ( str[ 0 ] < 256 )
	{

		n_memory_copy( &p->size_halfwidth.cx, &size, sizeof( SIZE ) );

	} else {

		if ( n_win_txtbox_is_fullwidth( str[ 0 ] ) )
		{
			n_memory_copy( &p->size_fullwidth.cx, &size, sizeof( SIZE ) );
		} else {
			n_memory_copy( &p->size_halfwidth.cx, &size, sizeof( SIZE ) );
		}

	}

	if ( size.cx > p->size_halfwidth.cx ) { ret = 1; }

#endif // #ifdef UNICODE


	return ret;
}

// internal
void
n_win_txtbox_fastmode_check
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	               int *ret_cch,
	               int *ret_sx,
	              bool *ret_tab,
	              bool *ret_fast,
	              bool *ret_surrogatepair
)
{

	bool tab           = false;
	bool surrogatepair = false;


	int i = 0;
	int l = 0;
	int r = 0;
	while( 1 )
	{

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }


		if ( str[ i ] == N_STRING_CHAR_TAB )
		{
			tab = true;
		}


		if (
			( n_string_is_ascii( str, i ) )
			||
			( n_win_txtbox_is_fullwidth( str[ i ] ) )
		)
		{
			r++;
		}


		if (
			( n_unicode_surrogatepair_is_hi( str[ i + 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( str[ i + 1 ] ) )
		)
		{
			surrogatepair = true;
		}


		int nonascii = n_win_txtbox_nonascii_single( p, &str[ i ] );

		i++;
		l++;

		l += nonascii;

	}


	if ( ret_cch  != NULL ) { (*ret_cch  ) = i; }
	if ( ret_sx   != NULL ) { (*ret_sx   ) = l; }


	if ( ret_tab           != NULL ) { (*ret_tab          ) = tab;           }
	if ( ret_fast          != NULL ) { (*ret_fast         ) = ( i == r );    }
	if ( ret_surrogatepair != NULL ) { (*ret_surrogatepair) = surrogatepair; }


	return;
}

// internal
n_posix_char*
n_win_txtbox_tab2space
(
	      n_win_txtbox  *p, 
	const n_posix_char  *arg,
	               int   tabstop,
	               int  *ret_len,
	               int  *ret_sx,
	               bool *ret_tab_is_exist,
	               bool *ret_fastmode,
	               bool *ret_surrogatepair,
	               bool  ret_str_needed

)
{

	// [!] : this module based on n_string_tab2space()


	// [!] : you need to n_memory_free() a returned variable


	if ( arg == NULL )
	{

		if ( ret_len           != NULL ) { (*ret_len           ) =     0; }
		if ( ret_sx            != NULL ) { (*ret_sx            ) =     0; }
		if ( ret_tab_is_exist  != NULL ) { (*ret_tab_is_exist  ) = false; }
		if ( ret_fastmode      != NULL ) { (*ret_fastmode      ) =  true; }
		if ( ret_surrogatepair != NULL ) { (*ret_surrogatepair ) = false; }

		return NULL;
	}


	int len_f = 0;
	int len_l = 0;

	bool tab_is_exist = false;
	n_win_txtbox_fastmode_check( p, arg, &len_f, &len_l, &tab_is_exist, ret_fastmode, ret_surrogatepair );

	if ( ret_tab_is_exist != NULL ) { (*ret_tab_is_exist) = tab_is_exist; }

	if ( tab_is_exist == false )
	{
		if ( ret_len != NULL ) { (*ret_len) = len_f; }
		if ( ret_sx  != NULL ) { (*ret_sx ) = len_l; }

		if ( ret_str_needed )
		{
			return n_string_carboncopy_length( arg, len_f );
		} else {
			return NULL;
		}
	}


	// [!] : enough size

	if ( tabstop <= 0 ) { tabstop = 8; }

	int           len_t = len_f * tabstop;
	n_posix_char *s     = NULL;
	if ( ret_str_needed )
	{
		s = n_string_new_fast( len_t );
	}

	int i,ii, tab, line;

	i = ii = line = 0;
	while( 1 )
	{

		if ( arg[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( arg[ i ] == N_STRING_CHAR_TAB )
		{
//s[ii] = '_'; ii++;

			tab = tabstop - ( line % tabstop );

			while( 1 )
			{

				// [DEBUG] : use '_'

				if ( ret_str_needed )
				{
					s[ ii ] = N_STRING_CHAR_SPACE;
				}


				ii++; line++;
				if ( ii >= len_t ) { break; }

				tab--;
				if ( tab <= 0 ) { break; }
			}

		} else {

			if ( ret_str_needed )
			{
				s[ ii ] = arg[ i ];
			}

			line += n_win_txtbox_nonascii_single( p, &arg[ i ] );

			ii++; line++;
			if ( ii >= len_t ) { break; }
		}


		i++;

	}


	if ( ret_len != NULL ) { (*ret_len) = ii;   }
	if ( ret_sx  != NULL ) { (*ret_sx ) = line; }

	
	if ( ret_str_needed )
	{
		n_string_terminate( s, ii );
	}


	return s;
}

// internal
int
n_win_txtbox_nonascii( n_win_txtbox *p, const n_posix_char *str, int tabstop )
{

	int sx = 0; n_win_txtbox_tab2space( p, str, tabstop, NULL,&sx, NULL,NULL,NULL, false );


	return sx;
}

void
n_win_txtbox_vector_stream( n_win_txtbox *p, const n_posix_char *newline, bool calc_width )
{

	// [!] : this module based on n_vector_stream()


	if ( p == NULL ) { return; }


	int cch_newline = 0;
	if ( newline != NULL ) { cch_newline = n_posix_strlen( newline ); }


	size_t i, cch;


	if ( calc_width )
	{

		HDC   hdc = GetDC( p->hwnd );
		HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

		i = cch = p->txt.sx = 0;
		while( 1 )
		{

//n_posix_debug( p->txt.line[ i ] );

			n_posix_char *line = p->txt.line[ i ];

			size_t sx = n_win_txtbox_nonascii( p, line, p->tabstop );
			if ( newline != NULL ) { sx += cch_newline; }

			if ( p->txt.sx < sx ) { p->txt.sx = sx; p->txt_maxwidth_y = i; }


			cch += sx;


			i++;
			if ( i >= p->txt.sy ) { break; }
		}

		SelectObject( hdc, hf );
		ReleaseDC( p->hwnd, hdc );

	} else {

		i = cch = 0;
		while( 1 )
		{

//n_posix_debug( p->txt.line[ i ] );

			n_posix_char *line = p->txt.line[ i ];

			s32 sx = n_posix_strlen( line );
			if ( newline != NULL ) { sx += cch_newline; }


			cch += sx;


			i++;
			if ( i >= p->txt.sy ) { break; }
		}

	}

//n_posix_debug_literal( str, "%d : %d", p->txt.byte, cch * sizeof( n_posix_char ) );

	n_memory_free( p->txt.stream );

	p->txt.stream = n_string_new_fast( cch );
	p->txt.byte   = cch * sizeof( n_posix_char );


	n_posix_char *strm = (void*) p->txt.stream;


	i = cch = 0;
	while( 1 )
	{

		cch += n_posix_sprintf_literal( &strm[ cch ], "%s", (n_posix_char*) p->txt.line[ i ] );

		if ( newline != NULL )
		{
			cch += n_posix_sprintf_literal( &strm[ cch ], "%s", newline );
		}


		i++;
		if ( i >= p->txt.sy ) { break; }
	}


	return;
}

void
n_win_txtbox_txt_stream( n_win_txtbox *p, bool calc_width )
{

	// [!] : this module based on n_txt_stream()

	if ( p == NULL ) { return; }


	n_posix_char *newline = NULL;


	if ( p->txt.newline == N_TXT_NEWLINE_CR   ) { newline = N_STRING_CR;   } else
	if ( p->txt.newline == N_TXT_NEWLINE_LF   ) { newline = N_STRING_LF;   } else
	if ( p->txt.newline == N_TXT_NEWLINE_CRLF ) { newline = N_STRING_CRLF; }


	n_win_txtbox_vector_stream( p, newline, calc_width );


	return;
}

void
n_win_txtbox_txt_copy( n_win_txtbox *p, n_txt *p_old, n_txt *p_new, bool txt_stream_onoff )
{

	// [!] : this module based on n_txt_copy()

	if ( n_txt_error( p_old ) ) { return; }
	if ( p_new == NULL ) { return; }


	n_txt_new( p_new );


	size_t i = 0;
	while( 1 )
	{//break;

		// [!] : don't use n_txt_set()

		if ( i == 0 )
		{
			n_txt_mod( p_new, i, n_txt_get( p_old, i ) );
		} else {
			n_txt_add( p_new, i, n_txt_get( p_old, i ) );
		}

		i++;
		if ( i >= p_old->sy ) { break; }
	}


	p_new->newline  = p_old->newline;
	p_new->unicode  = p_old->unicode;
	p_new->readonly = p_old->readonly;

	if ( txt_stream_onoff ) { n_win_txtbox_txt_stream( p, true ); }


	return;
}

#define n_win_txtbox_vector_load(          p, fname        ) n_win_txtbox_vector_load_internal( p, (void*) fname,    0,  true )
#define n_win_txtbox_vector_load_onmemory( p, stream, byte ) n_win_txtbox_vector_load_internal( p,        stream, byte, false )

// internal
bool
n_win_txtbox_vector_load_internal( n_win_txtbox *p, void *stream, size_t byte, bool is_file )
{

	// [!] : this module based on n_vector_load_onmemory()


	// [!] : load_onmemory() : don't free "stream" after calling this function


	if ( p == NULL ) { return true; }


	if ( is_file )
	{

		FILE *fp = n_posix_fopen_read( stream );
		if ( fp == NULL ) { return true; }

		byte   = n_posix_stat_size( stream );
		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	}


	// [!] : add stream NUL
	//
	//	unicode : file size may have odd number byte

	{

		size_t unit = sizeof( n_posix_char );
		size_t pad  = ( byte % unit );
		size_t nul  = unit;


		// [!] : stream can be NULL

		stream = n_memory_resize( stream, byte + pad + nul );

		n_posix_char *s = stream;
		s[ ( byte + pad ) / unit ] = N_STRING_CHAR_NUL;

	}


	n_vector_free( (void*) &p->txt );


	size_t cch = byte / sizeof( n_posix_char );


	HDC   hdc = GetDC( p->hwnd );
	HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	size_t i = 0;
	while( 1 )
	{//break;

		size_t        sx = 0;
		n_posix_char *l  = n_vector_stream_enumline( stream, cch, &sx, &i );
		if ( l == NULL ) { break; }

		p->txt.sy++;
		p->txt.line = n_memory_resize( p->txt.line, p->txt.sy * sizeof( void** ) );

		p->txt.line[ p->txt.sy - 1 ] = l;

//n_posix_debug( v->line[ p->txt.sy - 1 ] );

		size_t line_sx = n_win_txtbox_nonascii( p, l, p->tabstop );
		if ( p->txt.sx < line_sx ) { p->txt.sx = line_sx; p->txt_maxwidth_y = p->txt.sy - 1; }

	}

	SelectObject( hdc, hf );
	ReleaseDC( p->hwnd, hdc );


	if ( p->txt.sy == 0 )
	{

		n_memory_free( stream );

		n_vector_new( (void*) &p->txt );

	} else {

		p->txt.stream = stream;
		p->txt.byte   = byte;

	}


	return false;
}

#define n_win_txtbox_txt_load(          v, fname        ) n_win_txtbox_txt_load_internal( v, (void*) fname,    0,  true )
#define n_win_txtbox_txt_load_onmemory( v, stream, byte ) n_win_txtbox_txt_load_internal( v,        stream, byte, false )

// internal
bool
n_win_txtbox_txt_load_internal( n_win_txtbox *p, void *stream, size_t byte, bool is_file )
{

	// [!] : this module based on n_txt_load_onmemory()


	// [!] : load_onmemory() : don't free "stream" after calling this function


	if ( p == NULL ) { return true; }


	size_t bom_offset = 0;


	p->txt.unicode = N_TXT_UNICODE_NIL;

	if ( is_file )
	{

		FILE *fp = n_posix_fopen_read( stream );
		if ( fp == NULL ) { return true; }

		byte = n_posix_stat_size( stream );

		if ( byte >= 3 )
		{

			u8 sniffer[ 3 ]; n_posix_fread( sniffer, 3, 1, fp );

			// [!] : remember original spec

			if ( n_unicode_bom_is_utf8   ( sniffer, 3 ) )
			{
				p->txt.unicode = N_TXT_UNICODE_UTF;
				n_posix_fseek( fp, 3, SEEK_SET );
				byte -= 3;
			} else
			if ( n_unicode_bom_is_utf16_le( sniffer, 2 ) )
			{
				p->txt.unicode = N_TXT_UNICODE_LIL;
				n_posix_fseek( fp, 2, SEEK_SET );
				byte -= 2;
			} else
			if ( n_unicode_bom_is_utf16_be( sniffer, 2 ) )
			{
				p->txt.unicode = N_TXT_UNICODE_BIG;
				n_posix_fseek( fp, 2, SEEK_SET );
				byte -= 2;
			} else {
				n_posix_fseek( fp, 0, SEEK_SET );
			}

		}

		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	} else {

		// [!] : remember original spec

		if ( n_unicode_bom_is_utf8   ( stream, byte ) )
		{
//n_posix_debug_literal( "UTF" );

			p->txt.unicode = N_TXT_UNICODE_UTF;

			bom_offset = 3;

		} else
		if ( n_unicode_bom_is_utf16_le( stream, byte ) )
		{
//n_posix_debug_literal( "LIL" );

			p->txt.unicode = N_TXT_UNICODE_LIL;

			bom_offset = 2;

		} else
		if ( n_unicode_bom_is_utf16_be( stream, byte ) )
		{
//n_posix_debug_literal( "BIG" );

			p->txt.unicode = N_TXT_UNICODE_BIG;

			bom_offset = 2;

		}

		byte -= bom_offset;

	}


	// [!] : add stream NUL
	//
	//	unicode : file size may have odd number byte

	{

		size_t unit = sizeof( n_posix_char );
		size_t pad  = ( byte % unit );
		size_t nul  = unit;


		// [!] : stream can be NULL

		stream = n_memory_resize( stream, byte + pad + nul );

		n_posix_char *s = stream;
		s[ ( byte + pad ) / unit ] = N_STRING_CHAR_NUL;

	}


	// Decoder

	char *ptr;
	bool  lost = false;

#ifdef UNICODE


	if ( p->txt.unicode == N_TXT_UNICODE_NIL )
	{

		// [!] : ANSI only : don't use n_txt_newline_check()

		bool binary = false;

		u8 *ptr_u8 = (u8*) stream;

		size_t i = 0;
		while( 1 )
		{

			if ( ptr_u8[ i ] == 0 ) { binary = true; break; }

			// [!] : some files have NUL at end of file

			i++;
			if ( i >= ( byte - 1 ) ) { break; }
		}


		if ( binary == false )
		{

			ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );
//MessageBoxA( NULL, (char*) ptr, "DEBUG", 0 );


			// [!] : false is returned always

			//lost = n_unicode_codec_char2wchar( ptr, byte );
			//n_unicode_bom_remove( ptr, byte );

			lost = n_unicode_codec_char2wchar_no_bom( ptr, byte );
//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );


			n_memory_free( stream );


			byte   = n_posix_strlen( (void*) ptr ) * sizeof( wchar_t );
			stream = ptr;

		}

	} else {

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( p->txt.unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		} else
		if ( p->txt.unicode == N_TXT_UNICODE_UTF )
		{
			n_unicode_utf8_decode_no_bom( ptr, byte );
		}


		n_memory_free( stream );

		//n_unicode_bom_remove( ptr, byte );

		byte   = n_posix_strlen( (void*) ptr ) * sizeof( n_posix_char );
		stream = ptr;

	}


#else // #ifdef UNICODE


	if ( p->txt.unicode != N_TXT_UNICODE_NIL )
	{

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( p->txt.unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		} else
		if ( p->txt.unicode == N_TXT_UNICODE_UTF )
		{
			n_unicode_utf8_decode_no_bom( ptr, byte );
		}


//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );

		lost = n_unicode_codec_wchar2char_no_bom( ptr, byte );

//MessageBoxA( NULL, ptr, "DEBUG", 0 );


		n_memory_free( stream );

		byte   = strlen( ptr );
		stream = ptr;

	}


#endif // #ifdef UNICODE


	p->txt.newline = n_txt_newline_check( stream, byte );

//n_posix_debug( stream );

	n_win_txtbox_vector_load_onmemory( p, stream, byte );

//n_posix_debug( p->txt.stream );


	if (
		( lost )
		||
		( p->txt.newline == N_TXT_NEWLINE_BINARY )
	)
	{
		p->txt.readonly = N_TXT_READONLY_ON;
	} else {
		p->txt.readonly = N_TXT_READONLY_OFF;
	}


	return false;
}

bool
n_win_txtbox_txt_save( n_win_txtbox *p, const n_posix_char *fname )
{

	// [!] : this module based on n_txt_save()

	if ( p == NULL ) { return true; }


	if ( p->txt.readonly ) { return true; }


	n_win_txtbox_txt_stream( p, false );


	return n_txt_save_main( &p->txt, fname );
}

// internal
n_posix_char*
n_win_txtbox_character
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	               s32  index,
	              SIZE *ret_size,
	               s32 *ret_cch,
	               s32 *ret_tab
)
{

	// [ Mechanism ]
	//
	//	call this module from begining of a string
	//
	//	index    : element counter
	//	ret_size : pixel metrics of returned string
	//	ret_cch  : tabbed character count
	//	ret_tab  : accumulated tabbed character count


	static n_posix_char character[ 10 ];

	if ( ret_size == NULL ) { n_string_truncate( character ); }


	s32 i = 0;
	s32 v = 0;

	s32  dbcs_cch = 0;

#ifndef UNICODE
	bool is_dbcs  = false;
#endif // #ifdef UNICODE


	if ( str[ index ] == N_STRING_CHAR_NUL )
	{

		n_string_truncate( character );

	} else
	if ( ( str[ index ] == N_STRING_CHAR_TAB )&&( ret_tab != NULL ) )
	{

		s32 tabstop = p->tabstop;
		if ( tabstop <= 0 ) { tabstop = 8; }

		const s32 tab = tabstop - ( (*ret_tab) % tabstop );

		if ( ret_size != NULL )
		{
			n_string_padding  ( character, N_STRING_CHAR_SPACE, tab );
			n_string_terminate( character, tab );
		}

		dbcs_cch = i = tab;

	} else {

		if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }

		v += n_win_txtbox_nonascii_single( p, &str[ index + i ] );

		if ( n_unicode_surrogatepair_is_hi( str[ index + i ] ) )
		{
			i++;
			if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }
		}


		i++;
		dbcs_cch++;


		if ( 2 == n_string_doublebyte_increment( str[ index ] ) )
		{
#ifndef UNICODE
			is_dbcs = true;
#endif // #ifdef UNICODE

			if ( ret_size != NULL ) { character[ i ] = str[ index + i ]; }
			i++;
		}


		if ( ret_size != NULL ) { character[ i ] = N_STRING_CHAR_NUL; }

	}


	if ( ret_size != NULL )
	{

		if ( p->is_font_monospace )
		{

			SIZE size;
#ifdef UNICODE
			if ( n_win_txtbox_is_fullwidth( character[ 0 ] ) )
#else  // #ifdef UNICODE
			if ( is_dbcs )
#endif // #ifdef UNICODE
			{
				size = p->size_fullwidth;
			} else {
				size = p->size_halfwidth;
			}

			size.cx *= dbcs_cch;

			if ( ret_size != NULL ) { (*ret_size) = size; }

		} else {

			GetTextExtentPoint32( p->hdc, character, i, ret_size );

		}

	}
	if ( ret_cch  != NULL ) { (*ret_cch)  = i;     }
	if ( ret_tab  != NULL ) { (*ret_tab) += i + v; }


	return character;
}

void
n_win_txtbox_character_tabbed
(
	      n_win_txtbox *p,
	const n_posix_char *str,
	s32 stop_x, s32 stop_cch, s32 stop_tab,
	s32 *ret_x, s32 *ret_cch, s32 *ret_tab
)
{

	s32   x = 0;
	s32 cch = 0;
	s32 tab = 0;
	while( 1 )
	{

		if ( str[ cch ] == N_STRING_CHAR_NUL ) { break; }

		if ( ( stop_x   != -1 )&&( x   >= stop_x   ) ) { break; }
		if ( ( stop_cch != -1 )&&( cch >= stop_cch ) ) { break; }
		if ( ( stop_tab != -1 )&&( tab >= stop_tab ) ) { break; }

		SIZE size; n_win_txtbox_character( p, str, cch, &size, NULL, &tab );

		s32 half = size.cx / 2;

		x   += half;
		if ( ( stop_x   != -1 )&&( x   >= stop_x   ) ) { break; }

		s32 step = n_string_doublebyte_increment( str[ cch ] );
		if ( ( step == 2 )&&( str[ cch + 1 ] == N_STRING_CHAR_NUL ) ) { break; }

		if (
			( n_unicode_surrogatepair_is_hi( str[ cch + 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( str[ cch + 1 ] ) )
		)
		{
			step = 2;
		}

		x   += half;
		cch += step;

	}


	if ( ret_x   != NULL ) { (*ret_x  ) =   x; }
	if ( ret_cch != NULL ) { (*ret_cch) = cch; }
	if ( ret_tab != NULL ) { (*ret_tab) = tab; }


	return;
}

// internal
inline SIZE
n_win_txtbox_size_text_fast( n_win_txtbox *p, HDC hdc, const n_posix_char *str )
{

	// [!] : don't use p->hdc : hang-up

	SIZE size;
	GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size );


	return size;
}

// internal
SIZE
n_win_txtbox_size_text( n_win_txtbox *p, const n_posix_char *str )
{

	HDC   hdc = GetDC( p->hwnd );
	HFONT pf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	SIZE size = n_win_txtbox_size_text_fast( p, hdc, str );

	SelectObject( hdc, pf );
	ReleaseDC( p->hwnd, hdc );


	return size;
}

void
n_win_txtbox_ime_watch_color( n_win_txtbox *p )
{

	if ( p->ime_onoff )
	{
		p->color_back_selected = p->color___ime_watcher;
	} else {
		p->color_back_selected = p->color_border__focus;
	}

	// [ Mechanism ]
	//
	//	.color_back_linenum1	background color
	//	.color_back_linenum2	selected color
	//	.color_back_linenum3	indicator color
	//
	//	.color_text_linenum2	selected text color

	double ratio; if ( n_win_darkmode_onoff ) { ratio = 0.25; } else { ratio = 0.10; }
	p->color_back_striping = n_win_color_blend( p->color_back_noselect, p->color_back_selected, ratio );
	p->color_back_linenum1 = p->color_back_striping;
	p->color_back_linenum2 = n_win_color_blend( p->color_back_linenum1, p->color_back_selected, 0.25  );
	p->color_back_linenum3 = p->color_back_selected;
	p->color_text_linenum2 = n_win_color_blend( p->color_text_noselect, p->color_back_linenum2, 0.50  );

	p->color_text_tab_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50  );
	p->color_text_eol_mark = n_win_color_blend( p->color_back_noselect, p->color_back_selected, 0.50  );


	return;
}

void
n_win_txtbox_on_setcursor( n_win_txtbox *p )
{

	// [x] : static ownerdraw and disabled controls are excluded;

	HWND hwnd = NULL;
/*
	if ( hwnd != NULL )
	{
		if ( p->hwnd != n_win_cursor2hwnd_relative( GetParent( p->hwnd ) ) )
		{
			n_win_cursor_add( hwnd, IDC_ARROW );
			return;
		}
	}
*/
	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );

	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM )
	{

		n_win_cursor_add( hwnd, IDC_ARROW );
/*
		// [!] : no ibeam when normal, ibeam when IME is ON

		extern bool n_win_txtbox_is_hovered( n_win_txtbox* );

		if (
			( p->ime_onoff )
			&&
			( p->menu_onoff == false )
			&&
			( p->is_hovered_linenum == false )
			&&
			( n_win_txtbox_is_hovered( p ) )
			&&
			( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
		)
		{
			n_win_cursor_add( hwnd, IDC_IBEAM );
		} else {
			n_win_cursor_add( hwnd, IDC_ARROW );
		}
*/
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 0 " );

		extern bool n_win_txtbox_is_hovered( n_win_txtbox* );

		bool is_hovered = n_win_txtbox_is_hovered( p );

		if ( p->menu_onoff )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else
		if ( is_hovered == false )
		{

			n_win_cursor_add( hwnd, IDC_ARROW );

		} else {

			if (
				( p->smallbutton_margin == 0 )
				||
				( false == IsWindowVisible( n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) ) )
			)
			{
//n_posix_debug_literal( " 1 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			} else

			if (
				( p->menu_onoff         == false )
				&&
				( p->is_hovered_linenum == false )
				&&
				( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
			)
			{
//n_posix_debug_literal( " 2 " );
				n_win_cursor_add( hwnd, IDC_IBEAM );
			}

		}

	}


	return;
}

void
n_win_txtbox_ime_watch( n_win_txtbox *p )
{

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return; }
	if ( p->txt.readonly ) { return; }


	p->ime_onoff = n_win_ime_is_on( p->hwnd );

	n_win_txtbox_ime_watch_color( p );
	n_win_txtbox_refresh( p );

	n_win_txtbox_on_setcursor( p );


	return;
}

void
n_win_txtbox_grayed( n_win_txtbox *p, bool onoff )
{

	if ( p == NULL ) { return; }


	if ( onoff )
	{
		p->color_back_noselect = p->color_back_disabled;
	} else {
		p->color_back_noselect = p->color_back__enabled;
	}

	n_win_txtbox_refresh( p );


	return;
}

void
n_win_txtbox_caret_onoff( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->caret_onoff = true;


	return;
}

#define n_win_txtbox_on_settingchange( p ) n_win_txtbox_metrics( p )

// internal
void
n_win_txtbox_metrics( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// Compatibility

	p->is_9x          = n_sysinfo_version_9x();
	p->is_nt          = n_sysinfo_version_nt();
	p->is_2k_or_later = n_sysinfo_version_2000_or_later();
	p->is_classic     = n_win_style_is_classic();

	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"EDIT" );


	// Border

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 1;
	} else {
		p->border_pxl_sx = p->border_pxl_sy = 2;
	}


	// Padding

	s32 m; n_win_stdsize( p->hwnd, NULL, NULL, &m );

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG )
	{

		p->       pad_pxl_sx = 0;
		p->       pad_pxl_sy = 0;
		p->number_pad_pxl_sx = 0;

	} else {

		p->       pad_pxl_sx = m * 2;
		p->       pad_pxl_sy = m * 2;
		p->number_pad_pxl_sx = m * 2;

	}


	// Tabstop

	p->tabstop = 8;


	// Scrollbar

	p->scrollbar_pxl_sx = GetSystemMetrics( SM_CXVSCROLL );
	p->scrollbar_pxl_sy = GetSystemMetrics( SM_CYHSCROLL );

	n_win_scrollbar_on_settingchange( &p->hscr, true );
	n_win_scrollbar_on_settingchange( &p->vscr, true );


	// IME : for future version

	n_win_txtbox_ime_watch( p );


	// Color Scheme

	p->color_base_selected = n_win_darkmode_systemcolor( COLOR_HIGHLIGHT     );
	p->color_base__padding = n_win_darkmode_systemcolor( COLOR_BTNFACE       );

	p->color_text_selected = n_win_darkmode_systemcolor( COLOR_HIGHLIGHTTEXT );
	p->color_back_noselect = n_win_darkmode_systemcolor( COLOR_WINDOW        );
	p->color_text_noselect = n_win_darkmode_systemcolor( COLOR_WINDOWTEXT    );

	p->color_border___flat = n_win_darkmode_systemcolor( COLOR_BTNSHADOW     );

	p->color_back__enabled = p->color_back_noselect;

	if ( n_win_darkmode_onoff )
	{
		p->color_border__focus = n_win_darkmode_systemcolor( COLOR_HIGHLIGHT     );
		p->color_border_normal = n_win_darkmode_systemcolor( COLOR_BTNSHADOW     );
		p->color_back_disabled = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.75 );
		p->color___ime_watcher = GetSysColor( COLOR_HIGHLIGHT );
	} else {
		p->color_border__focus = p->color_base_selected;
		p->color_border_normal = p->color_base_selected;
		p->color_back_disabled = p->color_base__padding;
		p->color___ime_watcher = n_win_txtbox_color_hue_tweak( p->color_base_selected, 64 );
	}


	p->color_caret_focused = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.20 );
	p->color_caret_nofocus = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.80 );
	p->color_text_linenum1 = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.50 );

	p->color___placeholder = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.50 );

	n_win_txtbox_ime_watch_color( p );


	// DrawText modes

	p->drawtext_modes = DT_NOPREFIX | DT_NOCLIP;
	p->drawtext_modes = p->drawtext_modes | ( DT_SINGLELINE | DT_VCENTER );


	// Timer

	if ( p-> drag_timer == 0 ) { p-> drag_timer = n_win_timer_id_get(); }
	if ( p->caret_timer == 0 ) { p->caret_timer = n_win_timer_id_get(); }
	if ( p->input_timer == 0 ) { p->input_timer = n_win_timer_id_get(); }

	n_win_txtbox_caret_onoff( p );

	p-> drag_msec = 33;
	p->caret_msec = GetCaretBlinkTime();
	p->input_msec = GetCaretBlinkTime();


	return;
}

// internal
void
n_win_txtbox_metrics_caret( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->caret_pxl_sx = n_win_stdsize_caret( p->hwnd );
	p->caret_pxl_sy = p->cell_pxl_sy;

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		p->caret_pxl_sy += ( p->canvas_pxl_sy - p->cell_pxl_sy ) / 2;
	}


	return;
}

// internal
void
n_win_txtbox_metrics_canvas( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// Font

	// [!] : Win95 : font height has larger size than set value
	//
	//	example : 16px at CreateFont() will be 18px

	{
		SIZE size = n_win_txtbox_size_text( p, n_posix_literal( "W" ) );

		p->font_pxl_sx = n_posix_max_s32( 1, size.cx );
		p->font_pxl_sy = n_posix_max_s32( 1, size.cy );

		if ( p->cell_pxl_sy == 0 )  { p->cell_pxl_sy = p->font_pxl_sy; }
	}

	{
		SIZE size = n_win_txtbox_size_text( p, n_posix_literal( "i" ) );

		size.cx = n_posix_max( 1, size.cx );

		if ( size.cx == p->font_pxl_sx ) { p->is_font_monospace = true; }
	}


	SIZE halfwidth = { p->font_pxl_sx * 1, p->cell_pxl_sy };
	SIZE fullwidth = { p->font_pxl_sx * 2, p->cell_pxl_sy };

	p->size_halfwidth = halfwidth;
	p->size_fullwidth = fullwidth;


	// Caret

	n_win_txtbox_metrics_caret( p );


	// Canvas

	n_win_size( p->hwnd, &p->client_pxl_sx, &p->client_pxl_sy );

	s32 sx = p->client_pxl_sx - ( p->pad_pxl_sx * 2 );
	s32 sy = p->client_pxl_sy - ( p->pad_pxl_sy * 2 );

	// [Patch] : currently reason is unknown
	sx--;

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }
	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx; }


	s32 linenum = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	)
	{
		SIZE size_linenum = n_win_txtbox_size_text( p, n_posix_literal( " 0000 " ) );
		p->number_pxl_sx = size_linenum.cx;
		linenum          = size_linenum.cx + p->number_pad_pxl_sx;
	}

	p->canvas_pxl_sx = n_posix_max_s32( 0, sx );
	p->canvas_pxl_sy = n_posix_max_s32( 0, sy );

	p->canvas_real_pxl_sx = p->canvas_pxl_sx - linenum - p->smallbutton_margin;

	if ( p->is_font_monospace )
	{
		p->page_pxl_tabbed_sx = p->canvas_real_pxl_sx / p->font_pxl_sx * p->font_pxl_sx;
		p->last_pxl_tabbed_sx = n_posix_max_s32( 0, ( p->txt.sx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx + p->smallbutton_margin );
	} else {
		SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->txt_maxwidth_y ) );
		p->page_pxl_tabbed_sx = p->canvas_real_pxl_sx;
		p->last_pxl_tabbed_sx = size.cx - p->page_pxl_tabbed_sx + p->smallbutton_margin;
	}

	p->page_cch_tabbed_sy = p->canvas_pxl_sy / n_posix_max_s32( 1, p->cell_pxl_sy );
	p->last_cch_tabbed_sy = n_posix_max_s32( 0, p->txt.sy - p->page_cch_tabbed_sy );


	return;
}

void
n_win_txtbox_metrics_vertical_scpacing( n_win_txtbox *p, s32 value )
{

	if ( p == NULL ) { return; }


	p->cell_pxl_sy = value;


	n_win_txtbox_metrics_caret ( p );
	n_win_txtbox_metrics_canvas( p );


	//n_win_txtbox_refresh( p );


	return;
}

#define n_win_txtbox_metrics_maxwidth_all( p ) n_win_txtbox_metrics_maxwidth( p, 0, N_WIN_TXTBOX_ALL )

void
n_win_txtbox_metrics_maxwidth( n_win_txtbox *p, s32 y, s32 sy )
{

	if ( p == NULL ) { return; }


	bool redraw = false;


	HDC   hdc = GetDC( p->hwnd );
	HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	s32 max_sy = y + sy;
	while( 1 )
	{

		size_t sx = n_win_txtbox_nonascii( p, n_txt_get( &p->txt, y ), p->tabstop );
		if ( p->txt.sx < sx )
		{
//n_posix_debug_literal( "%d : %s", sx, n_txt_get( &p->txt, y ) );
			redraw    = true;
			p->txt.sx = sx;
		}

		y++;
		if ( y >= max_sy ) { break; }
	}

	SelectObject( hdc, hf );
	ReleaseDC( p->hwnd, hdc );


	p->cell_pxl_sy = 0;
	n_win_txtbox_metrics_canvas( p );


	if ( redraw ) { n_win_txtbox_refresh( p ); }


	return;
}

void
n_win_txtbox_line_minmax_reset( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->line_min_cch_x = N_WIN_TXTBOX_NOT_SELECTED;
	p->line_max_cch_x = N_WIN_TXTBOX_NOT_SELECTED;

	p->line_min_onoff = false;
	p->line_max_onoff = false;


	return;
}

void
n_win_txtbox_tabbedmetrics
(
	n_win_txtbox *p,
	int           line_index,
	s32 stop_x, s32 stop_cch, s32 stop_tab,
	s32 *ret_x, s32 *ret_cch, s32 *ret_tab
)
{

	if ( p == NULL ) { return; }


	      p->hdc = GetDC( p->hwnd );
	HFONT hf     = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );

	n_posix_char *str_line = n_txt_get( &p->txt, line_index );

	n_win_txtbox_character_tabbed( p, str_line, stop_x, stop_cch, stop_tab, ret_x, ret_cch, ret_tab );

	SelectObject( p->hdc, hf );
	ReleaseDC( p->hwnd, p->hdc );
	p->hdc = NULL;


	return;
}

bool
n_win_txtbox_is_selected( n_win_txtbox *p )
{

	if ( p == NULL ) { return false; }


	if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { return true; }
	if ( p->select_cch_sy == N_WIN_TXTBOX_ALL ) { return true; }

	if ( p->select_cch_sx > 0 ) { return true; }
	if ( p->select_cch_sy > 1 ) { return true; }


	return false;
}

bool
n_win_txtbox_is_highlighted_main( n_win_txtbox *p, s32 x, s32 y )
{

	if ( p == NULL ) { return false; }


	s32 sx = p->select_cch_sx;
	s32 sy = p->select_cch_sy;

	if ( sx == 0 ) { return false; }
	if ( sy == 0 ) { return false; }

	if ( sx == N_WIN_TXTBOX_ALL ) { sx = x + 1; }
	if ( sy == N_WIN_TXTBOX_ALL ) { sy = y + 1; }


	s32 fx = p->select_cch_x;
	s32 fy = p->select_cch_y;
	s32 tx = p->select_cch_x + sx - 1;
	s32 ty = p->select_cch_y + sy - 1;

	if (
		( ( fx <= x )&&( x <= tx ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		return true;
	}

	if (
		( ( y != fy )&&( y != ty ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		if (
			( p->line_min_onoff )
			||
			( p->line_max_onoff )
		)
		{
			return true;
		}
	}


	return false;
}

bool
n_win_txtbox_is_highlighted( n_win_txtbox *p, s32 x, s32 y )
{

	if ( p == NULL ) { return false; }


	if ( y == p->select_cch_y )
	{
//n_win_txtbox_hwndprintf_literal( p, " Min " );

		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{

			if ( p->line_min_cch_x <= x )
			{
				return true;
			}

		} else {

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else
	if ( y == ( p->select_cch_y + p->select_cch_sy - 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Max " );

		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{

			if ( p->line_max_cch_x > x )
			{
				return true;
			}

		} else {

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else {
//n_win_txtbox_hwndprintf_literal( p, " N/A " );

		return n_win_txtbox_is_highlighted_main( p, x,y );

	}


	return false;
}

void
n_win_txtbox_scroll_get( n_win_txtbox *p, s32 *x, s32 *y )
{

	if ( p == NULL ) { return; }

	if ( x != NULL ) { (*x) = p->scroll_pxl_tabbed_x / p->font_pxl_sx; }
	if ( y != NULL ) { (*y) = p->scroll_cch_tabbed_y; }


	return;
}

#define n_win_txtbox_scroll( p, x,y ) n_win_txtbox_scroll_set( p, x,y, true )

void
n_win_txtbox_scroll_set( n_win_txtbox *p, s32 x, s32 y, bool clamp_onoff )
{

	if ( p == NULL ) { return; }


	// [Needed] : set default

	p->scroll_pxl_tabbed_x = p->scroll_cch_tabbed_y = 0;


	if ( clamp_onoff )
	{

		if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		{

			p->scroll_pxl_tabbed_x = n_posix_minmax( 0, p->last_pxl_tabbed_sx, x );

			if ( p->is_font_monospace )
			{
				p->scroll_pxl_tabbed_x = p->scroll_pxl_tabbed_x / p->font_pxl_sx * p->font_pxl_sx;
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				p->hscr.unit_pos = p->scroll_pxl_tabbed_x;
			}
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			p->scroll_cch_tabbed_y = n_posix_minmax( 0, p->last_cch_tabbed_sy, y );

			p->vscr.unit_pos = p->scroll_cch_tabbed_y * p->cell_pxl_sy;

//n_win_txtbox_hwndprintf_literal( p, " %d ", (int) p->vscr.unit_pos );
		}

	} else {

		if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		{
			p->scroll_pxl_tabbed_x = x;

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				p->hscr.unit_pos = p->scroll_pxl_tabbed_x;
			}
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			p->scroll_cch_tabbed_y = y;

			p->vscr.unit_pos = p->scroll_cch_tabbed_y;
		}

	}


	return;
}

void
n_win_txtbox_autofocus( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_metrics_canvas( p );


	//p->scroll_pxl_tabbed_x = p->select_cch_x - ( p->page_pxl_tabbed_sx / 2 );
	p->scroll_cch_tabbed_y = p->select_cch_y - ( p->page_cch_tabbed_sy / 2 );
//n_posix_debug_literal( " %d : %d : %d ", p->scroll_cch_tabbed_y, p->select_cch_y, p->page_cch_tabbed_sy );


	s32 sel_x  = p->select_cch_x;
	s32 sel_y  = p->select_cch_y;
	s32 sel_sx = p->select_cch_sx;

	s32 txt_fx = 0; n_win_txtbox_tabbedmetrics( p, sel_y, -1,sel_x,-1, NULL,NULL,&txt_fx );
	s32 txt_tx = txt_fx + sel_sx;
	s32 scr_fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	s32 scr_tx = scr_fx + ( p->page_pxl_tabbed_sx / p->font_pxl_sx );

	if (
		( txt_fx < scr_fx )
		||
		( txt_tx > scr_tx )
	)
	{
		p->scroll_pxl_tabbed_x = ( txt_tx * p->font_pxl_sx ) - ( p->page_pxl_tabbed_sx / 2 );
	}


	// [Needed] : clamp when resized

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );


	// [!] : some functions rewrite position for calling through WM_COMMAND

	p->hscr.unit_pos = 0;
	p->vscr.unit_pos = 0;

	extern void n_win_txtbox_draw_scrollbars( n_win_txtbox *p, bool mask );
	n_win_txtbox_draw_scrollbars( p, false );
//n_posix_debug_literal( " %f ", p->vscr.unit_pos );


	// [Needed] : Win9x : reason is unknown

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_refresh( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_refresh( &p->vscr );
	}


	return;
}

void
n_win_txtbox_select_get( n_win_txtbox *p, s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	if ( p == NULL ) { return; }

	if (  x != NULL ) { (* x) = p->select_cch_x;  }
	if (  y != NULL ) { (* y) = p->select_cch_y;  }
	if ( sx != NULL ) { (*sx) = p->select_cch_sx; }
	if ( sy != NULL ) { (*sy) = p->select_cch_sy; }


	return;
}

#define n_win_txtbox_select( p, x,y,sx,sy ) n_win_txtbox_select_set( p, x,y,sx,sy, true )

void
n_win_txtbox_select_set( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy, bool clamp_onoff )
{

	if ( p == NULL ) { return; }

	if ( clamp_onoff )
	{

		if ( sy == N_WIN_TXTBOX_ALL ) { sy = p->txt.sy; }

		p->select_cch_y  = n_posix_minmax( 0, p->txt.sy -               1,  y );
		p->select_cch_sy = n_posix_minmax( 0, p->txt.sy - p->select_cch_y, sy );


		// [!] : the last character is accessible

		s32 cch = p->txt.sx;
		if ( sy <= 1 ) { cch = n_posix_strlen( n_txt_get( &p->txt, p->select_cch_y ) ); }

		if ( sx == N_WIN_TXTBOX_ALL ) { sx = cch; }

		p->select_cch_x  = n_posix_minmax( 0, cch,                    x );
		p->select_cch_sx = n_posix_minmax( 0, cch - p->select_cch_x, sx );

	} else {

		p->select_cch_x  = x;
		p->select_cch_y  = y;
		p->select_cch_sx = sx;
		p->select_cch_sy = sy;

	}


	return;
}

void
n_win_txtbox_select_search( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_select( p, x, y, sx, sy );

	p->shift_dragging = VK_RIGHT;


	return;
}

s32
n_win_txtbox_select_tail_get( n_win_txtbox *p )
{

	if ( p == NULL ) { return 0; }


	n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
	s32           cch  = n_posix_strlen( line );

	if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { p->select_cch_sx = cch; }
	p->select_cch_sx = n_posix_minmax( 0, cch - p->select_cch_x, p->select_cch_sx );
 

	return p->select_cch_x + p->select_cch_sx;
}

void
n_win_txtbox_select_tail_set( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
	s32           cch  = n_posix_strlen( line );

	p->select_cch_sx = 0;
	p->select_cch_x  = cch;

	n_win_txtbox_scroll( p, cch * p->font_pxl_sx, p->scroll_cch_tabbed_y );


	return;
}

void
n_win_txtbox_select_word( n_win_txtbox *p, s32 x, s32 y, s32 *from, s32 *to )
{

	n_posix_char *line = n_txt_get( &p->txt, y );

	if ( line[ x ] == N_STRING_CHAR_NUL ) { x = n_posix_max_s32( 0, x - 1 ); }

	s32 f = x;
	s32 t = x;

	bool is_blank = n_string_char_is_blank( line[ f ] );

	while( 1 )
	{

		bool b = n_string_char_is_blank( line[ f ] );

		if ( is_blank )
		{
			if ( b == false ) { f++; break; }
		} else {
			if ( b != false ) { f++; break; }
		}

		f--;
		if ( f < 0 ) { f = 0; break; }
	}

	while( 1 )
	{

		if ( line[ t ] == N_STRING_CHAR_NUL ) { break; }

		bool b = n_string_char_is_blank( line[ t ] );

		if ( is_blank )
		{
			if ( b == false ) { break; }
		} else {
			if ( b != false ) { break; }
		}

		t++;
	}

//n_win_txtbox_hwndprintf_literal( p, "%d : %d %d", x, f,t );

	if ( from != NULL ) { (*from) = f; }
	if ( to   != NULL ) { (*to  ) = t; }


	return;
}

#define n_win_txtbox_select_up(   p, x,y ) n_win_txtbox_select_updown( p, x,y,  true )
#define n_win_txtbox_select_down( p, x,y ) n_win_txtbox_select_updown( p, x,y, false )

s32
n_win_txtbox_select_updown( n_win_txtbox *p, s32 x, s32 y, bool is_up )
{

	if ( p == NULL ) { return 0; }
	if ( x ==    0 ) { return 0; }


	s32 delta; if ( is_up ) { delta = -1; } else { delta = 1; }


	s32 f = 0; n_win_txtbox_tabbedmetrics( p, y        , -1,  x, -1,   &f, NULL, NULL );
	s32 t = 0; n_win_txtbox_tabbedmetrics( p, y + delta,  f, -1, -1, NULL,   &t, NULL );


	return t;
}

void
n_win_txtbox_unselect( n_win_txtbox *p )
{

	// [Needed] : partial selection

	//if ( false == n_win_txtbox_is_selected( p ) ) { return; }


//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );

	if ( p->shift_dragging == VK_LEFT  )
	{
		//
		p->select_cch_y += p->select_cch_sy - 1;
	} else
	if ( p->shift_dragging == VK_RIGHT )
	{
		p->select_cch_x += p->select_cch_sx;
		p->select_cch_y += p->select_cch_sy - 1;
	} else
	if ( p->shift_dragging == VK_UP    )
	{
		//
		//
	} else
	if ( p->shift_dragging == VK_DOWN  )
	{
		p->select_cch_x += p->select_cch_sx;
		p->select_cch_y += p->select_cch_sy;
	}

	p->select_cch_sx = 0;
	p->select_cch_sy = 1;

	p->shift_dragging = p->prv_drag = 0;

	n_win_txtbox_line_minmax_reset( p );


	return;
}

void
n_win_txtbox_select2drag( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }

	p->drag_cch_x = p->select_cch_x;
	p->drag_cch_y = p->select_cch_y;

	return;
}

bool
n_win_txtbox_drag_scroll( n_win_txtbox *p )
{

	bool done = false;


	if ( p == NULL ) { return done; }


	s32 stop_sx = p->select_cch_x;
	if ( ( p->shift_dragging == VK_RIGHT )&&( p->select_cch_sx > 0 ) ) { stop_sx += p->select_cch_sx; }

	s32 y = p->select_cch_y;
	if ( ( p->shift_dragging == VK_DOWN )&&( p->select_cch_sy > 1 ) ) { y += p->select_cch_sy - 1; }

	s32 tsx = ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx ) / p->font_pxl_sx;

	s32 tabbed_sx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,p->hover_cch_x,-1, NULL,NULL,&tabbed_sx );
	if (
		( ( p->shift_dragging == VK_UP )||( p->shift_dragging == VK_DOWN ) )
		&&
		( tabbed_sx >= tsx )
	)
	{
		stop_sx = tabbed_sx;
	}

	s32 fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	s32 tx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,stop_sx,-1, NULL,NULL,&tx );
	s32 fy = p->scroll_cch_tabbed_y;
	s32 ty = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy;


	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		if ( p->hover_cch_y <  fy )
		{
//n_win_txtbox_hwndprintf_literal( p, " Up : %d ", ty );

			done              = true;
			p->shift_dragging = VK_UP;

			n_win_txtbox_scroll( p, fx, p->hover_cch_y );

		} else
		if ( p->hover_cch_y >= ty )
		{
//n_win_txtbox_hwndprintf_literal( p, " Down : %d ", ty );

			done              = true;
			p->shift_dragging = VK_DOWN;

			n_win_txtbox_scroll( p, fx, p->hover_cch_y - p->page_cch_tabbed_sy + 1 );

		}

	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{

		// [Needed] : for combination x and y

		fy = p->scroll_cch_tabbed_y;

		if ( tx >= tsx )
		{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", tx );

			if ( p->is_font_monospace )
			{

				done              = true;
				p->shift_dragging = VK_RIGHT;

				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx, fy );

			} else {

				if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->caret_pxl_x > p->canvas_real_pxl_sx ) )
				{
					done              = true;
					p->shift_dragging = VK_RIGHT;

					s32 osx = p->caret_pxl_x - p->canvas_real_pxl_sx;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + osx, p->scroll_cch_tabbed_y );
				} else
				if ( ( p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx ) ) > p->canvas_real_pxl_sx )
				{
					done              = true;
					p->shift_dragging = VK_RIGHT;

					s32 osx = ( p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx ) ) - p->canvas_real_pxl_sx;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + osx, p->scroll_cch_tabbed_y );
				}

			}

		} else
		if ( fx > tx )
		{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", tx );

			done              = true;
			p->shift_dragging = VK_LEFT;

			n_posix_char *line = n_txt_get( &p->txt, y );

			s32 tmp_x = 0; n_win_txtbox_tabbedmetrics( p, y, -1,-1,fx, NULL,&tmp_x,NULL );
			s32     l = 0; n_win_txtbox_caret_l( line, tmp_x, &l );
			s32 tmp   = 0; n_win_txtbox_tabbedmetrics( p, y, -1, l,-1, &tmp,  NULL,NULL );

			n_win_txtbox_scroll( p, tmp, fy );

		}

	}


	return done;
}

void
n_win_txtbox_drag( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	s32  x = n_posix_minmax( 0, p->txt.sx, p->hover_cch_x );
	s32  y = n_posix_minmax( 0, p->txt.sy, n_posix_min_s32( p->hover_cch_y, p->drag_cch_y ) );
	s32 sx = 0;
	s32 sy = n_posix_minmax( 0, p->txt.sy - y, 1 + abs( n_posix_max_s32( 0, p->hover_cch_y ) - p->drag_cch_y ) );


	n_posix_char *line = n_txt_get( &p->txt, y );

	if ( p->drag_cch_x == x )
	{
//n_win_txtbox_hwndprintf_literal( p, " Stopped " );

		p->shift_dragging = 0;

	} else
	if ( p->drag_cch_x < x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT " );

		p->shift_dragging = VK_RIGHT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	} else
	if ( p->drag_cch_x > x )
	{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT " );

		p->shift_dragging = VK_LEFT;

		n_win_txtbox_caret_m( line, x, &x );

		sx = abs( x - p->drag_cch_x );
		 x = n_posix_min_s32( x, p->drag_cch_x );

	}


	if ( sy <= 1 )
	{

		n_win_txtbox_line_minmax_reset( p );

	} else {
//n_win_txtbox_hwndprintf_literal( p, " %d : %d : %d : %d ", sy, x, p->select_cch_x, p->line_min_cch_x );
//if ( y != p->select_cch_y ) { n_win_txtbox_hwndprintf_literal( p, " ! " ); }

		 x = 0;
		sx = N_WIN_TXTBOX_ALL;

		if ( p->drag_cch_y < p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN " );

			p->shift_dragging = VK_DOWN;

			if ( p->partial_selection_onoff )
			{

				if ( p->line_min_onoff == false )
				{
					p->line_min_onoff = true;
					p->line_min_cch_x = p->drag_cch_x;
				}

				p->line_max_cch_x = p->hover_cch_x;

//n_win_txtbox_hwndprintf_literal( p, " Min " );

				if ( y == p->select_cch_y )
				{
					 x = 0;
					sx = p->hover_cch_x;
				}

			}

		} else
		if ( p->drag_cch_y > p->hover_cch_y )
		{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP " );

			p->shift_dragging = VK_UP;

			if ( p->partial_selection_onoff )
			{

				p->line_min_cch_x = p->hover_cch_x;

				if ( p->line_max_onoff == false )
				{
					p->line_max_onoff = true;
					p->line_max_cch_x = p->drag_cch_x;
				}

//n_win_txtbox_hwndprintf_literal( p, " Max : %d %d ", y, ( p->select_cch_y + p->select_cch_sy - 1 ) );

				if ( y == p->select_cch_y )
				{
					 x = p->hover_cch_x;
					sx = N_WIN_TXTBOX_ALL;
				}

			}

		}

		if ( p->partial_selection_onoff )
		{
			if ( sx == 0 )
			{
				 x = 0;
				sx = N_WIN_TXTBOX_ALL;
			}
		}

	}
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );


	n_win_txtbox_select_set( p, x, y, sx, sy, false );
	n_win_txtbox_drag_scroll( p );
	//n_win_txtbox_select2drag( p );


	return;
}

#define n_win_txtbox_line_cur(    p    ) ( ( p )->select_cch_y )
#define n_win_txtbox_line_max(    p    ) ( ( p )->txt.sy   )
#define n_win_txtbox_line_scroll( p, y ) n_win_txtbox_scroll( p, ( p )->scroll_pxl_tabbed_x, y )

bool
n_win_txtbox_line_select( n_win_txtbox *p, s32 y )
{

	if ( p == NULL ) { return true; }


	bool ret = false;


	if ( ( y < 0 )||( y >= (s32) p->txt.sy ) )
	{

		if (
			( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
			&&
			( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL )
		)
		{
			//
		} else {
			p->select_cch_x  = 0;
			p->select_cch_sx = 0;
			p->select_cch_sy = 0;
		}

		ret = true;

	} else {

		// [Patch] : a caret will move to tail

		p->shift_dragging = VK_RIGHT;

		p->select_cch_x  = 0;
		p->select_cch_sx = n_posix_strlen( n_txt_get( &p->txt, y ) );
		p->select_cch_y  = y;
		p->select_cch_sy = 1;

	}


	return ret;
}

void
n_win_txtbox_reset_undo( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// [Needed] : sy = 1 : a caret will disappear at the first time

	p->undo_cch_x  = 0;
	p->undo_cch_y  = 0;
	p->undo_cch_sx = 0;
	p->undo_cch_sy = 1;

	p->undo_line_min_onoff = false;
	p->undo_line_max_onoff = false;
	p->undo_line_min_cch_x = 0;
	p->undo_line_max_cch_x = 0;

	p->undo_onoff = false;


	n_txt_free( &p->txt_undo );
	n_txt_new ( &p->txt_undo );


	return;
}

void
n_win_txtbox_scaling( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->scale = n_win_dpi( p->hwnd ) / 96;


	return;
}

void
n_win_txtbox_scroll_reset( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_reset( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_reset( &p->vscr );
	}


	return;
}

void
n_win_txtbox_scroll_refresh( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_metrics_canvas( p );


	// [Needed] : clamp when resized

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );


	// [!] : some functions rewrite position for calling through WM_COMMAND

	p->hscr.unit_pos = 0;
	p->vscr.unit_pos = 0;

	extern void n_win_txtbox_draw_scrollbars( n_win_txtbox *p, bool mask );
	n_win_txtbox_draw_scrollbars( p, false );
//n_posix_debug_literal( " %f ", p->vscr.unit_pos );


	// [Needed] : Win9x : reason is unknown

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_refresh( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_refresh( &p->vscr );
	}


	return;
}

void
n_win_txtbox_reset( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_txt_free( &p->txt );
	n_txt_new ( &p->txt );

	n_win_txtbox_scroll_set( p, 0,0,      false );
	n_win_txtbox_select_set( p, 0,0, 0,1, false );

	n_win_txtbox_line_minmax_reset( p );

	n_win_txtbox_reset_undo( p );

	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"EDIT" );

	n_win_txtbox_scaling( p );

	//n_win_txtbox_scroll_reset( p );


	return;
}

#define n_win_txtbox_str2index_literal( p, s, b ) n_win_txtbox_str2index( p, n_posix_literal( s ), b )

s32
n_win_txtbox_str2index( n_win_txtbox *p, const n_posix_char *str, bool autoselect )
{

	// [!] : be sure to check a returned value


	if ( p == NULL ) { return -1; }


	size_t i = 0;
	while( 1 )
	{

		if ( n_string_is_same( str, n_txt_get( &p->txt, i ) ) ) { break; }

		i++;
		if ( i >= p->txt.sy ) { return -1; }
	}


	if ( autoselect )
	{
		n_win_txtbox_line_select( p, i );
		n_win_txtbox_autofocus( p );
		n_win_txtbox_refresh( p );
	}


	return i;
}




// internal
s32
n_win_txtbox_horizontal_centering( n_win_txtbox *p )
{

	s32 ret = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
	)
	{
		n_posix_char *text = n_txt_get( &p->txt, 0 );

		SIZE size = n_win_txtbox_size_text( p, text );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			ret = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		n_win_txtbox_caret_onoff( p );
	}


	return ret;
}

bool
n_win_txtbox_is_hovered( n_win_txtbox *p )
{

	if ( p == NULL ) { return false; }

	if ( false == IsWindow       ( p->hwnd ) ) { return false; }
	if ( false == IsWindowVisible( p->hwnd ) ) { return false; }


	bool is_hovered;

	p->hover_cch_x = 0;

	{

		s32 sx,sy; n_win_size( p->hwnd, &sx, &sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= GetSystemMetrics( SM_CYHSCROLL ); }
		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= GetSystemMetrics( SM_CXVSCROLL ); }

		sx -= p->pad_pxl_sx * 2;
		sy -= p->pad_pxl_sy * 2;

		is_hovered = n_win_is_hovered_offset( p->hwnd, 0,0,sx,sy );

	}


	// [!] : fail-safe

	if ( p->cell_pxl_sy <= 0 ) { return is_hovered; }


	// [!] : N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL : out-of-bound area is acceptable for usability

	s32 x,y; n_win_cursor_position_relative( p->hwnd, &x, &y );

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		p->hover_cch_y = 0;
	} else {
		p->hover_cch_y = p->scroll_cch_tabbed_y + ( ( y - p->pad_pxl_sy ) / p->cell_pxl_sy );
	}


	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return is_hovered; }
//return is_hovered;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->hover_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", ( p->hover_cch_y >= p->txt.sy ) );

	// [!] : Notepad compatible behavior

	if ( (u32) p->hover_cch_y <          0 ) { return is_hovered; }
	if ( (u32) p->hover_cch_y >= p->txt.sy ) { p->hover_cch_y = p->txt.sy - 1; }


	s32 nc_sx = p->pad_pxl_sx;
	s32 nc_sy = p->pad_pxl_sy;

	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ) { nc_sx += n_win_txtbox_horizontal_centering( p ); }
		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) { nc_sx += p->number_pxl_sx + p->number_pad_pxl_sx; }
	}

	// [!] : for usability

	p->is_hovered_linenum = false;

	if ( is_hovered )
	{
		s32 pad_fx = 0;
		s32 pad_tx = nc_sx;

		if ( ( x >= pad_fx )&&( x <= pad_tx ) )
		{
//n_posix_debug_literal( " ! " );
			p->hover_cch_x = 0;

			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				p->is_hovered_linenum = true;
			}

			return true;
		}

	}


	// [Needed] : for press'n'run

	if ( x < nc_sx ) { return false; }


	p->hdc = GetDC( p->hwnd );


	HFONT hf = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );


	n_posix_char *text = n_txt_get( &p->txt, p->hover_cch_y );


	SIZE  size  = { 0,0 };
	s32   cch   = 0;
	s32   tab   = 0;

	s32   osx    = p->scroll_pxl_tabbed_x;
	//s32   osy    = p->scroll_cch_tabbed_y * p->cell_pxl_sy;
	s32   draw_x = nc_sx - osx;
	s32   text_x = 0;
	POINT cursor = { x, nc_sy + ( y / p->cell_pxl_sy * p->cell_pxl_sy ) };
	while( 1 )
	{//break;

		n_posix_char *character = n_win_txtbox_character( p, text, text_x, &size, &cch, &tab );


		s32 inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		RECT rect; n_win_rect_set( &rect, draw_x, cursor.y, size.cx, p->cell_pxl_sy );

		if ( n_string_is_empty( character ) )
		{

			p->hover_cch_x = text_x;

			break;

		} else
		if ( PtInRect( &rect, cursor ) )
		{
//n_win_txtbox_box( p, hdc, &rect, RGB( 255,0,255 ) );

			s32 half_sx = ( size.cx / 2 );

			n_win_rect_set( &rect, draw_x + half_sx, cursor.y, half_sx, p->cell_pxl_sy );

			if ( PtInRect( &rect, cursor ) ) { text_x += inc; }


			p->hover_cch_x = text_x;


			break;

		}

		draw_x += size.cx;
		text_x += inc;

	}


	SelectObject( p->hdc, hf );
	ReleaseDC( p->hwnd, p->hdc );
	p->hdc = NULL;


	return is_hovered;
}

// internal
void
n_win_txtbox_draw_debug_fastmode( n_win_txtbox *p, s32 y )
{

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	const n_posix_char *str = n_posix_literal( "!" );


	SetBkColor  ( p->hdc, RGB( 255,255,255 ) );
	SetTextColor( p->hdc, RGB(   0,200,255 ) );

	s32 osx = 0;
	if (
		( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	)
	{
		osx = p->number_pxl_sx + p->number_pad_pxl_sx;
	}

	SIZE size = n_win_txtbox_size_text_fast( p, p->hdc, str );
	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + osx, y, size.cx, size.cy );

	n_win_txtbox_DrawText( p, str, -1, &rect, p->drawtext_modes );


	return;
}

// internal
void
n_win_txtbox_draw_eol( n_win_txtbox *p, s32 x, s32 y, u32 bg, n_posix_char *eol )
{

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	SetBkColor  ( p->hdc, bg );
	SetTextColor( p->hdc, p->color_text_eol_mark );

	SIZE size = n_win_txtbox_size_text_fast( p, p->hdc, eol );
	RECT rect = n_win_rect_set( NULL, x, y, size.cx, size.cy );

	n_win_txtbox_DrawText( p, eol, -1, &rect, p->drawtext_modes );


	return;
}

// internal
void
n_win_txtbox_draw_caret( n_win_txtbox *p )
{

	// [!] : fake caret

	// [x] : system caret is buggy
	//
	//	interfere with other edit controls' caret


	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	s32  x = p->caret_pxl_x;
	s32  y = p->caret_pxl_y;
	s32 sx = p->caret_pxl_sx;
	s32 sy = p->caret_pxl_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", x, y );


	// [!] : Win9x/NT4        : "sx" is 2px
	// [!] : Win2000 or later : "sx" is 1px by default (you can change this)

	if ( p->is_2k_or_later )
	{
		if ( ( p->ime_onoff )&&( sx == 1 ) ) { sx = 2; }
	} else {
		//
	}


	// Debug Center

	//sx = 10;


	if ( ( p->caret_onoff )||( p->input_onoff ) )
	{

		bool draw = true;

		u32 color = p->color_caret_focused;
		if ( p->hwnd != GetFocus() )
		{
			color = p->color_caret_nofocus;

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET )
			{
				draw = false;
			}
		}

		if ( draw )
		{

			//RECT r; n_win_rect_set( &r, x, y, sx,sy );
			//n_win_txtbox_box( p, p->hdc, &r, color );

			COLORREF fg = color;
			COLORREF bg = p->color_text_backgrnd;

			n_win_txtbox_box_invert( p->hdc, x,y, sx,sy, fg, bg );

		}


	}


	// [!] : remember the last position

	POINT pt = { x, y }; p->ime = pt;


	return;
}

// internal
bool
n_win_txtbox_is_caret_tail( n_win_txtbox *p )
{
	return (
		( ( p->shift_dragging == VK_RIGHT )||( p->shift_dragging == VK_DOWN ) )
		||
		( ( p->prv_drag       == VK_RIGHT )||( p->prv_drag       == VK_DOWN ) )
	);
}

// internal
void
n_win_txtbox_draw_linenumber( n_win_txtbox *p, size_t text_y, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx, y, p->number_pxl_sx, sy );

	if ( text_y < p->txt.sy )
	{
		int cch_y = 1 + text_y;

		bool over_ten_thousand = false;
		if ( cch_y >= 10000 ) { over_ten_thousand = true; }

		if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

		n_posix_char str[ 6 + 1 ];

		// [Patch] : not working accurately

		if ( cch_y < 1000 )
		{
			if ( over_ten_thousand )
			{
				n_posix_sprintf_literal( str, " %04d ", cch_y );
			} else {
				n_posix_sprintf_literal( str, " % 4d ", cch_y );
			}
		} else {
			n_posix_sprintf_literal( str, " %d "  , cch_y );
		}

		COLORREF bg = p->color_back_linenum1;
		COLORREF fg = p->color_text_linenum1;

//if ( text_y == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy ); }

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_sx, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_onoff, p->line_max_onoff );

		bool is_curline = false;

		if (
			( ( p->line_min_onoff )&&( text_y == ( p->select_cch_y + p->select_cch_sy - 1 ) ) )
			||
			( ( p->line_max_onoff )&&( text_y ==   p->select_cch_y                          ) )
			||
			(
				( ( p->line_min_onoff == false )&&( p->line_max_onoff == false ) )
				&&
				( text_y == p->select_cch_y )
			)
		)
		{
			is_curline = true;
			bg = p->color_back_linenum2;
		}

		bool is_sel_line = false;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->empty_line_selection, p->select_cch_y );

		if (
			(
				( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
				&&
				( p->empty_line_selection == p->select_cch_y )
				&&
				( text_y == p->select_cch_y )
			)
			||
			(
				(                1 != p->txt.sy )
				&&
				( p->select_cch_sy == p->txt.sy )
			)
			||
			( ( p->line_min_onoff     )&&( text_y == p->select_cch_y ) )
			||
			( ( p->line_max_onoff     )&&( text_y == p->select_cch_y ) )
			||
			( ( p->select_cch_sx != 0 )&&( text_y == p->select_cch_y ) )
			||
			( n_win_txtbox_is_highlighted( p, -1, text_y ) )
		)
		{
			is_sel_line = true;
			bg = p->color_back_linenum2;
		}

		n_win_txtbox_box( p, p->hdc, &rect, bg );

		if ( ( is_curline )||( is_sel_line ) )
		{
			RECT r = rect; n_win_rect_move( &r, 1, 1 );
			SetTextColor( p->hdc, p->color_back_noselect );
			n_win_txtbox_DrawText( p, str, 6, &r, p->drawtext_modes );

			fg = p->color_text_linenum2;
		}

		SetTextColor( p->hdc, fg );
		n_win_txtbox_DrawText( p, str, 6, &rect, p->drawtext_modes );

		if ( is_sel_line )
		{
			s32 fx = p->pad_pxl_sx + p->number_pxl_sx - ( p->number_pad_pxl_sx / 2 );
			RECT rect = n_win_rect_set( NULL, fx, y, p->number_pad_pxl_sx, sy );
			n_win_txtbox_box( p, p->hdc, &rect, p->color_back_linenum3 );
		}

	} else {

		rect.right++;
		n_win_txtbox_box( p, p->hdc, &rect, p->color_back_linenum1 );

	}

	// [Needed] : padding between line number and text
	{
		COLORREF color = p->color_back_noselect;
		if ( p->debug_onoff ) { color = RGB( 0,255,0 ); }

		RECT rect = n_win_rect_set( NULL, p->pad_pxl_sx + p->number_pxl_sx, y, p->pad_pxl_sx, sy );
		n_win_txtbox_box( p, p->hdc, &rect, color );
	}


	return;
}

void
n_win_txtbox_smallbutton_embed( n_win_txtbox *p, n_win_smallbutton *sb, int index, bool redraw )
{

	if ( p == NULL ) { return; }

	if ( false == IsWindow( sb->hgui ) ) { return; }


	index = n_posix_max( 1, index + 1 );

	s32 ix,iy,isx,isy; n_win_location( p->hwnd, &ix,&iy,&isx,&isy );

	{

		const s32 border = 2;

		s32 btn = isy - ( border * 2 );

		//if ( p->debug_onoff == false )
		{
			s32 bx = bx = ( ix + isx ) - border - ( btn * index );
			s32 by = iy + border;

			n_win_move_simple( sb->hgui, bx,by, btn,btn, redraw );
			if ( redraw ) { n_win_smallbutton_bitmap( sb ); }
		}

		p->smallbutton_margin = btn * index;

	}


	return;
}

// internal
void
n_win_txtbox_draw_singleline( n_win_txtbox *p, s32 text_y, s32 x, s32 y, s32 sx, s32 sy )
{

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	if ( text_y < ( p->scroll_cch_tabbed_y                         ) ) { return; }
	if ( text_y > ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) { return; }


//if ( p->debug_onoff ) { return; }


	int p_bkmode = GetBkMode( p->hdc );
	SetBkMode( p->hdc, TRANSPARENT );


	bool editbox = ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX );


	// [!] : Stripe Background

	COLORREF bg = p->color_back_noselect;

	if ( p->style & N_WIN_TXTBOX_STYLE_STRIPED )
	{
		if ( text_y & 1 ) { bg = p->color_back_striping; }
	}
//bg = RGB( 200,200,200 );

	p->color_text_backgrnd = bg;


	// [!] : Global Background

	{

		COLORREF color;
		if (
			( editbox == false )
			&&
			( n_win_txtbox_is_highlighted( p, 0, text_y ) )
		)
		{
			color = p->color_back_selected;
//n_win_txtbox_hwndprintf_literal( p, " %d ", text_y );
		} else {
			color = bg;
			if ( p->debug_onoff ) { color = RGB( 222,222,255 ); }
		}
//if ( color ) {}

		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{ 
			color = 0;
		}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", y, sy, p->client_pxl_sy );

		RECT rect = n_win_rect_set( NULL, p->border_pxl_sx, y, p->client_pxl_sx - ( p->border_pxl_sx * 2 ), sy );
		n_win_txtbox_box( p, p->hdc, &rect, color );

	}


	bool tab_onoff = ( false == n_string_is_empty( p->tab_mark ) );
	bool eol_onoff = ( false == n_string_is_empty( p->eol_mark ) );


	bool tab_auto = false;

	if ( tab_onoff )
	{
		tab_auto = n_string_is_same_literal( "auto", p->tab_mark );
	}


	bool          eol_auto = false;
	n_posix_char *eol_str  = N_STRING_EMPTY;

	if ( eol_onoff )
	{
		eol_auto = n_string_is_same_literal( "auto", p->eol_mark );
		if ( eol_auto )
		{
#ifdef UNICODE
			eol_str = n_posix_literal( "\x21a9" );
#else  // #ifdef UNICODE
			eol_str = n_posix_literal( "<" );
#endif // #ifdef UNICODE
		} else {
			eol_str = p->eol_mark;
		}
	}


	n_posix_char *text = n_txt_get( &p->txt, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text ); return;

	bool  bold_onoff = false;
	HFONT bold_hfont =  NULL;
	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_BOLDTXT )
	)
	{
		if ( n_string_match_literal( text, "[b]" ) )
		{
			bold_onoff = true;

			text = &text[ 3 ];

			bold_hfont = SelectObject( p->hdc, n_win_txtbox_font_bold( n_win_font_get( p->hwnd ) ) );
		}
	}


	// Fast Mode

	int  text_cch           = 0;
	int  text_sx            = 0;
	bool text_tab_is_exist  = false;
	bool text_fastmode      = false;
	bool text_surrogatepair = false;

	n_win_txtbox_tab2space
	(
		 p, text,
		 p->tabstop,
		&text_cch, &text_sx,
		&text_tab_is_exist,
		&text_fastmode,
		&text_surrogatepair,
		 false
	);


	bool outer   = ( ( text_y < p->select_cch_y )||( text_y > ( p->select_cch_y + p->select_cch_sy - 1 ) ) );
	bool inner   = ( ( text_y > p->select_cch_y )&&( text_y < ( p->select_cch_y + p->select_cch_sy - 1 ) ) );
	bool just    = ( ( text_y == p->select_cch_y )&&( p->select_cch_sy == 1 ) );
	bool zeroall = ( ( p->select_cch_sx == 0 )||( p->select_cch_sx == text_cch ) );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", text_cch, text_sx, just );
//n_posix_debug_literal( "%s\n%s", text, n_txt_get( &p->txt_undo, 0 ) );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->oneline_cache_onoff );

	if (
//( false )&&
		( false == ( p->style_option & N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ) )
		&&
		( editbox == false )
		&&
		( text_tab_is_exist == false )
	)
	{

		n_posix_char *text_tab = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch,&text_sx, NULL,NULL,NULL, true );


		s32  pxl_x  = p->border_pxl_sx + p->virtual_padding_pxl_sx + p->pad_pxl_sx;
		s32  pxl_sx = p->client_pxl_sx;
		RECT rect   = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );


		if ( ( just )&&( p->select_cch_sx != 0 ) )
		{
			SetTextColor( p->hdc, p->color_text_selected );
		} else {
			SetTextColor( p->hdc, p->color_text_noselect );
		}

		n_win_txtbox_DrawText( p, text,-1, &rect, p->drawtext_modes );

		n_memory_free( text_tab );


		if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( false == n_string_is_empty( p->placeholder ) )
		&&
		( n_string_is_empty( text ) )
		&&
		( p->hwnd != GetFocus() )
	)
	{

		s32 pxl_x  = x;
		s32 pxl_sx = sx;

		SIZE size = n_win_txtbox_size_text( p, p->placeholder );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			pxl_x = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		SetTextColor( p->hdc, p->color___placeholder );

		RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		n_win_txtbox_DrawText( p, p->placeholder,-1, &rect, p->drawtext_modes );

		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
//( false )&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->oneline_cache_onoff )
		&&
		( p->select_cch_sx == p->prv_sel_sx )
		&&
		( n_string_is_same( text, n_txt_get( &p->txt_undo, 0 ) ) )
		&&
		( n_gdi_doublebuffer_instance.bpp == 32 )
		&&
		( false == n_string_is_empty( text ) )
		&&
		( false == n_bmp_error( &p->prv_bmp ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->select_cch_sx, p->prv_sel_sx, p->select_cch_sy, p->prv_sel_sy );

		n_bmp *bmp = &n_gdi_doublebuffer_instance.bmp;

		s32 _sx = N_BMP_SX( &p->prv_bmp );
		s32 _sy = N_BMP_SY( &p->prv_bmp );
		s32 __x = 0;
		s32 __y = 0;

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
		{
			__x = p->pad_pxl_sx - p->border_pxl_sx;
		}

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
		{
			__x = ( sx - _sx ) / 2;
			__y = ( sy - _sy ) / 2;
		}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sx, _sx );

		n_bmp_fastcopy( &p->prv_bmp, bmp, 0,0,_sx,_sy, __x,__y );

		SetBkMode( p->hdc, p_bkmode );

		return;

	} else
	if (
//( false )&&
		( editbox )
		&&
		( p->is_font_monospace )
		&&
		( text_tab_is_exist == false )
		&&
		( text_fastmode )
		&&
		( text_surrogatepair == false )
		&&
		( text_cch == text_sx )
		&&
		( ( outer )||( inner )||( ( just )&&( zeroall ) ) )
		&&
		( false == ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ) )
	)
	{
//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", just, p->select_cch_sx, text_cch );

		// Line Number

		n_win_txtbox_draw_linenumber( p, text_y, x,y,sx,sy );


		n_posix_char *text_tab = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch,&text_sx, NULL,NULL,NULL, true );


		s32 pxl_x  = n_win_txtbox_horizontal_centering( p ); if ( pxl_x == 0 ) { pxl_x = x; }
		s32 pxl_sx = sx + p->scroll_pxl_tabbed_x;


		if ( p->scroll_pxl_tabbed_x != 0 )
		{
			s32 linenum_osx = 0;
			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				linenum_osx = p->number_pxl_sx + p->number_pad_pxl_sx;
			}
			pxl_x = n_posix_max_s32( p->pad_pxl_sx + linenum_osx, x );
		}

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->select_cch_sx );


		// [x] : TabbedTextOut() : width will be different from space character

		int cch = text_cch - ( p->scroll_pxl_tabbed_x / p->font_pxl_sx );

//n_win_txtbox_hwndprintf_literal( p, " %d ", cch );

		if ( cch > 0 )
		{

//n_win_txtbox_hwndprintf_literal( p, " %s : %d ", str, cch );

			if ( n_win_txtbox_is_highlighted( p, 0, text_y ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " %d ", pxl_x - 1 );
				RECT rect = n_win_rect_set( NULL, pxl_x, y, ( cch * p->font_pxl_sx ), sy );
				n_win_txtbox_box( p, p->hdc, &rect, p->color_back_selected );
			}

			{

				if ( ( inner )||( ( just )&&( p->select_cch_sx != 0 ) ) )
				{
					SetTextColor( p->hdc, p->color_text_selected );
				} else
				if ( ( outer )||( ( just )&&( p->select_cch_sx == 0 ) ) )
				{
					SetTextColor( p->hdc, p->color_text_noselect );
				}

				n_posix_char *str = &text_tab[ p->scroll_pxl_tabbed_x / p->font_pxl_sx ];

				RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );
				n_win_txtbox_DrawText( p, str,cch, &rect, p->drawtext_modes );

			}

		}


		// Caret

		if ( just )
		{

			s32 ox = p->pad_pxl_sx;
			s32 oy = p->pad_pxl_sy;

			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				ox += p->number_pxl_sx + p->number_pad_pxl_sx;
			}

			s32 tx = p->select_cch_x * p->font_pxl_sx;
			if ( p->select_cch_sx != 0 ) { tx = text_cch * p->font_pxl_sx; }

			p->caret_pxl_x = ox + (              tx - p->scroll_pxl_tabbed_x )                 ;
			p->caret_pxl_y = oy + ( p->select_cch_y - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;

			n_win_txtbox_draw_caret( p );

		}

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( cch >= 0 )&&( (u32) text_y < p->txt.sy ) )
		{
			n_posix_char *str = &text_tab[ p->scroll_pxl_tabbed_x / p->font_pxl_sx ];

			SIZE size; GetTextExtentPoint32( p->hdc, str, cch, &size );
			s32  ox    = p->pad_pxl_sx + size.cx;

			if (
				( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
				&&
				( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			)
			{
				ox += p->number_pxl_sx + p->number_pad_pxl_sx;
				ox++;
			}

			n_win_txtbox_draw_eol( p, ox, y, bg, eol_str );
		}


		n_memory_free( text_tab );


		// Debug

		//n_win_txtbox_draw_debug_fastmode( p, y );


		if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


		SetBkMode( p->hdc, p_bkmode );

		return;
	}


	// Slow Mode
	//
	//	+ tabstop support
	//	+ CJK fixed pitch patch

	SIZE size     = { 0,0 };
	s32  cch      = 0;
	s32  tab      = 0;

	s32  caret_fx = -1;
	s32  caret_tx = -1;
	s32  text_x   =  0;
	s32  tail_x   =  0;
	s32  horz_x   = n_win_txtbox_horizontal_centering( p );

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		horz_x++;
	}

	if (
		( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	)
	{
		tail_x = p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
	} else {
		tail_x = p->pad_pxl_sx;
	}

	tail_x += p->virtual_padding_pxl_sx;

	tail_x -= p->scroll_pxl_tabbed_x;
	tail_x += horz_x;

	p->oneline_cache_f = tail_x;

	s32 ctl_sy; n_win_size_client( p->hwnd, NULL, &ctl_sy );

	while( 1 )
	{//break;

		n_posix_char *character = n_win_txtbox_character( p, text, text_x, &size, &cch, &tab );

		if ( n_string_is_empty( character ) )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			if ( caret_tx == -1 ) { caret_tx = tail_x; }

			break;

		}


		// [!] : DrawText() will be slowdown without manual clipping

		bool is_highlighted = n_win_txtbox_is_highlighted( p, text_x, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_highlighted );

		if ( is_highlighted )
		{
			SetTextColor( p->hdc, p->color_text_selected );
		} else {
			SetTextColor( p->hdc, p->color_text_noselect );
		}
//if ( color_bg ) {}
//size.cx *= 2;

		{
			RECT rect = n_win_rect_set( NULL, tail_x, y, size.cx, p->cell_pxl_sy );
			RECT r_bg = rect;

			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				s32 vcenter = ( p->canvas_pxl_sy - p->cell_pxl_sy ) / 2;

				if ( 96 != n_win_dpi( p->hwnd ) )
				{
					vcenter = ( ctl_sy - size.cy ) / 2 / 2;
				}

				r_bg.top    -= vcenter;
				r_bg.bottom -= vcenter;
			}

			if ( is_highlighted ) { n_win_txtbox_box( p, p->hdc, &r_bg, p->color_back_selected ); }

			if ( tab_onoff )
			{
				if ( text[ text_x ] == N_STRING_CHAR_TAB )
				{
					if ( tab_auto )
					{
						RECT rect = n_win_rect_set( NULL, tail_x, y, 1, size.cy );
						n_win_txtbox_box( p, p->hdc, &rect, p->color_text_tab_mark );
					} else {
						SetTextColor( p->hdc, p->color_text_tab_mark );
						character[ 0 ] = p->tab_mark[ 0 ];
					}
				}
			}

			n_win_txtbox_DrawText( p, character, cch, &rect, p->drawtext_modes | DT_CENTER );

		}


		if ( is_highlighted )
		{

			if ( caret_fx == -1 ) { caret_fx = tail_x; }
			caret_tx = tail_x + size.cx;

		} else {

			if (
				( ( p->line_min_onoff )&&( text_x == p->line_max_cch_x ) )
				||
				( ( p->line_max_onoff )&&( text_x == p->line_min_cch_x ) )
				||
				( text_x == p->select_cch_x )
			)
			{
				//caret_fx = tail_x;
				caret_tx = tail_x;
			}

		}

		int inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		text_x += inc;
		tail_x += size.cx;

	}


	if ( editbox )
	{

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( (u32) text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, tail_x,y, bg, eol_str );
		}


		// Caret

		// [!] : don't use p->hover_cch_y : value will be changed when scrolled

		s32 line_fy = n_posix_minmax( 0, p->txt.sy - 1, p->drag_cch_y - ( p->select_cch_sy - 1 ) );
		s32 line_ty = p->select_cch_y + p->select_cch_sy - 1;

		if ( p->line_min_onoff )
		{
			line_fy = p->select_cch_y + p->select_cch_sy - 1;
		} else
		if ( p->line_max_onoff )
		{
			line_fy = p->select_cch_y;
		}

		// [Mechanism]
		//
		//	#define VK_LEFT  37
		//	#define VK_UP    38
		//	#define VK_RIGHT 39
		//	#define VK_DOWN  40

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );

		p->is_caret_tail = false;

		s32 line    = line_ty;
		s32 caret_x = caret_tx;
		s32 caret_y = y;
		if ( p->line_min_onoff )
		{

			//

		} else
		if ( p->line_max_onoff )
		{

			line    = line_fy;
			caret_x = caret_fx;

		} else {

			if ( p->shift_dragging == VK_LEFT )
			{
				caret_x = caret_fx;
			} else
			if ( p->shift_dragging == VK_UP )
			{
				line    = line_fy;
				caret_x = caret_fx;
			} else {
				p->is_caret_tail = true;
			}

		}


		if ( ( line == text_y )&&( caret_x != -1 ) )
		{

			p->caret_pxl_x = caret_x;
			p->caret_pxl_y = caret_y;

			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->shift_dragging, p->select_cch_x + p->select_cch_sx );

				if ( p->shift_dragging == VK_LEFT  )
				{
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x += p->scale;
					} else {
						p->caret_pxl_x -= p->scale;
					}
				} else
				if ( p->shift_dragging == VK_RIGHT )
				{
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x -= p->scale;
					} else {
						p->caret_pxl_x += p->scale;
					}
				} else {
					if ( ( p->select_cch_x + p->select_cch_sx ) == 0 )
					{
						p->caret_pxl_x -= p->scale;
					} else {
						p->caret_pxl_x += p->scale;
					}
				}

				p->caret_pxl_x = n_posix_max_s32( p->pad_pxl_sx, p->caret_pxl_x );

			}

			n_win_txtbox_draw_caret( p );

		}

//n_win_txtbox_hwndprintf_literal( p, " %d ", line );


		// Line Number

		n_win_txtbox_draw_linenumber( p, text_y, x,y,sx,sy );

	}


	if ( bold_onoff ) { n_win_font_exit( SelectObject( p->hdc, bold_hfont ) ); }


	p->oneline_cache_t = tail_x;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( n_gdi_doublebuffer_instance.bpp == 32 )
	)
	{
		n_bmp *bmp = &n_gdi_doublebuffer_instance.bmp;

		s32 fx = p->oneline_cache_f - 2;
		s32 sx = p->oneline_cache_t - p->oneline_cache_f + 4;

		n_bmp_new_fast( &p->prv_bmp, sx,N_BMP_SY( bmp ) );
		n_bmp_fastcopy( bmp, &p->prv_bmp, fx,0,sx,N_BMP_SY( bmp ), 0,0 );
//n_bmp_save_literal( &p->prv_bmp, "ret.bmp" );
	}


	SetBkMode( p->hdc, p_bkmode );


	return;
}

// internal
void
n_win_txtbox_draw_nonclient( n_win_txtbox *p )
{
//return;

	if ( p      == NULL ) { return; }
	if ( p->hdc == NULL ) { return; }


	COLORREF color_border       = p->color_base__padding;
	COLORREF color_border_mask  = p->color_base__padding;
	COLORREF color_padding      = p->color_back_noselect;
	COLORREF color_padding_mask = p->color_base__padding;
	COLORREF color_corner       = p->color_base__padding;

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		color_border       = 0;
		color_border_mask  = 0;
		color_padding      = 0;
		color_padding_mask = 0;
		color_corner       = 0;
	}

	if ( p->debug_onoff )
	{
		color_border       = RGB( 200,  0,255 );
		color_border_mask  = RGB( 255,255,  0 );
		color_padding      = RGB( 255,  0,  0 );
		color_padding_mask = RGB(   0,  0,255 );
		color_corner       = RGB(   0,255,  0 );
	}


	// Border

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->client_pxl_sx,p->client_pxl_sy );

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		RECT r = n_win_rect_set( NULL, 0,0,p->client_pxl_sx,p->client_pxl_sy );

		// [!] : WS_EX_CLIENTEDGE causes flickering

		if (
			( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			&&
			( false == ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ) )
		)
		{

			if ( p->hwnd == GetFocus() )
			{

				n_win_txtbox_box( p, p->hdc, &r, p->color_back_selected );

			} else {

				if ( n_win_darkmode_onoff )
				{
					n_win_txtbox_box( p, p->hdc, &r, p->color_border_normal );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
				{
					n_win_txtbox_box( p, p->hdc, &r, n_bmp_white );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_frame( p->hdc, &r, p->scale, p->color_border___flat );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_combo_border( p, &r );
				} else
				if ( p->uxtheme.onoff )
				{
					p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, p->hdc, EP_EDITBORDER_NOSCROLL, EPSN_NORMAL, &r, NULL );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}

			}

		} else {

			if ( p->is_classic )
			{

				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_frame( p->hdc, &r, p->scale, p->color_border___flat );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_combo_border( p, &r );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}

			} else {

				if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
				{
					n_win_txtbox_frame( p->hdc, &r, p->scale, p->color_border___flat );
				} else
				if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BDR )
				{
					n_win_txtbox_combo_border( p, &r );
				} else
				if ( p->uxtheme.onoff )
				{
					int state = EPSN_NORMAL;
					if ( p->hwnd == GetFocus() ) { state = EPSN_FOCUSED; }
					p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, p->hdc, EP_EDITBORDER_NOSCROLL, state, &r, NULL );
				} else {
					DrawEdge( p->hdc, &r, EDGE_SUNKEN, BF_RECT );
				}


			}

		}

		if ( p->debug_onoff )
		{
			n_win_txtbox_box( p, p->hdc, &r, color_border );
		}

	}

	// Mask Border

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) )
	{

		// [Needed] : for text clipping

		s32  x = 0;
		s32  y = 0;
		s32 sx = p->client_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32 ox = sx - p->border_pxl_sx;
		s32 oy = sy - p->border_pxl_sy;
		s32 bx = p->border_pxl_sx;
		s32 by = p->border_pxl_sy;

		if ( p->debug_onoff )
		{
			RECT r;
			n_win_rect_set_simple( &r,  x,  y,      sx,      by ); n_win_txtbox_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r,  x, oy,      sx, oy + by ); n_win_txtbox_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r,  x,  y,      bx,      sy ); n_win_txtbox_box( p, p->hdc, &r, color_border_mask );
			n_win_rect_set_simple( &r, ox,  y, ox + bx,      sy ); n_win_txtbox_box( p, p->hdc, &r, color_border_mask );
		}

		ExcludeClipRect( p->hdc,  x,  y,      sx,      by );
		ExcludeClipRect( p->hdc,  x, oy,      sx, oy + by );
		ExcludeClipRect( p->hdc,  x,  y,      bx,      sy );
		ExcludeClipRect( p->hdc, ox,  y, ox + bx,      sy );

	}


	// Corner : before padding

	if (
		( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		&&
		( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	)
	{

		// [!] : blank at bottom-right corner

		s32  tsx = p->scrollbar_pxl_sx;
		s32  tsy = p->scrollbar_pxl_sy;
		s32   tx = p->client_pxl_sx - p->scrollbar_pxl_sx - p->border_pxl_sx;
		s32   ty = p->client_pxl_sy - p->scrollbar_pxl_sy - p->border_pxl_sy;
		RECT   r = n_win_rect_set( NULL, tx, ty, tsx, tsy );

		if ( p->debug_onoff )
		{
			n_bmp_mixer( p->debug_bmp, tx, ty, tsx, tsy, color_corner, 0.5 );
		} else {
			n_win_txtbox_box( p, p->hdc, &r, color_corner );
		}

		ExcludeClipRect( p->hdc, r.left, r.top, r.right, r.bottom );

	}


	// Padding

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG ) )
	{

		// [Needed] : Win9x : padding will be black

		// [!] : for performance : accurate calculation is too much complicated

		// [!] : top bottom left right in order

		s32  x = p->border_pxl_sx;
		s32  y = p->border_pxl_sy;
		s32 sx = p->client_pxl_sx - ( x * 2 );
		s32 sy = p->client_pxl_sy - ( y * 2 );

		RECT r;

		COLORREF clr = color_padding;

		n_win_rect_set( &r, x, y, sx, sy );
		n_win_txtbox_box( p, p->hdc, &r, clr );

	}

	// Mask Padding

	if ( false == ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG ) )
	{

		// [Needed] : for text clipping

		s32 pad_sx = p->pad_pxl_sx;
		s32 pad_sy = p->pad_pxl_sy;
		s32      x = p->border_pxl_sx;
		s32      y = p->border_pxl_sy;
		s32     sx = p->canvas_pxl_sx + ( pad_sx * 2 );
		s32     sy = p->canvas_pxl_sy + ( pad_sy * 2 );
		s32    csx = p->client_pxl_sx;
		s32    csy = p->client_pxl_sy;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			csy -= p->scrollbar_pxl_sy;
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			csx -= p->scrollbar_pxl_sx;
		}

		s32 ox = csx - pad_sx - p->smallbutton_margin;
		s32 oy = csy - pad_sy;

		if ( p->debug_onoff )
		{
			RECT r;
			n_win_rect_set_simple( &r,  x,  y,     sx, pad_sy ); n_win_txtbox_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r,  x, oy,     sx,    csy ); n_win_txtbox_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r,  x,  y, pad_sx,     sy ); n_win_txtbox_box( p, p->hdc, &r, color_padding_mask );
			n_win_rect_set_simple( &r, ox,  y,    csx,     sy ); n_win_txtbox_box( p, p->hdc, &r, color_padding_mask );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			ExcludeClipRect( p->hdc,  x,  y,     sx, pad_sy );
			//ExcludeClipRect( p->hdc,  x, oy,     sx,    csy ); // [!] : for "g"
			ExcludeClipRect( p->hdc,  x,  y, pad_sx,     sy );
			ExcludeClipRect( p->hdc, ox,  y,    csx,     sy );
		} else {

			ExcludeClipRect( p->hdc,  x,  y,     sx, pad_sy );
			ExcludeClipRect( p->hdc,  x, oy,     sx,    csy );
			ExcludeClipRect( p->hdc,  x,  y, pad_sx,     sy );
			ExcludeClipRect( p->hdc, ox,  y,    csx,     sy );

		}

	}


	return;
}

// internal
void
n_win_txtbox_draw_scrollbars( n_win_txtbox *p, bool mask )
{
//return;

	if ( p == NULL ) { return; }

	if ( ( mask )&&( p->hdc == NULL ) ) { return; }


	// Scrollbars

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{

		// Horizontal / X

		s32 sx = p->client_pxl_sx;
		s32 sy = p->scrollbar_pxl_sy;
		s32  x = 0;
		s32  y = p->client_pxl_sy - p->scrollbar_pxl_sy - p->offset_pxl_y;

		x  += p->border_pxl_sx;
		y  -= p->border_pxl_sy;
		sx -= p->border_pxl_sx * 2;
		//sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx; }


		if ( mask )
		{

			if ( p->debug_onoff )
			{
				RECT r = n_win_rect_set_simple( &r, x, y, x + sx, y + sy );
				n_win_txtbox_box( p, p->hdc, &r, RGB( 0,255,255 ) );
			}

			ExcludeClipRect( p->hdc, x, y, x + sx, y + sy );

		} else {

			if ( p->debug_onoff )
			{
				n_bmp_mixer( p->debug_bmp, x,y,sx,sy, RGB( 255,255,0 ), 0.5 );
			} else {
				n_win_scrollbar_move( &p->hscr, x,y,sx,sy, false );
			}


			bool onoff;

			if ( p->is_font_monospace )
			{
				onoff = ( (u32) ( p->page_pxl_tabbed_sx / p->font_pxl_sx ) < p->txt.sx );
			} else {
				SIZE size = n_win_txtbox_size_text( p, n_txt_get( &p->txt, p->txt_maxwidth_y ) );
				onoff = ( p->page_pxl_tabbed_sx < size.cx );
			}

			if ( onoff )
			{

				s32 pos  = p->scroll_pxl_tabbed_x;
				s32 page = p->  page_pxl_tabbed_sx;
				s32 max  = p->  last_pxl_tabbed_sx;

				n_win_scrollbar_parameter( &p->hscr, p->font_pxl_sx, page, max, pos, false );

			}

			n_win_scrollbar_enable( &p->hscr, onoff, false );

			n_win_scrollbar_draw_always( &p->hscr, true );

		}

	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{

		// Vertical / Y

		s32 sx = p->scrollbar_pxl_sx;
		s32 sy = p->client_pxl_sy;
		s32  x = p->client_pxl_sx - p->scrollbar_pxl_sx;
		s32  y = -p->offset_pxl_y;

		x  -= p->border_pxl_sx;
		y  += p->border_pxl_sy;
		//sx -= p->border_pxl_sx * 2;
		sy -= p->border_pxl_sy * 2;

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }


		if ( mask )
		{

			if ( p->debug_onoff )
			{
				RECT r = n_win_rect_set_simple( &r, x, y, x + sx, y + sy );
				n_win_txtbox_box( p, p->hdc, &r, RGB( 0,255,255 ) );
			}

			ExcludeClipRect( p->hdc, x, y, x + sx, y + sy );

		} else {

			if ( p->debug_onoff )
			{
				n_bmp_mixer( p->debug_bmp, x,y,sx,sy, RGB( 255,255,0 ), 0.5 );
			} else {
				n_win_scrollbar_move( &p->vscr, x,y,sx,sy, false );
			}

			bool onoff = ( (u32) p->page_cch_tabbed_sy < p->txt.sy );

			if ( onoff )
			{

				s32 step = p->cell_pxl_sy;
				s32 pos  = p->cell_pxl_sy * p->scroll_cch_tabbed_y;
				s32 page = p->cell_pxl_sy * p->  page_cch_tabbed_sy;
				s32 max  = p->cell_pxl_sy * p->  last_cch_tabbed_sy;

//n_win_txtbox_hwndprintf_literal( p, " %g %g ", p->vscr.pixel_thumb_original, p->vscr.pixel_thumb );

				n_win_scrollbar_parameter( &p->vscr, step, page, max, pos, false );

			}

			n_win_scrollbar_enable( &p->vscr, onoff, false );

			n_win_scrollbar_draw_always( &p->vscr, true );


//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %g ", p->vscr.rect_main.y );

		}

	}


	return;
}

#define n_win_txtbox_draw( p ) n_win_txtbox_draw_partial( p, NULL, true, -1, -1 )

#define n_win_txtbox_draw_selection( p ) n_win_txtbox_draw_partial( p, NULL, false, (p)->select_cch_y, (p)->select_cch_sy );

// internal
void
n_win_txtbox_draw_partial( n_win_txtbox *p, RECT *r, bool nonclient, s32 line_y, s32 line_sy )
{
//n_win_txtbox_debug_count( p );

	if ( p == NULL ) { return; }

	if ( n_txt_error( &p->txt ) ) { return; }


	// Debug Center

	//u32 benchmark = n_posix_tickcount();

	if ( p->debug_onoff )
	{
		//p->style &= ~( N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL ); 
		//p->style |= N_WIN_TXTBOX_STYLE_HSCROLL;
		//p->style |= N_WIN_TXTBOX_STYLE_VSCROLL;
		//p->style |= N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL;
	}


	// Canvas Metrics : this cannot be put into n_win_txtbox_draw_nonclient()

	if ( nonclient )
	{
		n_win_txtbox_metrics_canvas( p );
		n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );
	}


	// Draw

	bool  getdc_onoff = false;

	HFONT p_hfont = NULL;

	if ( p->hdc != NULL )
	{

		//

	} else
	if (
		( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		||
		( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		||
		( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
	)
	{
		s32 tmp_sy = p->client_pxl_sy;

		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{
			tmp_sy *= -1;
			n_gdi_doublebuffer_instance.upsidedown = true;
		}

		n_gdi_doublebuffer_simple_zero();
		p->hdc = n_gdi_doublebuffer_simple_init( p->hwnd, p->client_pxl_sx, tmp_sy );

		//p->hscr.bmp_backbuffer = &n_gdi_doublebuffer_instance.bmp;
		//p->vscr.bmp_backbuffer = &n_gdi_doublebuffer_instance.bmp;
	} else {
		getdc_onoff = true;

		p->hdc = GetDC( p->hwnd );
		p_hfont = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );
	}


	if ( p->debug_onoff )
	{
		p->debug_bmp = &n_gdi_doublebuffer_instance.bmp;
	}


	// [Needed] : Vista/7 : corner needs this

	//if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		RECT rect = n_win_rect_set( NULL, 0,0, p->client_pxl_sx,p->client_pxl_sy );
		n_win_txtbox_box( p, p->hdc, &rect, p->color_back_noselect );
	}


	// [x] : a caret needs this always : when a line with a caret is out of client area

	//if ( nonclient )
	{

		n_win_txtbox_draw_nonclient( p );

		if ( p->debug_onoff )
		{
			n_win_txtbox_draw_scrollbars( p, false );
		}

		n_win_txtbox_draw_scrollbars( p, true );

	}


	if ( r == NULL )
	{
		if ( line_y  == -1 ) { line_y  = p->scroll_cch_tabbed_y;                         }
		if ( line_sy == -1 ) { line_sy = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy; }
	} else {
		s32 y, sy; n_win_rect_expand_size( r, NULL, &y, NULL, &sy );
		line_y  = ( ( y - p->pad_pxl_sy ) / p->cell_pxl_sy ) + p->scroll_cch_tabbed_y;
		line_sy = sy / p->cell_pxl_sy;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		SIZE sz = n_win_txtbox_size_text( p, n_posix_literal( "y" ) );
		line_sy = n_posix_max_s32( sz.cy, line_sy );
	}

	s32 psx = ( p->pad_pxl_sx );
	s32 psy = ( p->pad_pxl_sy );
	s32 ox  = (           p->scroll_pxl_tabbed_x );
	s32 oy  = ( line_y  - p->scroll_cch_tabbed_y ) * p->cell_pxl_sy;
	s32 osy = ( line_sy                          ) * p->cell_pxl_sy;

	oy -= p->offset_pxl_y;
 
	{ // Text

		s32 x  = psx - ox;
		s32 y  = psy + oy;
		s32 sx = p->canvas_pxl_sx;
		s32 sy = p->canvas_pxl_sy;

		if (
			( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
			&&
			( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		)
		{
			 x += p->number_pxl_sx + p->number_pad_pxl_sx;
			sx -= p->number_pxl_sx + p->number_pad_pxl_sx;
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			y += ( p->canvas_pxl_sy - p->cell_pxl_sy ) / 2;
		}

		s32 text_fy = line_y;
		s32 text_ty = line_y + line_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", text_fy, text_ty );

		// [x] : this section is called many times than needed

		while( 1 )
		{//break;
//n_win_txtbox_debug_count( p );

			n_win_txtbox_draw_singleline( p, text_fy, x, y, sx, p->cell_pxl_sy );

			text_fy++;
			if ( text_fy >= text_ty )
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				break;
			}

			y += p->cell_pxl_sy;
			if ( y >= sy )
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				break;
			}

		}

	} // Text

/*
	{ // Mask Debug

		RECT r = n_win_rect_set( NULL, 0,0, p->client_pxl_sx,p->client_pxl_sy );
		n_win_clear( p->hwnd, p->hdc, &r, COLOR_BTNFACE );

	} // Mask Debug
*/

	{ // Sync
//n_gdi_doublebuffer_simple_exit();

		s32 redraw_x  = 0;
		s32 redraw_y  = 0;
		s32 redraw_sx = 0;
		s32 redraw_sy = 0;

		if ( nonclient )
		{
			n_win_rect_expand_size( r, &redraw_x, &redraw_y, &redraw_sx, &redraw_sy );
		} else {
			redraw_x  = psx;
			redraw_y  = psy + oy;
			redraw_sx = p->canvas_pxl_sx + 1;
			redraw_sy = osy;
		}

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		{
			n_gdi_doublebuffer_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		{
			n_gdi_doublebuffer_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
		{
			n_gdi_doublebuffer_simple_visible();
			n_gdi_doublebuffer_simple_exit_partial( redraw_x, redraw_y, redraw_sx, redraw_sy );
		} else
		if ( getdc_onoff )
		{
			SelectObject( p->hdc, p_hfont );
			ReleaseDC( p->hwnd, p->hdc );
		}

		p->hdc = NULL;

	} // Sync


	// [Needed] : after text is drawn

	if ( ( p->debug_onoff == false )&&( nonclient ) )
	{
		n_win_txtbox_draw_scrollbars( p, false );
	}


	if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
	{
		HWND hwnd = GetParent( p->hwnd );

		HDC hdc = GetDC( hwnd );

		RECT rect; GetClientRect( hwnd, &rect );
		n_win_txtbox_frame( hdc, &rect, p->scale, p->color_border___flat );

		ReleaseDC( hwnd, hdc );
	}

/*
static int count = 0; count++;
n_win_txtbox_hwndprintf_literal
(
	p,
	"Count %d"
	" : "
	"Selection : %d %d %d %d"
	" : "
	"Hover : %d %d"
	" : "
	"Drag %d : %d %d"
	"",
	count,
	p->select_cch_x, p->select_cch_y, p->select_cch_sx, p->select_cch_sy,
	p->hover_cch_x, p->hover_cch_y,
	p->shift_dragging, p->drag_cch_x, p->drag_cch_y
);
*/

//n_win_txtbox_hwndprintf_literal( p, "%d", p->txt.sx );


//n_win_txtbox_hwndprintf_literal( p, "%d", n_posix_tickcount() - benchmark );


	return;
}

void
n_win_txtbox_caret_on_timer( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	bool redraw = false;

	if ( p->ime_onoff )
	{

		if ( p->caret_onoff )
		{
			p->caret_onoff = false;
		} else {
			p->caret_onoff =  true;
		}

		redraw = true;

	} else {

		p->caret_onoff =  true;

	}

	if ( p->hwnd != GetFocus() )
	{
		n_win_txtbox_caret_onoff( p );
	}


	if ( redraw )
	{
		n_win_txtbox_metrics_caret( p );
		n_win_txtbox_draw_selection( p );
	}
//n_win_txtbox_refresh( p );


	return;
}




#define N_WIN_TXTBOX_LINE_ADD 0
#define N_WIN_TXTBOX_LINE_MOD 1
#define N_WIN_TXTBOX_LINE_DEL 2
#define N_WIN_TXTBOX_LINE_GET 3
#define N_WIN_TXTBOX_LINE_SET 4
#define N_WIN_TXTBOX_LINE_CAT 5
#define N_WIN_TXTBOX_LINE_CCH 6

#define n_win_txtbox_line_add( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_ADD )
#define n_win_txtbox_line_mod( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_MOD )
#define n_win_txtbox_line_del( p, y    ) n_win_txtbox_line( p, y, 0, N_WIN_TXTBOX_LINE_DEL )
#define n_win_txtbox_line_get( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_GET )
#define n_win_txtbox_line_set( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_SET )
#define n_win_txtbox_line_cat( p, y, s ) n_win_txtbox_line( p, y, s, N_WIN_TXTBOX_LINE_CAT )
#define n_win_txtbox_line_cch( p, y    ) n_win_txtbox_line( p, y, 0, N_WIN_TXTBOX_LINE_CCH )

int
n_win_txtbox_line( n_win_txtbox *p, s32 y, n_posix_char *str, int mode )
{

	if ( p == NULL ) { return 0; }

	if ( n_txt_error( &p->txt ) ) { return 0; }


	if ( mode == N_WIN_TXTBOX_LINE_ADD )
	{
		n_txt_add( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_MOD )
	{
		n_txt_mod( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_DEL )
	{
		n_txt_del( &p->txt, y );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_GET )
	{

		if ( str == NULL ) { return 0; } else { n_string_truncate( str ); }

		n_string_copy( n_txt_get( &p->txt, y ), str );

		return 0;

	} else
	if ( mode == N_WIN_TXTBOX_LINE_SET )
	{
		n_txt_set( &p->txt, y, str );
	} else
	if ( mode == N_WIN_TXTBOX_LINE_CAT )
	{

		// [!] : selection only

		if ( y != p->select_cch_y ) { return 0; }


		n_posix_char *line  = n_txt_get( &p->txt, p->select_cch_y );
		s32           cch_f = n_posix_strlen( line );
		s32           cch_t = n_posix_strlen( str  );
		s32           cch   = cch_f + cch_t;
		n_posix_char *s     = n_string_alloccopy( cch, line );


		if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { p->select_cch_sx = cch_f; }

		p->select_cch_sx = n_posix_minmax( 0,cch_f, p->select_cch_sx );
		p->select_cch_x  = n_posix_minmax( 0,cch_f, p->select_cch_x  );

//n_posix_debug_literal( "%s : %s", line, str );

		n_posix_sprintf_literal( &s[ p->select_cch_x ], "%s%s", str, &line[ p->select_cch_x + p->select_cch_sx ] );
		n_txt_mod_fast( &p->txt, p->select_cch_y, s );

		//n_memory_free( s );

		if ( false == n_win_txtbox_is_caret_tail( p ) )
		{
			n_win_txtbox_unselect( p );
		}

		p->select_cch_x  = p->select_cch_x + cch_t;
		p->select_cch_sx = 0;

	} else
	if ( mode == N_WIN_TXTBOX_LINE_CCH )
	{

		return n_posix_strlen( n_txt_get( &p->txt, y ) );

	} // else


	//n_win_txtbox_txt_stream( p );
	n_win_txtbox_metrics_maxwidth( p, p->select_cch_y, 1 );


	return 0;
}

n_posix_char*
n_win_txtbox_line_get_new( n_win_txtbox *p, s32 y )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	size_t        cch = n_win_txtbox_line_cch( p, y );
	n_posix_char *str = n_string_path_new( cch );


	n_win_txtbox_line_get( p, y, str );


	return str;
}

#define n_win_txtbox_selection_mod( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_MOD )
#define n_win_txtbox_selection_del( p    ) n_win_txtbox_selection( p, NULL, N_WIN_TXTBOX_LINE_DEL )
#define n_win_txtbox_selection_get( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_GET )
#define n_win_txtbox_selection_cat( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_CAT )
#define n_win_txtbox_selection_cch( p    ) n_win_txtbox_selection( p, NULL, N_WIN_TXTBOX_LINE_CCH )

int
n_win_txtbox_selection( n_win_txtbox *p, n_posix_char *str, int mode )
{

	if ( p == NULL ) { return 0; }


	if ( mode == N_WIN_TXTBOX_LINE_GET ) { n_string_truncate( str ); }


	// [!] : don't use n_win_txtbox_is_selected( p ) : single line is exluded

	if ( p->select_cch_sy <= 0 ) { return 0; }


	return n_win_txtbox_line( p, p->select_cch_y, str, mode );
}

n_posix_char*
n_win_txtbox_selection_new( n_win_txtbox *p )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	size_t        cch = n_win_txtbox_selection_cch( p );
	n_posix_char *str = n_string_path_new( cch );


	n_win_txtbox_selection_get( p, str );


	return str;
}

void
n_win_txtbox_edit_undo( n_win_txtbox *p, bool reverse )
{

	if ( p == NULL ) { return; }


	if ( reverse )
	{

		if ( n_txt_error( &p->txt_undo ) ) { return; }

		n_win_txtbox_unselect( p );

		n_win_txtbox_txt_copy( p, &p->txt_undo, &p->txt, true );

		n_win_txtbox_select( p, p->undo_cch_x,p->undo_cch_y,p->undo_cch_sx,p->undo_cch_sy );

		p->line_min_onoff = p->undo_line_min_onoff;
		p->line_max_onoff = p->undo_line_max_onoff;
		p->line_min_cch_x = p->undo_line_min_cch_x;
		p->line_max_cch_x = p->undo_line_max_cch_x;

		p->undo_onoff = false;

	} else {

		p->undo_cch_x  = p->select_cch_x;
		p->undo_cch_y  = p->select_cch_y;
		p->undo_cch_sx = p->select_cch_sx;
		p->undo_cch_sy = p->select_cch_sy;

		p->undo_line_min_onoff = p->line_min_onoff;
		p->undo_line_max_onoff = p->line_max_onoff;
		p->undo_line_min_cch_x = p->line_min_cch_x;
		p->undo_line_max_cch_x = p->line_max_cch_x;

		p->undo_onoff = true;

		n_win_txtbox_txt_copy( p, &p->txt, &p->txt_undo, false );

//n_txt_save_literal( &p->txt_undo, "undo.txt" );
	}


	return;
}

void
n_win_txtbox_edit_copy( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy == 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

		if ( n_string_is_empty( line ) )
		{

			n_clipboard_text_set( p->hwnd, N_STRING_CRLF );

		} else
		if ( p->select_cch_sx )
		{

			n_posix_char *text = n_string_carboncopy( line );

			s32 tail = n_win_txtbox_select_tail_get( p );

			n_string_terminate( text, tail );
			n_clipboard_text_set( p->hwnd, &text[ p->select_cch_x ] );

			n_memory_free( text );

//n_win_txtbox_hwndprintf_literal( p, "Copy : %d %d : %d", p->select_cch_x, p->select_cch_sx, tail );

		}

	} else {

		s32 sy = p->select_cch_sy;
		if ( sy == N_WIN_TXTBOX_ALL ) { sy = p->txt.sy; }


		s32 y   = 0;
		s32 cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->line_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->line_max_cch_x );
				}
			}

			cch += n_posix_strlen( text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_strlen( N_STRING_CRLF );

		}

		n_posix_char *clipboard = n_string_new_fast( cch );

		y = cch = 0;
		while( 1 )
		{

			n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y + y ) );

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{
				if ( y == 0 )
				{
					n_posix_sprintf_literal( text, "%s", &text[ p->line_min_cch_x ] );
				} else
				if ( y == ( sy - 1 ) )
				{
					n_string_terminate( text, p->line_max_cch_x );
				}
			}

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", text );

			n_memory_free( text );

			y++;
			if ( y >= sy ) { break; }

			cch += n_posix_sprintf_literal( &clipboard[ cch ], "%s", N_STRING_CRLF );

		}

		n_clipboard_text_set( p->hwnd, clipboard );

		n_memory_free( clipboard );

	}


	return;
}

void
n_win_txtbox_edit_del( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sy == 0 ) { return; }


	if ( p->select_cch_sy == 1 )
	{

		n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
		s32           cch  = n_posix_strlen( line );


		if ( cch == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Empty Line" );

			if ( p->select_cch_y == 0 ) { return; }

			n_win_txtbox_line_del( p, p->select_cch_y );

			s32 tail = n_posix_strlen( n_txt_get( &p->txt, p->select_cch_y - 1 ) );

			n_win_txtbox_select_set( p, tail, p->select_cch_y - 1, 0, 1, false );

		} else
		if ( p->select_cch_sx == 0 )
		{
//n_win_txtbox_hwndprintf_literal( p, "Single : Not Selected : %d %d", p->select_cch_x, p->select_cch_sx );

			if ( p->select_cch_x == 0 )
			{

				if ( p->select_cch_y == 0 ) { return; }

				n_posix_char *p_line = n_txt_get( &p->txt, p->select_cch_y - 1 );
				s32           p_cch  = n_posix_strlen( p_line );
				n_posix_char *text   = n_string_new_fast( cch + p_cch );

				n_posix_sprintf_literal( text, "%s%s", p_line, line );

				n_win_txtbox_line_mod( p, p->select_cch_y - 1, text );
				n_win_txtbox_line_del( p, p->select_cch_y );

				n_memory_free( text );

				n_win_txtbox_select_set( p, p_cch, p->select_cch_y - 1, 0, 1, false );

			} else {

				s32 unit = p->select_cch_x;
				n_win_txtbox_caret_l( line, p->select_cch_x, &unit );
				unit = p->select_cch_x - unit;

				n_string_copy( &line[ p->select_cch_x ], &line[ p->select_cch_x - unit ] );

				n_win_txtbox_select_set( p,  p->select_cch_x - unit, p->select_cch_y, 0, 1, false );

			}

		} else {
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d : %d", p->select_cch_x, p->select_cch_sx, cch );
//n_win_txtbox_hwndprintf_literal( p, "Single : Selected : %d %d", p->line_min_onoff, p->line_max_onoff );

			s32 tail = n_win_txtbox_select_tail_get( p );

			n_string_copy( &line[ tail ], &line[ p->select_cch_x ] );

			if ( false == n_win_txtbox_is_caret_tail( p ) )
			{
				n_win_txtbox_unselect( p );
			}

			n_win_txtbox_select_set( p,  p->select_cch_x, p->select_cch_y, 0, 1, false );

		}

	} else {
//n_win_txtbox_hwndprintf_literal( p, " Multiple : %d %d ", p->select_cch_y, p->drag_cch_y );

		bool line_add = true;

		s32 i = p->select_cch_y + p->select_cch_sy - 1;
		while( 1 )
		{

			if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
			{

				line_add = false;

				n_posix_char *text = n_string_carboncopy( n_txt_get( &p->txt, i ) );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_onoff, p->line_max_onoff );

				if ( i == p->select_cch_y )
				{

					int nextline = i + 1;

					n_posix_char *cat1 = n_string_carboncopy( n_txt_get( &p->txt, nextline ) );

					size_t cch1 = n_posix_strlen( text );
					size_t cch2 = n_posix_strlen( cat1 );

					n_posix_char *cat2 = n_string_alloccopy( cch1 + cch2, text );

					size_t line_min_cch_x = p->line_min_cch_x;
					if ( line_min_cch_x <= n_posix_strlen( cat2 ) )
					{
						n_string_terminate( cat2, line_min_cch_x );
					}

					n_posix_strcat( cat2, cat1 );

					n_win_txtbox_line_del( p, nextline );
					n_win_txtbox_line_mod( p, i, cat2 );

					n_memory_free( cat1 );
					n_memory_free( cat2 );

				} else
				if ( i == ( p->select_cch_y + p->select_cch_sy - 1 ) )
				{

					size_t line_max_cch_x = p->line_max_cch_x;
					if ( line_max_cch_x <= n_posix_strlen( text ) )
					{
						n_posix_sprintf_literal( text, "%s", &text[ line_max_cch_x ] );
						n_win_txtbox_line_mod( p, i, text );
					}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", line_max_cch_x, n_posix_strlen( text ) );

				} else {

					n_win_txtbox_line_del( p, i );

				}

				n_memory_free( text );

			} else {

				n_win_txtbox_line_del( p, i );

			}

			i--;
			if ( i < p->select_cch_y ) { break; }
		}


		// [!] : Edit Control compatible behavior

		s32 select_x = p->select_cch_x;
		s32 select_y = p->select_cch_y;

		if ( line_add )
		{
//n_win_txtbox_hwndprintf_literal( p, " A " );
			n_win_txtbox_line_add( p, select_y, N_STRING_EMPTY );
			n_win_txtbox_select( p, select_x, select_y, 0,1 );
		} else
		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " B : %d : %d ", p->line_min_cch_x, select_y );
			n_win_txtbox_select( p, p->line_min_cch_x, select_y, 0,1 );
		}

		n_win_txtbox_select2drag( p );

		p->shift_dragging = 0;

		n_win_txtbox_line_minmax_reset( p );

	}


	return;
}

void
n_win_txtbox_edit_cut( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->select_cch_sx == 0 ) { return; }

	n_win_txtbox_edit_copy( p );
	n_win_txtbox_edit_del ( p );


	return;
}

void
n_win_txtbox_edit_paste( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	s32 cch = n_clipboard_text_get( p->hwnd, NULL );
	if ( cch == 0 ) { return; }


	if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }


	n_txt txt; n_txt_zero( &txt );

	{

		n_posix_char *text = n_string_new_fast( cch );
		n_clipboard_text_get( p->hwnd, text );

		n_txt_load_onmemory( &txt, text, ( cch + 1 ) * sizeof( n_posix_char ) );

	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )||( txt.sy <= 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Single " );

		n_posix_char *line = n_txt_get( &txt, 0 );

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM )
		{
			bool ret = n_win_txtbox_filename_is_safe( line );
			if ( ret == false ) { return; }
		}

		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL )
		{
			bool ret = n_win_txtbox_filename_is_digit( line );
			if ( ret == false ) { return; }
		}

		if ( n_string_is_empty( line ) )
		{
			n_win_txtbox_line_add( p, p->select_cch_y, line );
		} else {
			n_win_txtbox_selection_cat( p, line );
		}

		n_txt_free( &txt );

		n_win_txtbox_line_minmax_reset( p );


		return;
	}
//n_win_txtbox_hwndprintf_literal( p, " Multi " );


	n_posix_char *half_upper = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
	n_posix_char *half_lower = n_string_carboncopy( n_txt_get( &p->txt, p->select_cch_y ) );
//n_win_txtbox_hwndprintf_literal( p, " %s : %s ", half_upper, half_lower );

	n_string_terminate( half_upper, p->select_cch_x );
	n_string_copy( &half_lower[ p->select_cch_x ], half_lower );


	size_t y = 0;
	while( 1 )
	{//break;

		n_posix_char *line = n_txt_get( &txt, y );

		if ( y == 0 )
		{

			n_posix_char *s = n_string_new_fast( n_posix_strlen( half_upper ) + n_posix_strlen( line ) );

			n_posix_sprintf_literal( s, "%s%s", half_upper, line );

			n_win_txtbox_line_mod( p, p->select_cch_y + y, s );

			n_memory_free( s );

		} else
		if ( y == ( txt.sy - 1 ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " %s ", half_lower );

			s32 cch_1 = n_posix_strlen( half_lower );
			s32 cch_2 = n_posix_strlen( line       );
			s32 cch   = cch_1 + cch_2;

			n_posix_char *s = n_string_new_fast( cch );

			n_posix_sprintf_literal( s, "%s%s", line, half_lower );

			n_win_txtbox_line_add( p, p->select_cch_y + y, s );

			n_memory_free( s );

			n_win_txtbox_select( p, cch_2, p->select_cch_y + y, 0,1 );
			n_win_txtbox_select2drag( p );

		} else {

			n_win_txtbox_line_add( p, p->select_cch_y + y, line );

		}

		y++;
		if ( y >= txt.sy ) { break; }
	}

	n_memory_free( half_upper );
	n_memory_free( half_lower );


	n_win_txtbox_line_minmax_reset( p );


	n_txt_free( &txt );


	n_win_txtbox_txt_stream( p, true );


	return;
}

bool
n_win_txtbox_edit_input( n_win_txtbox *p, int vk )
{

	if ( p == NULL ) { return false; }


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	BYTE         key[ 256 ]; GetKeyboardState( key );
	n_posix_char str[ 100 ];

#ifdef UNICODE

	ToUnicode( vk,0,key, str,100, 0 );

#else // #ifdef UNICODE

	WORD w;
	ToAscii  ( vk,0,key, &w, 0 );
	str[ 0 ] = w;
	str[ 1 ] = N_STRING_CHAR_NUL;

	// [x] : Buggy : ANSI version on NT : invalid character will be returned

	if ( p->is_nt )
	{
		wchar_t wstr[ 100 ];
		ToUnicode( vk,0,key, wstr,100, 0 );
		if ( wstr[ 0 ] == L'\0' ) { return false; }
	}

#endif // #ifdef UNICODE

//n_posix_debug_literal( " %d ", str[ 0 ] );

//n_posix_debug_literal( "%d : %d : %d : %x", vk, ImmGetVirtualKey( p->hwnd ), n_win_is_input( VK_CONVERT ), (int) str[ 0 ] );

	if ( n_string_is_empty( str ) ) { return false; }


	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->select_cch_x );

		if ( false == n_win_txtbox_filename_is_safe_char( str[ 0 ] ) ) { return false; }

		if (
			( str[ 0 ] == n_posix_literal( ' ' ) )
			&&
			(
				( n_string_is_empty( n_txt_get( &p->txt, 0 ) ) )
				||
				( p->select_cch_x == 0 )
				||
				(
					( p->select_cch_sx == N_WIN_TXTBOX_ALL )
					||
					( p->select_cch_sx == n_posix_strlen( n_txt_get( &p->txt, 0 ) ) )
				)
			)
		)
		{
			return false;
		}

	} else
	if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ) )
	{

		if (
			( false == n_string_is_digit( str, 0 ) )
			&&
			( 0x08 != str[ 0 ] )
		)
		{
			return false;
		}

	}


	if ( 0x08 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x08 : BS

		n_win_txtbox_edit_del( p );

	} else
	if ( 0x09 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x09 : TAB

		//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return true; }

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

	} else
	if ( 0x0d == str[ 0 ] )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { return true; }


		// [!] : ASCII Control Code : 0x0d CR

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		if ( p->select_cch_x == 0 )
		{

			n_win_txtbox_line_add( p, p->select_cch_y, N_STRING_EMPTY );
			n_win_txtbox_select  ( p, p->select_cch_x, p->select_cch_y + 1, 0, 1 );

		} else {

			n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

			n_win_txtbox_line_add( p, p->select_cch_y + 1, &line[ p->select_cch_x ] );
			n_string_terminate( line, p->select_cch_x );

			n_win_txtbox_select_set( p, 0, p->select_cch_y + 1, 0, 1, false );

		}

		//s32 last = n_win_scrollbar_position_last_unit( &p->vscr );
		//n_win_scrollbar_scroll_unit( &p->vscr, last, N_WIN_SCROLLBAR_SCROLL_SEND );

	} else
	if ( 0x1b == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x1b ESC

		return false;

	} else
	if ( 0x16 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x16 Synchronous Idle

		return false;

	} else
	//
	{
//n_win_txtbox_hwndprintf_literal( p, " %s ", str );

		if ( n_win_txtbox_is_selected( p ) ) { n_win_txtbox_edit_del( p ); }

		n_win_txtbox_selection_cat( p, str );

	}


	return true;
}




void
n_win_txtbox_refresh_optimized_init( n_win_txtbox *p )
{

	p->prv_scr_x  = p->scroll_pxl_tabbed_x;
	p->prv_scr_y  = p->scroll_cch_tabbed_y;
	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_txt_sx = p->txt.sx;
	p->prv_txt_sy = p->txt.sy;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_drag   = p->shift_dragging;
	p->prv_caret  = p->caret_pxl_x;


	return;
}

void
n_win_txtbox_refresh_optimized_exit( n_win_txtbox *p, bool autoscroll_onoff )
{

	bool        moved = ( p->prv_sel_y != p->select_cch_y );
	bool     selected = ( ( p->prv_sel_sy != 1                      )||( p->select_cch_sy  != 1                      ) );
	bool     scrolled = ( ( p->prv_scr_x  != p->scroll_pxl_tabbed_x )||( p->prv_scr_y      != p->scroll_cch_tabbed_y ) );
	bool      updated = ( ( p->prv_txt_sx != p->txt.sx              )||( p->prv_txt_sy     != p->txt.sy              ) );
	bool autoscrolled = false;


	// [!] : keyboard input only
	//
	//	mouse input uses n_win_txtbox_drag()

	if ( autoscroll_onoff )
	{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->shift_dragging );


		if ( p->is_font_monospace )
		{

			s32 stop_sx = p->select_cch_x;
			if ( ( p->shift_dragging == VK_RIGHT )&&( p->select_cch_sx > 0 ) ) { stop_sx += p->select_cch_sx; }

			s32 stop_sy = p->select_cch_y;
			if ( p->line_min_onoff ) { stop_sy += p->select_cch_sy - 1; }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", stop_sy, p->select_cch_y );

			s32 fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
			s32 tx = 0; n_win_txtbox_tabbedmetrics( p, stop_sy, -1,stop_sx,-1, NULL,NULL,&tx );
			s32 fy = p->scroll_cch_tabbed_y;
			s32 ty = p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy;


//n_win_txtbox_hwndprintf_literal( p, " N/A : %d ", tx );

			if ( stop_sy <  fy )
			{
//n_win_txtbox_hwndprintf_literal( p, " Top : %d ", ty );

				autoscrolled = true;
				n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y );

			} else
			if ( stop_sy >= ty )
			{
//n_win_txtbox_hwndprintf_literal( p, " Bottom : %d ", ty );

				autoscrolled = true;
				n_win_txtbox_scroll( p, fx * p->font_pxl_sx, p->select_cch_y - p->page_cch_tabbed_sy + 1 );

			}


			// [Needed] : for combination x and y

			fy = p->scroll_cch_tabbed_y;


			if ( tx >= ( ( p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx ) / p->font_pxl_sx ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", tx );

				autoscrolled = true;
				n_win_txtbox_scroll( p, ( tx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx, fy );

			} else
			if ( fx > tx )
			{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", tx );

				autoscrolled = true;
				n_win_txtbox_scroll( p, tx * p->font_pxl_sx, fy );

			}

		} else {

			s32 scr_y = p->scroll_cch_tabbed_y;
			s32 sel_y = p->select_cch_y;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, sel_y ) );

			// [Patch] : caret information will be invalid
			n_win_txtbox_draw( p );

			if ( p->prv_caret < p->caret_pxl_x )
			{
//n_win_txtbox_hwndprintf_literal( p, " Right : %d ", p->scroll_pxl_tabbed_x + p->caret_pxl_x );

				s32 target_x = p->canvas_real_pxl_sx + ( p->number_pxl_sx + p->number_pad_pxl_sx );
				if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) { target_x -= p->font_pxl_sx; }
				if ( p->caret_pxl_x > target_x )
				{
//n_win_txtbox_hwndprintf_literal( p, " Right : Scroll : %d : %d ", p->caret_pxl_x, p->canvas_real_pxl_sx );
					autoscrolled = true;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x + ( p->caret_pxl_x - target_x ), scr_y );
				}

			} else
			if ( p->prv_sel_x > p->select_cch_x )
			{
//n_win_txtbox_hwndprintf_literal( p, " Left : %d ", p->caret_pxl_x );

//n_win_txtbox_scroll( p, 0, 0 );

				n_posix_char *str = n_win_txtbox_line_get_new( p, sel_y );
				str[ p->prv_sel_x    ] = N_STRING_CHAR_NUL;
				SIZE size_prv = n_win_txtbox_size_text( p, str );
				str[ p->select_cch_x ] = N_STRING_CHAR_NUL;
				SIZE size_cur = n_win_txtbox_size_text( p, str );
				n_string_free( str );
//n_win_txtbox_hwndprintf_literal( p, " Left : %d : %d ", p->caret_pxl_x, size_prv.cx - size_cur.cx );

				s32 target_x = p->caret_pxl_x - ( p->number_pxl_sx + p->number_pad_pxl_sx );
				if ( target_x < ( size_prv.cx - size_cur.cx ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " Left : Scroll " );
					autoscrolled = true;
					n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x - ( size_prv.cx - size_cur.cx ), scr_y );
				}

			}

		}

	}


//n_win_txtbox_hwndprintf_literal( p, " Moved %d : Selected %d ", moved, selected );
	if ( moved )
	{
//n_win_txtbox_hwndprintf_literal( p, "Prv %d %d : Cur %d %d ", p->prv_sel_y, p->prv_sel_sy, p->select_cch_y, p->select_cch_sy );

		n_win_txtbox_caret_onoff( p );

		n_win_timer_init( p->hwnd, p->caret_timer, p->caret_msec );

		if ( false == ( selected | scrolled | updated | autoscrolled ) )
		{

			bool inner_prv;
			if ( ( p->prv_sel_y > p->scroll_cch_tabbed_y )&&( p->prv_sel_y < ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Inner " );
				inner_prv =  true;
			} else {
//n_win_txtbox_hwndprintf_literal( p, " Outer " );
				inner_prv = false;
			}

			bool inner_cur;
			if ( ( p->select_cch_y > p->scroll_cch_tabbed_y )&&( p->select_cch_y < ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) ) )
			{
//n_win_txtbox_hwndprintf_literal( p, " Inner " );
				inner_cur =  true;
			} else {
//n_win_txtbox_hwndprintf_literal( p, " Outer " );
				inner_cur = false;
			}

			s32 f = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
			s32 t = n_posix_max_s32( 1, 1 + abs( p->prv_sel_y - p->select_cch_y ) );
			if ( ( inner_prv )&&( inner_cur ) )
			{
				//
			} else {
				if ( ( inner_prv == false )&&( inner_cur ) )
				{
					t = 1;
				} else {
					//
				}
			}

//n_win_txtbox_hwndprintf_literal( p, " Moved : %d %d : %d %d ", f, t, p->scroll_cch_tabbed_y, p->page_cch_tabbed_sy );

			n_win_txtbox_draw_partial( p, NULL, false, f, t );

			return;
		}

	}

	if ( selected )
	{

		if ( false == ( moved | scrolled | updated | autoscrolled ) )
		{

			s32 f = n_posix_min_s32( p->prv_sel_y , p->select_cch_y  );
			s32 t = n_posix_max_s32( p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " Selected %d %d ", f, t );

			n_win_txtbox_draw_partial( p, NULL, false, f, t );

			return;
		} else
		if ( false == ( scrolled | updated | autoscrolled ) )
		{

			n_win_txtbox_draw_partial( p, NULL, false, p->   prv_sel_y, p->   prv_sel_sy );
			n_win_txtbox_draw_partial( p, NULL, false, p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " Selected/Moved " );

			return;
		}

	}

	if ( moved | selected | scrolled | updated | autoscrolled )
	{
//n_win_txtbox_hwndprintf_literal( p, " All " );
		n_win_txtbox_refresh( p );
	} else {
//n_win_txtbox_hwndprintf_literal( p, " Partial " );
//n_win_txtbox_debug_count( p );
		n_win_txtbox_draw_selection( p );
	}


	return;
}


bool
n_win_txtbox_menu_emptyline_cut( n_win_txtbox *p )
{

	bool ret = false;


	if ( p == NULL ) { return ret; }


	if ( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
	{

		n_win_txtbox_refresh_optimized_init( p );


		n_win_txtbox_edit_undo( p, false );

		n_win_txtbox_line_del( p, p->empty_line_selection );

		n_clipboard_text_set( p->hwnd, N_STRING_CRLF );

		p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


		n_win_txtbox_refresh_optimized_exit( p, true );


		ret = true;

	}


	return ret;
}

void
n_win_txtbox_menu_undo( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// [!] : don't use optimized_init()/exit()
	//
	//	heap curruption will occur when string size will shorten


	//n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, true );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	//n_win_txtbox_refresh_optimized_exit( p, true );


	n_win_txtbox_refresh( p );


	return;
}

void
n_win_txtbox_menu_delete( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_txtbox_menu_emptyline_cut( p ) ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );

	n_win_txtbox_edit_del( p );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_cut( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_txtbox_menu_emptyline_cut( p ) ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );

	n_win_txtbox_edit_cut( p );

	if ( ( p->prv_sel_sy > 1 )&&( p->select_cch_y < p->scroll_cch_tabbed_y ) )
	{
		n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->select_cch_y );
	}

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_copy( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_copy( p );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_paste( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );

	n_win_txtbox_edit_paste( p );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_selectall( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_select( p, 0, 0, N_WIN_TXTBOX_ALL, N_WIN_TXTBOX_ALL );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_insert( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_is_input( VK_SHIFT ) )
	{
		n_win_txtbox_menu_paste( p );
	}


	return;
}

#define N_WIN_TXTBOX_PROC_MENU_UNDO      0
#define N_WIN_TXTBOX_PROC_MENU_LINE1     1
#define N_WIN_TXTBOX_PROC_MENU_CUT       2
#define N_WIN_TXTBOX_PROC_MENU_COPY      3
#define N_WIN_TXTBOX_PROC_MENU_PASTE     4
#define N_WIN_TXTBOX_PROC_MENU_DELETE    5
#define N_WIN_TXTBOX_PROC_MENU_LINE2     6
#define N_WIN_TXTBOX_PROC_MENU_SELECTALL 7

void
n_win_txtbox_proc_menu_editbox( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	const int menu_offset = 0;

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Undo"       ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "---"        ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Cut"        ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Copy"       ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Paste"      ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Delete"     ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "---"        ) },
		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Select All" ) },

		{ N_WIN_MENU_NONE, false, false, NULL }

	};


//if ( msg == WM_MOUSEMOVE ) { n_win_hwndprintf_literal( hwnd, "%d %d", p->select_cch_sx, p->select_cch_sy ); }

	if ( n_txt_error( &p->txt_undo ) )
	{
		menu[ N_WIN_TXTBOX_PROC_MENU_UNDO ].gray =  true;
	} else {
		menu[ N_WIN_TXTBOX_PROC_MENU_UNDO ].gray = false;
	}


	if ( ( p->select_cch_sx == N_WIN_TXTBOX_ALL )||( p->select_cch_sx != 0 ) )
	{
		menu[ N_WIN_TXTBOX_PROC_MENU_CUT    ].gray = false;
		menu[ N_WIN_TXTBOX_PROC_MENU_COPY   ].gray = false;
		menu[ N_WIN_TXTBOX_PROC_MENU_DELETE ].gray = false;
	} else {
		menu[ N_WIN_TXTBOX_PROC_MENU_CUT    ].gray =  true;
		menu[ N_WIN_TXTBOX_PROC_MENU_COPY   ].gray =  true;
		menu[ N_WIN_TXTBOX_PROC_MENU_DELETE ].gray =  true;
	}


	if (
		( p->select_cch_sy == N_WIN_TXTBOX_ALL )
		||
		(
			( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
			&&
			( p->select_cch_sy == p->txt.sy )
		)
		||
		(
			( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			&&
			( p->select_cch_sx == n_posix_strlen( n_txt_get( &p->txt, 0 ) ) )
		)
	)
	{
		menu[ N_WIN_TXTBOX_PROC_MENU_SELECTALL ].gray =  true;
	} else {
		menu[ N_WIN_TXTBOX_PROC_MENU_SELECTALL ].gray = false;
	}


	if ( p->txt.readonly )
	{
		menu[ N_WIN_TXTBOX_PROC_MENU_UNDO   ].gray = true;
		menu[ N_WIN_TXTBOX_PROC_MENU_CUT    ].gray = true;
		menu[ N_WIN_TXTBOX_PROC_MENU_PASTE  ].gray = true;
		menu[ N_WIN_TXTBOX_PROC_MENU_DELETE ].gray = true;
	} else {
		menu[ N_WIN_TXTBOX_PROC_MENU_UNDO   ].gray = ( p->undo_onoff == false );
		menu[ N_WIN_TXTBOX_PROC_MENU_PASTE  ].gray = false;
	}


	if ( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
	{
		menu[ N_WIN_TXTBOX_PROC_MENU_CUT    ].gray = false;
		menu[ N_WIN_TXTBOX_PROC_MENU_DELETE ].gray = false;
	}


	int ret = n_win_menu_popup_proc( hwnd, msg, wparam, lparam, p->hmenu_editbox, menu, menu_offset );
	if ( ret < 0 ) { return; }


	switch( ret ) {

	case N_WIN_TXTBOX_PROC_MENU_UNDO :

		n_win_txtbox_menu_undo( p );

	break;

	case N_WIN_TXTBOX_PROC_MENU_LINE1 :

		//

	break;

	case N_WIN_TXTBOX_PROC_MENU_CUT :

		n_win_txtbox_menu_cut( p );

	break;

	case N_WIN_TXTBOX_PROC_MENU_COPY :

		n_win_txtbox_menu_copy( p );

	break;

	case N_WIN_TXTBOX_PROC_MENU_PASTE :

		n_win_txtbox_menu_paste( p );

	break;

	case N_WIN_TXTBOX_PROC_MENU_DELETE :

		n_win_txtbox_menu_delete( p );

	break;

	case N_WIN_TXTBOX_PROC_MENU_LINE2 :

		//

	break;

	case N_WIN_TXTBOX_PROC_MENU_SELECTALL :
//n_win_txtbox_debug_count( p );

		n_win_txtbox_menu_selectall( p );

	break;

	} // switch


	return;
}

#define N_WIN_TXTBOX_PROC_MENU_CARET 0

void
n_win_txtbox_proc_menu_linenum( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	const int menu_offset = 0;

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE, false, false, n_posix_literal( "Caret" ) },

		{ N_WIN_MENU_NONE, false, false, NULL }

	};


	int ret = n_win_menu_popup_proc( hwnd, msg, wparam, lparam, p->hmenu_linenum, menu, menu_offset );
	if ( ret < 0 ) { return; }

	switch( ret ) {

	case N_WIN_TXTBOX_PROC_MENU_CARET :

		n_win_txtbox_autofocus( p );
		n_win_txtbox_refresh( p );

	break;

	} // switch


	return;
}

void
n_win_txtbox_proc_mouse( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->mouse_input_stop_onoff ) { return; }


	switch( msg ) {


	case WM_MOUSEWHEEL :

		// [!] : don't use n_win_txtbox_is_hovered() : scrollbars will be excluded

		if ( p->is_captured == false )
		{
			if ( false == n_win_is_hovered( p->hwnd ) ) { break; }
		}

		int delta = n_win_scrollbar_wheeldelta( wparam, 0, true );

		double py = p->scroll_cch_tabbed_y;

		n_win_txtbox_line_scroll( p, p->scroll_cch_tabbed_y + delta );

		p->vscr.unit_pos = py * p->vscr.pixel_step;
		n_win_scrollbar_scroll_pixel( &p->vscr, delta * p->vscr.pixel_step, N_WIN_SCROLLBAR_SCROLL_AUTO );

//n_win_txtbox_hwndprintf_literal( p, " %d : %d %g %g ", delta, p->scroll_cch_tabbed_y, p->vscr.unit_pos, p->vscr.pixel_pos );

		n_win_scrollbar_draw_always( &p->vscr, true );
		n_win_txtbox_refresh( p );

	//break;
	case WM_MOUSEMOVE :

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{

			if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL )
			{

				if ( false == n_win_txtbox_is_hovered( p ) ) { break; }

				if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
				{
					if ( p->vscr.pressed_thumb ) { break; }
				}

				bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );
				n_win_txtbox_refresh( p );

				if ( ( ret == false )&&( p->select_cch_sy ) )
				{
					n_win_txtbox_message_redirect( p, hwnd, msg );
				}

			}

		} else {

			n_win_txtbox_message_redirect( p, hwnd, msg );

		}

	break;


	case WM_LBUTTONDBLCLK :
	case WM_MBUTTONDBLCLK :
	case WM_RBUTTONDBLCLK :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
	{

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		p->oneline_cache_onoff = false;


		//if ( p->style & N_WIN_TXTBOX_STYLE_DELAYED )
		{
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->focus_phase );

			if ( p->focus_phase_is_first )
			{
				p->focus_phase_is_first = false;
				p->focus_phase          = N_WIN_TXTBOX_FOCUS_GO;
			}

			if ( p->focus_phase != N_WIN_TXTBOX_FOCUS_GO )
			{
				p->focus_phase = N_WIN_TXTBOX_FOCUS_GO;
				if ( n_win_is_input( VK_MBUTTON ) ) { break; }
			}

		}


		static DWORD tripleclick_tmr  = 0;
		static UINT  tripleclick_pmsg = WM_NULL;
		static POINT tripleclick_pt   = { 0, 0 };


		if ( false == n_win_txtbox_is_hovered( p ) ) { break; }
//n_win_hwndprintf_literal( hwnd, "%d %d", p->hover_cch_x, p->hover_cch_y );


		if ( p->is_static_ownerdraw ) { SetFocus( p->hwnd ); }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( p->ime_composition_onoff )
			{

				n_win_txtbox_refresh_optimized_init( p );

				n_win_txtbox_unselect( p );
				n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

				n_win_txtbox_select2drag( p );

				n_win_txtbox_refresh_optimized_exit( p, false );


				HIMC himc = ImmGetContext( hwnd );

				n_win_txtbox_draw( p );

				COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
				ImmSetCompositionWindow( himc, &cf );

				ImmReleaseContext( hwnd, himc );

			} else
			if ( msg == WM_RBUTTONDOWN )
			{

				//n_win_menu_popup_show( p->hmenu_editbox, hwnd );

			} else
			if ( msg == WM_LBUTTONDBLCLK )
			{

				if ( p->is_hovered_linenum )
				{

					n_win_txtbox_refresh_optimized_init( p );

					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{
						p->empty_line_selection = p->hover_cch_y;
					} else {
						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_select2drag( p );
					}

					n_win_txtbox_refresh_optimized_exit( p, false );

					break;
				}


				// Triple-Click : Start

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = 0;
				} else {
					tripleclick_tmr = GetTickCount();
				}


				// [!] : for usability

				tripleclick_pmsg = WM_LBUTTONDBLCLK;

				GetCursorPos( &tripleclick_pt );


				if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
				{

					n_win_txtbox_refresh_optimized_init( p );

					p->empty_line_selection = p->hover_cch_y;

					n_win_txtbox_refresh_optimized_exit( p, false );

				} else {

					n_win_txtbox_refresh_optimized_init( p );

					s32 f,t;
					n_win_txtbox_select_word( p, p->hover_cch_x, p->hover_cch_y, &f, &t );
					n_win_txtbox_select( p, f, p->hover_cch_y, t - f, 1 );
					n_win_txtbox_select2drag( p );

					n_win_txtbox_refresh_optimized_exit( p, false );

				}

			} else
			if ( msg == WM_LBUTTONDOWN )
			{
//n_win_txtbox_debug_count( p );

				bool tripleclick_onoff = true;


				// Triple-Click : End

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = GetTickCount();
					tripleclick_onoff = false;
				} else {
					tripleclick_tmr = 0;
				}


				// [!] : for usability

				if ( tripleclick_pmsg != WM_LBUTTONDBLCLK )
				{
					tripleclick_onoff = false;
				} else {
					tripleclick_pmsg = WM_LBUTTONDOWN;
				}


				{

					int threshold_sx = 0;
					int threshold_sy = 0;
					n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

					POINT p;
					GetCursorPos( &p );

					if (
						( threshold_sx < abs( p.x - tripleclick_pt.x ) )
						||
						( threshold_sy < abs( p.y - tripleclick_pt.y ) )
					)
					{
						tripleclick_onoff = false;
					}

				}

				if ( tripleclick_onoff )
				{

					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{

						n_win_txtbox_refresh_optimized_init( p );

						p->empty_line_selection = p->hover_cch_y;

						n_win_txtbox_refresh_optimized_exit( p, false );

					} else {

						n_win_txtbox_refresh_optimized_init( p );

						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_select2drag( p );

						n_win_txtbox_refresh_optimized_exit( p, false );

					}

				} else {
//n_win_txtbox_hwndprintf_literal( p, " Single Click " );

					p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;

					p->is_dragging = false;


					n_win_txtbox_refresh_optimized_init( p );

					n_win_txtbox_message_redirect( p, hwnd, msg );

					if ( n_win_is_input( VK_SHIFT ) )
					{

						n_win_txtbox_drag( p );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " Dragging Start : %d : %d ", p->shift_dragging, p->prv_drag );

						n_win_txtbox_unselect( p );
						n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

						n_win_txtbox_select2drag( p );


						s32  y = p->select_cch_y;
						s32 tx = 0; n_win_txtbox_tabbedmetrics( p, y, -1,p->select_cch_x,-1, NULL,NULL,&tx );

						if ( tx < ( p->scroll_pxl_tabbed_x / p->font_pxl_sx ) )
						{
							n_win_txtbox_scroll( p, p->select_cch_x * p->font_pxl_sx, p->scroll_cch_tabbed_y );
						}

//n_win_txtbox_hwndprintf_literal( p, "%d %d", p->drag_cch_x, p->drag_cch_y );

					}

					n_win_txtbox_refresh_optimized_exit( p, false );


					p->hscr.stop_onoff = true;
					p->vscr.stop_onoff = true;

					p->is_captured = true;
					SetCapture( hwnd );

					p->drag_onoff = true;
					n_win_timer_init( hwnd, p->drag_timer, p->drag_msec );

				}

			} else { break; }

		} else {

			bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );


			n_win_txtbox_refresh( p );

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				n_win_scrollbar_refresh( &p->hscr );
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
			{
				n_win_scrollbar_refresh( &p->vscr );
			}


			if ( ( ret == false )&&( p->select_cch_sy ) )
			{
				n_win_txtbox_message_redirect( p, hwnd, msg );
			}

		}

	}
	break;

	case WM_TIMER :
	{

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != p->drag_timer ) { break; }


		// [!] : don't break for mouse capture

		bool is_hovered = n_win_txtbox_is_hovered( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_hovered );

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( p->is_captured == false ) { break; }


			// [!] : prevent drawing when keep on pressing

			static s32 p_scroll_y = -1;

			if ( p_scroll_y == p->scroll_cch_tabbed_y )
			{

				static s32 p_cursor_x = -1;
				static s32 p_cursor_y = -1;

				s32 cursor_x, cursor_y; n_win_cursor_position_relative( p->hwnd, &cursor_x, &cursor_y );
				if ( ( p_cursor_x == cursor_x )&&( p_cursor_y == cursor_y ) )
				{
					if ( is_hovered ) { break; }
				}

				p_cursor_x = cursor_x;
				p_cursor_y = cursor_y;

			}

			p_scroll_y = p->scroll_cch_tabbed_y;


//n_win_txtbox_debug_count( p );

			p->is_dragging = true;

			n_win_txtbox_refresh_optimized_init( p );

			n_win_txtbox_drag( p );
//is_hovered = false;
			if ( is_hovered )
			{
				n_win_txtbox_refresh_optimized_exit( p, false );
			} else {
				n_win_txtbox_refresh( p );
			}
//n_win_hwndprintf_literal( hwnd, " %d %d : %d %d ", p->hover_cch_x, p->hover_cch_y, p->drag_cch_x, p->drag_cch_y );

		}

	}
	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :
	{

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( msg == WM_RBUTTONUP )
			{
//n_win_txtbox_debug_count( p );

				if ( p->ime_composition_onoff ) { break; }


				// [Needed] : for multiple instances

				if ( n_win_txtbox_is_hovered( p ) )
				{
					p->menu_onoff = true;
					n_win_message_send( GetParent( p->hwnd ), WM_SETCURSOR, p->hwnd, 0 );

					if ( p->is_hovered_linenum )
					{
						n_win_menu_popup_show( p->hmenu_linenum, hwnd );
					} else {
						n_win_menu_popup_show( p->hmenu_editbox, hwnd );
					}
				}

			} else
			if ( msg == WM_MBUTTONUP )
			{

				if ( p->is_hovered_linenum )
				{
					n_win_txtbox_autofocus( p );
					n_win_txtbox_refresh( p );
				}

			} else
			if ( msg == WM_LBUTTONUP )
			{

				// [!] : don't do n_win_txtbox_is_hovered()
				//
				//	capture will not be released when a cursor goes outside of a window

				if ( p->is_captured )
				{

					if ( p->drag_onoff )
					{
						p->drag_onoff = false;
						n_win_timer_exit( hwnd, p->drag_timer );
					}

					ReleaseCapture();

					p->hscr.stop_onoff = false;
					p->vscr.stop_onoff = false;

					p->is_captured = false;
					p->is_dragging = false;

				}

			}

		}


		n_win_txtbox_message_redirect( p, hwnd, msg );

	}
	break;


	} // switch


	n_win_txtbox_proc_menu_editbox( hwnd, msg, wparam, lparam, p );
	n_win_txtbox_proc_menu_linenum( hwnd, msg, wparam, lparam, p );


	return;
}

static bool n_win_txtbox_printclient = false;

int
n_win_txtbox_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	// [Needed] : don't pass to DefWindowProc() when return value is non-zero


	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_CREATE :

		if ( false == p->is_static_ownerdraw )
		{
			// [Needed] : when button ownerdraw

			n_win_txtbox_proc_menu_editbox( hwnd, msg, wparam, lparam, p );
			n_win_txtbox_proc_menu_linenum( hwnd, msg, wparam, lparam, p );
		}

	break;


	case WM_SETTINGCHANGE :

		// [!] : you need to call this manually

		//n_win_txtbox_metrics( p );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE__DI_HDC )
		{
			p->hdc = di->hDC;
		}

		n_win_txtbox_draw_partial( p, &di->rcItem, true, -1, -1 );


		// [x] : conflict with n_win_smallbutton.c
/*
		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_refresh( &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_refresh( &p->vscr );
		}
*/
	}
	break;


	case WM_PRINTCLIENT :
	{

		if ( n_win_txtbox_printclient == false ) { break; }


		p->hdc = (HDC) wparam;

		//RECT r; GetWindowRect( p->hwnd, &r );

		HFONT pf = SelectObject( p->hdc, n_win_font_get( p->hwnd ) );

		n_win_txtbox_draw_partial( p, NULL, true, -1, -1 );

		SelectObject( p->hdc, pf );

	}
	break;


	case WM_SETCURSOR :

		if (
			( n_win_txtbox_is_hovered( p ) )
			&&
			( hwnd == n_win_cursor2hwnd() )
		)
		{

			n_win_txtbox_on_setcursor( p );

			return true;
		}

	break;


	case WM_EXITMENULOOP :

		p->menu_onoff = false;
		n_win_message_send( GetParent( p->hwnd ), WM_SETCURSOR, p->hwnd, 0 );

	break;


	} // switch


	if ( p->is_static_ownerdraw ) { n_win_txtbox_proc_mouse( hwnd, msg, wparam, lparam, p ); }


	if ( p->mouse_input_stop_onoff == false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_proc( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


	return 0;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_txtbox *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }
#else  // #ifdef _WIN64
	n_win_txtbox *p = (void*) n_win_property_get( hwnd, N_WIN_TXTBOX_NAMESPACE );
	if ( p == NULL ) { return 0; }
#endif // #ifdef _WIN64


	// [x] : Static Control's Limitation
	//
	//	[ Unsupported Events ]
	//	WM_*MOUSE*
	//	WM_*FOCUS
	//	WM_SETTINGCHANGE
	//
	//	use button control ownerdraw instead


	// [x] : Button Control's Limitation
	//
	//	focus events are auto-set
	//	flickering when resized


	switch( msg ) {


	case 648 : // WM_IME_REQUEST
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %x ", wparam, lparam );

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		if ( wparam == IMR_RECONVERTSTRING )
		{

			if ( false == n_win_txtbox_is_selected( p ) ) { break; }


			// [Needed] : crash prevention

			if ( p->select_cch_sy > 1 )
			{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %d ", p->line_min_onoff, p->line_max_onoff );

				bool min_onoff = p->line_min_onoff;
				//bool max_onoff = p->line_max_onoff;

				n_win_txtbox_unselect( p );

				if ( min_onoff ) { p->select_cch_y--; }
				//if ( max_onoff ) { p->select_cch_y++; }

				n_win_txtbox_refresh( p );

				break;
			}


			n_posix_char *line     = n_txt_get( &p->txt, p->select_cch_y );
			n_posix_char *word     = n_string_carboncopy( &line[ p->select_cch_x ] );

			if ( p->select_cch_sx ) { n_string_terminate( word, p->select_cch_sx ); }

			s32           word_cch = n_posix_strlen( word ) + 1;
			s32           word_cb  = sizeof( n_posix_char    ) * word_cch;
			s32           rcnv_cb  = sizeof( RECONVERTSTRING );
			u8           *data     = (void*) lparam;
			LRESULT       lret     = rcnv_cb + word_cb;

			if ( data != NULL )
			{

				RECONVERTSTRING rcs = { rcnv_cb, 0, word_cch,rcnv_cb, word_cch,0, word_cch,0, };
				s32             i   = 0;

				n_memory_copy( &rcs, &data[ i ], rcnv_cb ); i += rcnv_cb;
				n_memory_copy( word, &data[ i ], word_cb ); i += word_cb;

				n_win_message_send( hwnd, WM_IME_COMPOSITION, 0,0 );

				lret = (LRESULT) data;

			}

			n_memory_free( word );
			return lret;

		} else
		if ( wparam == 0x0005 ) // IMR_CONFIRMRECONVERTSTRING
		{

			// [!] : never sent

		} else
		if ( wparam == 0x0006 ) // IMR_QUERYCHARPOSITION
		{
//n_posix_debug_literal( " ! " );

			IMECHARPOSITION *icp = (void*) lparam;
			if ( icp == NULL ) { return false; }

			RECT            rect; n_win_rect_set( &rect, 0,0,0,0 );
			POINT           pt   = { p->ime.x, p->ime.y }; ClientToScreen( hwnd, &pt );
			IMECHARPOSITION ret  = { sizeof( IMECHARPOSITION ), 0, pt, p->cell_pxl_sy, rect };
			*icp = ret;

			return true;

		}

	}
	break;

	case WM_IME_STARTCOMPOSITION :

		p->ime_composition_onoff = true;

	case WM_IME_COMPOSITION :
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_COMPOSITION : %d %x ", wparam, lparam );

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		// [!] : this message can replace WM_IME_STARTCOMPOSITION and WM_IME_ENDCOMPOSITION

		// [ Mechanism ]
		//
		//	0x01b9 : Start
		//	0x1e00 : End
		//	0x1fb9 : Auto-Confirmation : End + Start

		const int start = GCS_DELTASTART | GCS_CURSORPOS | GCS_COMPCLAUSE | GCS_COMPATTR | GCS_COMPSTR | GCS_COMPREADSTR;
		const int end   = GCS_RESULTCLAUSE | GCS_RESULTSTR | GCS_RESULTREADCLAUSE | GCS_RESULTREADSTR;

		HIMC himc = ImmGetContext( hwnd );

		if ( lparam & end )
		{

			// [ Mechanism ] : ImmGetCompositionString()
			//
			//	this API doesn't write "\0"
			//
			//	return value will always be DBCS unit
			//	an ASCII character will be 1
			//	a  kanji character will be 2

			s32           n = ImmGetCompositionString( himc, GCS_RESULTSTR, NULL, 0 );
			n_posix_char *s = n_string_new( n * 4 );

			ImmGetCompositionString( himc, GCS_RESULTSTR, s, n );

//n_win_txtbox_hwndprintf_literal( p, " %s : %d", s, n );

			if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
			{
				bool ret = n_win_txtbox_filename_is_safe( s );
				if ( ret == false ) { n_memory_free( s ); break; }
			}

			if ( p->txt.readonly == false )
			{

				n_win_txtbox_refresh_optimized_init( p );

				if ( n_win_txtbox_is_selected( p ) )
				{
					n_win_txtbox_edit_del( p );
				}

				n_win_txtbox_selection_cat( p, s );
				//n_win_txtbox_refresh( p );
				n_win_txtbox_draw_selection( p );

				n_win_txtbox_refresh_optimized_exit( p, true );

			}

			n_memory_free( s );

			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );

		}

		if ( ( lparam == 0 )||( lparam & start ) )
		{

			LOGFONT lf = n_win_font_hwnd2logfont( p->hwnd );
			ImmSetCompositionFont( himc, &lf );

			COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
			ImmSetCompositionWindow( himc, &cf );

		}

		ImmReleaseContext( hwnd, himc );

	}
	break;

	case WM_IME_ENDCOMPOSITION :

		p->ime_composition_onoff = false;

	break;

	case WM_IME_NOTIFY :

		if ( wparam == IMN_SETOPENSTATUS )
		{
			n_win_txtbox_ime_watch( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime_onoff );
			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );
		}

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_SIZE :

		p->oneline_cache_onoff = true;

		// [Needed] : for border
		n_win_refresh( p->hwnd, true );

		n_win_txtbox_draw( p );
/*
{
RECT r; GetClientRect( p->hwnd, &r );
n_win_box( p->hwnd, NULL, &r, RGB( 0,255,0 ) );
}
*/
	break;


	case WM_TIMER :
//n_win_txtbox_debug_count( p );

		if ( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == p->caret_timer )
		{
//n_win_txtbox_debug_count( p );

			n_win_txtbox_caret_on_timer( p );

		} else
		if ( wparam == p->input_timer )
		{

			n_win_timer_exit( p->hwnd, p->input_timer );

			p->input_onoff = false;

			//n_win_txtbox_caret_onoff( p );

			n_win_txtbox_draw_selection( p );
//n_win_txtbox_refresh( p );

		}

	break;


	case WM_SETFOCUS :
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime_onoff );

		p->ime_onoff = n_win_ime_is_on( p->hwnd );

		if ( p->ime_onoff )
		{

			HIMC himc = ImmGetContext( hwnd );

			COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };
			ImmSetCompositionWindow( himc, &cf );

			ImmReleaseContext( hwnd, himc );

		}


		//if ( p->style & N_WIN_TXTBOX_STYLE_DELAYED )
		{
			p->focus_phase = N_WIN_TXTBOX_FOCUS_WAIT;
		}


		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

		n_win_txtbox_caret_on_timer( p );

		n_win_timer_init( p->hwnd, p->caret_timer, p->caret_msec );


		// [!] : for border

		n_win_txtbox_refresh( p );

	break;

	case WM_KILLFOCUS :

		//if ( p->style & N_WIN_TXTBOX_STYLE_DELAYED )
		{
			p->focus_phase = N_WIN_TXTBOX_FOCUS_NONE;
		}


		// [!] : for caret

		if ( p->is_static_ownerdraw ) { n_win_txtbox_refresh( p ); }


		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == p->hscr.hwnd )
		{

			s32 prv = p->scroll_pxl_tabbed_x;

			p->scroll_pxl_tabbed_x = wparam;

			if ( p->is_font_monospace )
			{
				p->scroll_pxl_tabbed_x = p->scroll_pxl_tabbed_x / p->font_pxl_sx * p->font_pxl_sx;
			}

			if ( prv != p->scroll_pxl_tabbed_x )
			{
				n_win_txtbox_refresh( p );
				n_win_scrollbar_draw_always( &p->hscr, true );
			}

		} else
		if ( (HWND) lparam == p->vscr.hwnd )
		{
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_shaft, p->vscr.pixel_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", fmod( p->vscr.pixel_shaft, p->vscr.pixel_thumb ) / p->vscr.pixel_thumb, p->vscr.pixel_modulo );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_pos, p->vscr.unit_pos );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->vscr.pressed, p->vscr.pressed_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_arrow );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.base_page / p->vscr.base_max, p->vscr.base_max );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );

//double d = ( p->vscr.pixel_max / p->vscr.pixel_page ) - ( p->vscr.pixel_max / p->vscr.pixel_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f ", d / p->vscr.pixel_max );

//double pixel_last = n_win_scrollbar_pixel_last( &p->vscr );
//n_win_txtbox_hwndprintf_literal( p, " %g %g ", pixel_last, p->vscr.pixel_pos );

			s32 prv = p->scroll_cch_tabbed_y;

			p->scroll_cch_tabbed_y = wparam / n_posix_max( 1, p->cell_pxl_sy );

			if ( prv != p->scroll_cch_tabbed_y )
			{
				n_win_txtbox_refresh( p );
				n_win_scrollbar_draw_always( &p->vscr, true );
			}

		}

	break;


	case WM_KEYUP :
//n_win_txtbox_debug_count( p );

		n_win_timer_init( p->hwnd, p->input_timer, p->input_msec );

	break;

	case WM_KEYDOWN :
	{
//n_win_txtbox_debug_count( p );

		p->oneline_cache_onoff = false;

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			int vk = wparam;


			// [Needed] : see WM_LBUTTONDOWN

			if ( vk == VK_SHIFT ) { break; }


			n_win_txtbox_refresh_optimized_init( p );


			if ( vk == VK_UP )
			{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", p->select_cch_y );

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				if ( n_win_is_input( VK_SHIFT ) )
				{

					p->shift_dragging = VK_UP;

					if (
						( ( p->line_min_onoff )||( p->line_max_onoff ) )
						&&
						( p->updown_selection_onoff )
					)
					{

						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						if ( p->line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " Min : VK_UP " );

							if ( sy <= 2 )
							{

								if ( ( sy == 2 )&&( p->reverse_selection_onoff ) )
								{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : .reverse_selection_onoff " );

									s32 targe_y = y + 1;
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %s ", n_txt_get( &p->txt, targe_y ) );

									sx = N_WIN_TXTBOX_ALL;

									p->line_min_onoff = false;
									p->line_max_onoff =  true;

									x = p->line_max_cch_x;
									p->line_min_cch_x = n_win_txtbox_select_up( p, x, targe_y );
									p->line_max_cch_x = x;

//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d %d ", p->line_min_cch_x, p->line_max_cch_x );

									n_win_txtbox_select( p, x,y,sx,sy );
									n_win_txtbox_select2drag( p );

								}

							} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_UP " );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_drag, p->shift_dragging );

								sy--;

								s32 target_y = y + sy - 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

								 x = p->line_max_cch_x = n_win_txtbox_select_up( p, p->line_max_cch_x,target_y+1 );
								sx = N_WIN_TXTBOX_ALL;

								n_win_txtbox_select( p, x,y,sx,sy );

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", ( y + sy ), p->scroll_cch_tabbed_y );
								if ( ( y + sy - 1 ) <= p->scroll_cch_tabbed_y )
								{
									n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y - 1 );
								}

							}

						} else
						if ( p->line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " Max : VK_UP " );

							if ( y == 0 ) { break; }

							if ( y > 0 )
							{
								y--;
								sy++;
							}

							 x = p->line_min_cch_x = n_win_txtbox_select_up( p, x,y+1 );
							sx = N_WIN_TXTBOX_ALL;

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", x, y, sx, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_cch_x, p->line_max_cch_x );

							n_win_txtbox_select( p, x,y,sx,sy );

						}

					} else {

						if (
							( p->partial_selection_onoff )
							&&
							( p-> updown_selection_onoff )
						)
						{
//n_win_txtbox_hwndprintf_literal( p, " updown_selection_onoff : VK_UP " );

							// [Needed] : don't use n_win_txtbox_select2drag()
							//
							//	a caret will disappear

							s32 target_x = p->select_cch_x + p->select_cch_sx;

							s32  x = n_win_txtbox_select_up( p, target_x, p->select_cch_y );
							s32 sx = N_WIN_TXTBOX_ALL;
							s32  y = p->select_cch_y  - 1;
							s32 sy = p->select_cch_sy + 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", x, n_txt_get( &p->txt, p->select_cch_y ) );

							p->line_min_onoff = false;
							p->line_max_onoff = true;
							p->line_min_cch_x = x;
							p->line_max_cch_x = target_x;
//n_win_txtbox_hwndprintf_literal( p, " %d ", target_x );

							//n_win_txtbox_unselect( p );
							n_win_txtbox_select( p, x,y,sx,sy );
							//n_win_txtbox_select2drag( p );

						} else {
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->prv_sel_sy );

							// [!] : n_win_txtbox_unselect() rewrites p->select_cch_y, _sy

							n_win_txtbox_unselect( p );

							if ( p->prv_sel_sy == 1 )
							{

								n_win_txtbox_line_select( p, p->prv_sel_y );
								n_win_txtbox_select2drag( p );

							} else {

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_x, p->select_cch_sx );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_x, p->prv_sel_sx );

								s32 target_x = p->prv_sel_x;
								s32 target_y = p->prv_sel_y - 1;
								if ( n_win_txtbox_is_caret_tail( p ) )
								{
									target_x = p->prv_sel_x + p->prv_sel_sx;
									target_y = p->prv_sel_y + p->prv_sel_sy - 1 - 1;
								}
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

								p->select_cch_y  = n_posix_max_s32( 0, target_y );
								p->select_cch_sy = 1;

								// [x] : patched : buggy
								if ( target_x < 0 ) { target_x = 0; }

								p->select_cch_x = n_win_txtbox_select_up( p, target_x, target_y + 1 );

							}

						}

					}

				} else {

					if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
					{

						s32 x = 0;
						s32 y = 0;

						if ( p->line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : Min " );
							x = p->line_max_cch_x;
							y = p->select_cch_y + p->select_cch_sy - 1;
						} else
						if ( p->line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : Max " );
							x = p->line_min_cch_x;
							y = p->select_cch_y;
						}

						n_win_txtbox_unselect( p );
						x = n_win_txtbox_select_up( p, x,y );
						n_win_txtbox_select( p, x, y - 1, 0, 1 );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_UP " );

						// [!] : n_win_txtbox_unselect() rewrites some members

						s32 x = p->select_cch_x;
						if ( n_win_txtbox_is_caret_tail( p ) )
						{
							x += p->select_cch_sx;
						}

						n_win_txtbox_unselect( p );

						if ( p->select_cch_y > 0 )
						{
							x = n_win_txtbox_select_up( p, x, p->select_cch_y );
							n_win_txtbox_select( p, x, p->select_cch_y - 1, 0, 1 );
						}

					}

				}

			} else
			if ( vk == VK_DOWN )
			{

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				if ( n_win_is_input( VK_SHIFT ) )
				{

					p->shift_dragging = VK_DOWN;

					if (
						( ( p->line_min_onoff )||( p->line_max_onoff ) )
						&&
						( p->updown_selection_onoff )
					)
					{

						s32  x = p->select_cch_x;
						s32  y = p->select_cch_y;
						s32 sx = p->select_cch_sx;
						s32 sy = p->select_cch_sy;

						if ( p->line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " Min : VK_DOWN " );

							sy++;

							s32 target_y = y + sy - 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

							 x = p->line_max_cch_x = n_win_txtbox_select_down( p, p->line_max_cch_x,target_y-1 );
							sx = N_WIN_TXTBOX_ALL;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, target_y-1 ) );

							n_win_txtbox_select( p, x,y,sx,sy );

							if ( ( y + sy ) > ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) )
							{
//n_win_txtbox_hwndprintf_literal( p, " Autoscroll On  : %d %d ", ( y + sy ), ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) );
								n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y + 1 );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->scroll_cch_tabbed_y );
							} else {
//n_win_txtbox_hwndprintf_literal( p, " Autoscroll Off : %d %d ", ( y + sy ), ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) );
							}

						} else
						if ( p->line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " Max : VK_DOWN " );
//n_win_txtbox_hwndprintf_literal( p, " %d ", sy );

							if ( sy <= 2 )
							{

								if ( ( sy == 2 )&&( p->reverse_selection_onoff ) )
								{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : .reverse_selection_onoff " );
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %s ", n_txt_get( &p->txt, y+sy-1-1 ) );

									sx = N_WIN_TXTBOX_ALL;

									p->line_min_onoff =  true;
									p->line_max_onoff = false;

									x = p->line_min_cch_x;
									p->line_min_cch_x = x;
									p->line_max_cch_x = n_win_txtbox_select_down( p, x, y+sy-1-1 );

//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d %d ", p->line_min_cch_x, p->line_max_cch_x );

									n_win_txtbox_select( p, x,y,sx,sy );
									n_win_txtbox_select2drag( p );

								}

							} else {

								 y++;
								sy--;

								 x = p->line_min_cch_x = n_win_txtbox_select_down( p, p->line_min_cch_x, y-1 );
								sx = N_WIN_TXTBOX_ALL;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y-1 ) );

								n_win_txtbox_select_set( p, x,y,sx,sy, false );

							}

						}

					} else {

						if (
							( p->partial_selection_onoff )
							&&
							( p-> updown_selection_onoff )
						)
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Shift : .updown_selection_onoff " );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_y + p->select_cch_sy, p->txt.sy );

							// [Needed] : don't use n_win_txtbox_select2drag()
							//
							//	a caret will disappear
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_cch_x, p->select_cch_x );

							s32 target_x = p->select_cch_x;

							s32  y = p->select_cch_y;
							s32 sy = p->select_cch_sy + 1;
							s32  x = n_win_txtbox_select_down( p, target_x, y );
							s32 sx = N_WIN_TXTBOX_ALL;
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y ) );

							p->line_min_onoff = true;
							p->line_max_onoff = false;
							p->line_min_cch_x = target_x;
							p->line_max_cch_x = x;

							//n_win_txtbox_unselect( p );
							n_win_txtbox_select( p, x,y,sx,sy );
							//n_win_txtbox_select2drag( p );

						} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Shift : Single Line " );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->prv_sel_sy );

							// [!] : n_win_txtbox_unselect() rewrites p->select_cch_y, _sy

							n_win_txtbox_unselect( p );

							if ( p->prv_sel_sy == 1 )
							{

								n_win_txtbox_line_select( p, p->prv_sel_y );
								n_win_txtbox_select2drag( p );

							} else {

								s32 target_y = p->prv_sel_y + 1;
								if ( n_win_txtbox_is_caret_tail( p ) )
								{
									target_y = p->prv_sel_y + p->prv_sel_sy - 1 + 1;
								}
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", p->prv_sel_y, n_txt_get( &p->txt, p->prv_sel_y ) );
//n_win_txtbox_hwndprintf_literal( p, " %d : %s ", target_y, n_txt_get( &p->txt, target_y ) );

								p->select_cch_y  = n_posix_max_s32( 0, target_y );
								p->select_cch_sy = 1;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_x, p->select_cch_sx );
								p->select_cch_x = n_win_txtbox_select_down( p, p->select_cch_x, p->select_cch_y - 1 );

							}

						}

					}

				} else {

					if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : multi-line partial " );

						s32 x = 0;
						s32 y = 0;

						if ( p->line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Min " );
							x = p->line_max_cch_x;
							y = p->select_cch_y + p->select_cch_sy - 1;
						} else
						if ( p->line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : Max " );
							x = p->line_min_cch_x;
							y = p->select_cch_y;
						}

						n_win_txtbox_unselect( p );
						x = n_win_txtbox_select_down( p, x,y );
						n_win_txtbox_select( p, x, y + 1, 0, 1 );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : N/A " );

						// [!] : n_win_txtbox_unselect() rewrites some members

						s32 x = p->select_cch_x;
						if ( n_win_txtbox_is_caret_tail( p ) )
						{
							x += p->select_cch_sx;
						}

						n_win_txtbox_unselect( p );

						x = n_win_txtbox_select_down( p, x, p->select_cch_y );
						n_win_txtbox_select( p, x, p->select_cch_y + 1, 0, 1 );

					}

				}

			} else
			if ( vk == VK_LEFT )
			{

				if ( n_win_is_input( VK_SHIFT ) )
				{

					//p->shift_dragging = VK_LEFT;

					if ( p->select_cch_sy != 1 )
					{

						const s32 limit = 0;

						if ( p->line_min_onoff )
						{

							n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y + p->select_cch_sy - 1 );

							s32 tail = n_posix_strlen( line );
							if ( p->line_max_cch_x > tail ) { p->line_max_cch_x = tail; }

							n_win_txtbox_caret_l( line, p->line_max_cch_x, &p->line_max_cch_x );
							if ( p->line_max_cch_x < limit ) { p->line_max_cch_x = limit; }

							p->select_cch_x = p->line_max_cch_x;

						}

						if ( p->line_max_onoff )
						{

							n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

							s32 tail = n_posix_strlen( line );
							if ( p->line_min_cch_x > tail ) { p->line_min_cch_x = tail; }

							n_win_txtbox_caret_l( line, p->line_min_cch_x, &p->line_min_cch_x );
							if ( p->line_min_cch_x < limit ) { p->line_min_cch_x = limit; }

							p->select_cch_x = p->line_min_cch_x;

						}

					} else {

						if ( p->select_cch_sx == 0 ) { p->shift_dragging = vk; }


						n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

						s32 cch;

						if ( p->shift_dragging == vk )
						{
							cch = p->select_cch_x;
						} else {
							cch = p->select_cch_x + p->select_cch_sx;
						}

						n_win_txtbox_caret_l( line, cch, &cch );


						s32 x, sx;

						if ( p->shift_dragging == vk )
						{
							 x = cch;
							sx = ( p->select_cch_x + p->select_cch_sx ) - cch;
						} else {
							 x = p->select_cch_x;
							sx = cch - p->select_cch_x;
						}


						n_win_txtbox_select_set( p, x, p->select_cch_y, sx, p->select_cch_sy, false );

					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					s32 f,t;

					f = p->select_cch_x;
					n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
					n_win_txtbox_caret_l( line, f, &f );

					n_win_txtbox_select_word( p, f, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, f, p->select_cch_y, 0, 1, false );

				} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT( %d ) : %d ", VK_LEFT, p->shift_dragging );

					s32 prv_line_min_onoff = p->line_min_onoff;
					s32 prv_line_max_onoff = p->line_max_onoff;
					s32 prv_line_min_cch_x = p->line_min_cch_x;
					s32 prv_line_max_cch_x = p->line_max_cch_x;

					if ( p->shift_dragging == VK_LEFT )
					{
						n_win_txtbox_unselect( p );
					} else {
						p->select_cch_x += p->select_cch_sx;
					}

					if ( ( p->select_cch_x == 0 )&&( p->select_cch_y == 0 ) )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : full stop " );

						// [!] : full stop

					} else
					if ( p->select_cch_x <= 0 )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : if ( p->select_cch_x <= 0 ) " );

						if ( p->select_cch_y == 0 ) { break; } else { p->select_cch_y--; }

						n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
						s32           tail = n_posix_strlen( line );

						n_win_txtbox_select_set( p, tail, p->select_cch_y, 0, 1, false );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : %d : %d : %d ", p->prv_sel_sy, p->prv_sel_y, p->drag_cch_y );

						s32  x = p->prv_sel_x;
						s32  y = p->prv_sel_y;
						s32 sx = 0;
						s32 sy = 1;

						if (
							(
								( prv_line_max_onoff == false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( n_win_txtbox_is_caret_tail( p ) )
							)
							||
							( prv_line_min_onoff )
						)
						{
							y = n_posix_max_s32( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( prv_line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Min " );
							x = prv_line_max_cch_x;
						} else
						if ( prv_line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max " );
							x = prv_line_min_cch_x;
						} else
						if ( p->prv_sel_sx != -1 )
						{
							if ( p->prv_sel_x == p->select_cch_x )
							{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Left " );
								if ( p->is_caret_tail )
								{
									x = p->prv_sel_x + p->prv_sel_sx;
								}
							} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Right " );
								x = p->prv_sel_x + p->prv_sel_sx;
							}
						}

						n_posix_char *line = n_txt_get( &p->txt, y );
						n_win_txtbox_caret_l( line, x, &x );
						n_win_txtbox_select_set( p, x,y,sx,sy, false );

					}

				}

			} else
			if ( vk == VK_RIGHT )
			{

				if ( n_win_is_input( VK_SHIFT ) )
				{

					//p->shift_dragging = VK_RIGHT;

					if ( p->select_cch_sy != 1 )
					{

						if ( p->line_min_onoff )
						{

							s32 y = p->select_cch_y + p->select_cch_sy - 1;
							n_win_txtbox_caret_r( n_txt_get( &p->txt, y ), p->line_max_cch_x, &p->line_max_cch_x );
							p->select_cch_x = p->line_max_cch_x;
//n_win_txtbox_hwndprintf_literal( p, " Min : %d ", p->line_max_cch_x );

						}

						if ( p->line_max_onoff )
						{

							s32 y = p->select_cch_y;
							n_win_txtbox_caret_r( n_txt_get( &p->txt, y ), p->line_min_cch_x, &p->line_min_cch_x );
							p->select_cch_x = p->line_min_cch_x;
//n_win_txtbox_hwndprintf_literal( p, " Max : %d ", p->line_min_cch_x );
//n_win_txtbox_hwndprintf_literal( p, " Max : %d %d ", p->select_cch_x, p->select_cch_sx );

						}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->line_min_cch_x, p->line_max_cch_x );

					} else {

						if ( p->select_cch_sx == 0 ) { p->shift_dragging = vk; }


						n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );

						s32 cch;

						if ( ( p->is_caret_tail )||( p->shift_dragging == vk ) )
						{
							cch = p->select_cch_x + p->select_cch_sx;
						} else {
							cch = p->select_cch_x;
						}

						n_win_txtbox_caret_r( line, cch, &cch );


						s32 x, sx;

						if ( ( p->is_caret_tail )||( p->shift_dragging == vk ) )
						{
							 x = p->select_cch_x;
							sx = cch - p->select_cch_x;
						} else {
							 x = cch;
							sx = ( p->select_cch_x + p->select_cch_sx ) - cch;
						}

						n_win_txtbox_select_set( p, x, p->select_cch_y, sx, p->select_cch_sy, false );

					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					s32 f,t;
					n_win_txtbox_select_word( p, p->select_cch_x, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, t, p->select_cch_y, 0, 1, false );

				} else {

					s32 prv_line_min_onoff = p->line_min_onoff;
					s32 prv_line_max_onoff = p->line_max_onoff;
					s32 prv_line_min_cch_x = p->line_min_cch_x;
					s32 prv_line_max_cch_x = p->line_max_cch_x;


					n_win_txtbox_unselect( p );


					if ( p->is_caret_tail )
					{
						p->select_cch_x = p->prv_sel_x + p->prv_sel_sx;
					}


					size_t target_y = p->prv_sel_y;
					if ( n_win_txtbox_is_caret_tail( p ) )
					{
						target_y = p->prv_sel_y + p->prv_sel_sy - 1;
					}

					n_posix_char *line = n_txt_get( &p->txt, n_posix_max_s32( 0, target_y ) );
					s32           tail = n_posix_strlen( line );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %s ", line );

					if ( p->prv_sel_x == tail )
					{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : tail " );

						if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }

						if ( target_y >= ( p->txt.sy - 1 ) ) { break; }

						n_win_txtbox_select_set( p, 0, target_y + 1, 0, 1, false );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d : %d ", p->prv_sel_sy, p->prv_sel_y, p->drag_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d ", p->prv_sel_x, tail );

						s32  x = p->prv_sel_x;
						s32  y = p->prv_sel_y;
						s32 sx = 0;
						s32 sy = 1;

						if (
							(
								( prv_line_max_onoff == false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( n_win_txtbox_is_caret_tail( p ) )
							)
							||
							( prv_line_min_onoff )
						)
						{
							y = n_posix_max_s32( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( prv_line_min_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Min " );
							x = prv_line_max_cch_x;
						} else
						if ( prv_line_max_onoff )
						{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Max " );
							x = prv_line_min_cch_x;
						} else
						if ( p->prv_sel_sx != -1 )
						{
							if ( p->prv_sel_x == p->select_cch_x )
							{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Left " );
								//
							} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : Right " );
								x = p->prv_sel_x + p->prv_sel_sx;
							}
						}

						n_posix_char *line = n_txt_get( &p->txt, y );
						n_win_txtbox_caret_r( line, x, &x );
						n_win_txtbox_select_set( p, x,y,sx,sy, false );

					}

				}

			} else
			if ( vk == VK_NEXT )
			{

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy );

				n_win_txtbox_refresh( p );
				break;

			} else
			if ( vk == VK_PRIOR )
			{

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y - p->page_cch_tabbed_sy );

				n_win_txtbox_refresh( p );
				break;

			} else
			if ( vk == VK_HOME )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, 0 );
					n_win_txtbox_select_set( p, 0, 0, 0, 1, false );
				} else {
					n_win_txtbox_select_set( p, 0, p->select_cch_y, 0, p->select_cch_sy, false );
				}

			} else
			if ( vk == VK_END )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, p->last_cch_tabbed_sy );
					n_win_txtbox_select_set( p, 0, p->txt.sy - 1, 0, 1, false );
				} else {
					n_win_txtbox_select( p, 0, p->select_cch_y, N_WIN_TXTBOX_ALL, p->select_cch_sy );
					n_win_txtbox_select_set( p, p->select_cch_sx, p->select_cch_y, 0, p->select_cch_sy, false );
				}

			} else
			if ( vk == VK_INSERT )
			{

				// [x] : for usability

				//n_win_txtbox_menu_insert( p );

			} else
			if ( vk == VK_DELETE )
			{

				n_win_txtbox_menu_delete( p );

			} else
			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( vk == 'A' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+A" );

					n_win_txtbox_menu_selectall( p );

				} else
				if ( vk == 'C' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+C" );

					n_win_txtbox_menu_copy( p );

				} else
				if ( ( vk == 'V' )&&( p->txt.readonly == false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+V" );

					n_win_txtbox_menu_paste( p );

				} else
				if ( ( vk == 'X' )&&( p->txt.readonly == false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+X" );

					n_win_txtbox_menu_cut( p );

				} else
				if ( ( vk == 'Z' )&&( p->txt.readonly == false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+Z" );

					n_win_txtbox_menu_undo( p );

				}// else

				break;

			} else
			if ( p->txt.readonly == false )
			{

				n_win_txtbox_edit_undo( p, false );

				if ( n_win_txtbox_edit_input( p, vk ) )
				{
					n_win_message_send( GetParent( hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );
				}

			}

			p->input_onoff = true;

			n_win_txtbox_refresh_optimized_exit( p, true );

		}

	}
	break;


	} // switch


	if ( p->is_static_ownerdraw == false ) { n_win_txtbox_proc_mouse( hwnd, msg, wparam, lparam, p ); }


	if ( p->mouse_input_stop_onoff == false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( p->pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}




void
n_win_txtbox_init( n_win_txtbox *p, HWND hwnd_parent, int style, int style_option )
{

	if ( p == NULL ) { return; }

	if ( hwnd_parent == NULL ) { return; }


	// Debug

	p->debug_onoff = false;//true;


	// Default

	p->style        = style;
	p->style_option = style_option;

	if (
		( false == ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX ) )
		&&
		( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		&&
		( false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	)
	{
		return;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { p->style |= N_WIN_TXTBOX_STYLE_EDITBOX; }


	p->color___dwm_contour = RGB(  50, 50, 50 );
	p->color___dwm_textclr = RGB( 255,255,255 );


	// UI

	if ( false )//( n_sysinfo_version_10_or_later() )
	{
		n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, "", &p->hwnd );
		n_win_ime_enable( p->hwnd );
	} else {
		n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS,        "", &p->hwnd );
		p->is_static_ownerdraw = true;
	}


#ifdef _WIN64
	SetWindowSubclass( p->hwnd, n_win_txtbox_subclass, 0, (DWORD_PTR) p );
#else  // #ifdef _WIN64
	p->pfunc = n_win_gui_subclass_set( p->hwnd, n_win_txtbox_subclass );
	n_win_property_init( p->hwnd, N_WIN_TXTBOX_NAMESPACE, (int) p );
#endif // #ifdef _WIN64


	//n_win_scrollbar_direct_render = true;

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_init( &p->hscr, p->hwnd, N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL, 0 );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_init( &p->vscr, p->hwnd, N_WIN_SCROLLBAR_LAYOUT_VERTICAL  , 0 );
	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		n_win_stdfont_init( &p->hwnd, 1 );
	}



	// [Needed] : after p->hwnd is made
	// [Needed] : after scrollbars are made

	n_win_txtbox_metrics( p );
	n_win_txtbox_reset  ( p );


	p->hmenu_editbox = n_win_menu_popup_hmenu_init();
	p->hmenu_linenum = n_win_menu_popup_hmenu_init();


	p->partial_selection_onoff = true;
	p-> updown_selection_onoff = true;
	p->reverse_selection_onoff = true;

	n_win_txtbox_line_minmax_reset( p );


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	n_win_txtbox_reset_undo( p );


	n_win_timer_init( p->hwnd, p->caret_timer, p->caret_msec );


	p->focus_phase_is_first = N_WIN_TXTBOX_FOCUS_GO;


	return;
}

void
n_win_txtbox_exit( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_timer_exit( p->hwnd, p->caret_timer );


#ifdef _WIN64
	RemoveWindowSubclass( p->hwnd, n_win_txtbox_subclass, 0 );
#else  // #ifdef _WIN64
	n_win_gui_subclass_set( p->hwnd, p->pfunc );
	n_win_property_exit( p->hwnd, N_WIN_TXTBOX_NAMESPACE );
#endif // #ifdef _WIN64


	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_exit( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_exit( &p->vscr );
	}


	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		n_win_stdfont_exit( &p->hwnd, 1 );
	}


	n_win_menu_popup_hmenu_exit( p->hmenu_editbox );
	n_win_menu_popup_hmenu_exit( p->hmenu_linenum );


	DestroyWindow( p->hwnd );


	n_txt_free( &p->txt      );
	n_txt_free( &p->txt_undo );


	n_bmp_free( &p->prv_bmp );


	n_win_txtbox_zero( p );


	return;
}


#endif // _H_NONNON_WIN32_TXTBOX

