// Nonnon Batch Drop for Win9x
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_APPS_NAME_BATCHDROP

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef N_APPS_NAME_BATCHDROP




#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win/commandline.c"




#define N_BAT_EXT n_posix_literal( ".bat\0\0" )




bool
n_bat_main( const n_posix_char *cmdline )
{

	if ( false == n_string_path_ext_is_same( N_BAT_EXT, cmdline ) ) { return true; }


	n_string_path_folder_change( cmdline );


	// [Needed] : WinNT : doublequote

	n_posix_char *str = n_string_path_cat( N_STRING_DQUOTE, cmdline, N_STRING_DQUOTE, NULL );


	// [!] : Win9x : don't use WinExec()

	n_posix_system( str );


	n_string_path_free( str );


	n_explorer_refresh( false );


	return false;
}

#ifndef N_APPS_NAME_BATCHDROP

int
main( void )
{

	n_posix_char *cmdline = n_win_commandline_new();
//n_posix_debug( cmdline );

	bool ret = n_bat_main( cmdline );

	n_string_path_free( cmdline );


	return ret;
}

#endif // #ifndef N_APPS_NAME_BATCHDROP

