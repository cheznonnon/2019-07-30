// Nonnon FTP
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_APPS_NAME_FTP

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef N_APPS_NAME_FTP




#include "../nonnon/neutral/ini.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"


#include <wininet.h>

#ifdef _MSC_VER
#pragma comment( lib, "wininet" )
#endif // #ifdef _MSC_VER




#define n_ftp_init_literal( s ) n_ftp_init( n_posix_literal( s ) )

HINTERNET
n_ftp_init( const n_posix_char *str_agent )
{

	HINTERNET h_inet = InternetOpen
	(
		str_agent,
		INTERNET_OPEN_TYPE_DIRECT,
		NULL,NULL,
		0
	);


	return h_inet;
}

void
n_ftp_exit( HINTERNET h_inet )
{

	InternetCloseHandle( h_inet );

	return;
}

HINTERNET
n_ftp_session_init
(
	HINTERNET h_inet,
	const n_posix_char *hostname,
	const n_posix_char *username,
	const n_posix_char *password,
	const n_posix_char *pasv_ftp
)
{

	DWORD passive = 0;

	if ( n_string_is_same_literal( "on", pasv_ftp ) )
	{
		passive = INTERNET_FLAG_PASSIVE;
	}


	HINTERNET h_session = InternetConnect
	(
		h_inet,
		hostname,
		INTERNET_DEFAULT_FTP_PORT,
		username,
		password,
		INTERNET_SERVICE_FTP,
		passive,
		0
	);


	return h_session;
}

void
n_ftp_session_exit( HINTERNET h_session )
{

	InternetCloseHandle( h_session );

	return;
}

WIN32_FIND_DATA
n_ftp_session_property( HINTERNET h_session, const n_posix_char *name )
{

	WIN32_FIND_DATA f; ZeroMemory( &f, sizeof( WIN32_FIND_DATA ) );

	HINTERNET folder = FtpFindFirstFile( h_session, name, &f, 0, 0 );

	InternetCloseHandle( folder );


	return f;
}

bool
n_ftp_session_is_exist( HINTERNET h_session, const n_posix_char *path )
{
//n_posix_debug_literal( " %s ", path ); return false;

	bool ret = false;


	n_posix_char *name = n_string_path_name_new( path );

	WIN32_FIND_DATA f = n_ftp_session_property( h_session, name );
//n_posix_debug_literal( " %d : %s ", n_string_is_empty( f.cFileName ), f.cFileName );

	if ( false == n_string_is_empty( f.cFileName ) ) { ret = true; }

	n_string_path_free( name );


	return ret;
}

bool
n_ftp_session_is_folder( HINTERNET h_session, const n_posix_char *name )
{

	bool ret = false;


	WIN32_FIND_DATA f = n_ftp_session_property( h_session, name );

	if ( f.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY ) { ret = true; }


	return ret;
}

bool
n_ftp_session_folder_current( HINTERNET h_session, n_posix_char *str_ret )
{

	// [MSDN] : MAX_PATH is used

	DWORD cch = MAX_PATH;
	bool  ret = FtpGetCurrentDirectory( h_session, str_ret, &cch );


	return ( ret == false );
}

bool
n_ftp_session_folder_set( HINTERNET h_session, n_posix_char *str_folder )
{

	bool ret = FtpSetCurrentDirectory( h_session, str_folder );


	return ( ret == false );
}

bool
n_ftp_session_upload( HINTERNET h_session, n_posix_char *fname )
{

	bool ret;


	n_posix_char *remote = n_string_path_name_new( fname );

	if ( n_posix_stat_is_file( fname ) )
	{

		ret = FtpPutFile( h_session, fname, remote, 0, 0 );

	} else {

		if ( 0 == n_posix_folder_count( fname ) )
		{
			ret = FtpCreateDirectory( h_session, remote );
		} else {
			ret = false;
		}

	}

	n_string_path_free( remote );


	return ( ret == false );
}

bool
n_ftp_session_download( HINTERNET h_session, n_posix_char *fname, n_posix_char *localname )
{

	bool ret;


	ret = FtpGetFile( h_session, fname, localname, false, 0, 0, 0 );


	return ( ret == false );
}

void
n_ftp_session_delete( HINTERNET h_session, n_posix_char *fname )
{

	if ( n_ftp_session_is_folder( h_session, fname ) )
	{
		FtpRemoveDirectory( h_session, fname );
	} else {
		FtpDeleteFile( h_session, fname );
	}


	return;
}




#define N_NONNON_FTP_AGENT           n_posix_literal( "Nonnon FTP" )

#define N_NONNON_FTP_CAPTION         n_posix_literal( "Nonnon FTP" )
#define N_NONNON_FTP_ICON            n_posix_literal( "FTP_MAIN" )

#define N_NONNON_FTP_STRING_FOLDER   n_posix_literal( "[b]" )

#define N_NONNON_FTP_INI_SECTION     n_posix_literal( "Nonnon FTP" )
#define N_NONNON_FTP_INI_HOSTNAME    n_posix_literal( "hostname" )
#define N_NONNON_FTP_INI_USERNAME    n_posix_literal( "username" )
#define N_NONNON_FTP_INI_PASSWORD    n_posix_literal( "password" )
#define N_NONNON_FTP_INI_PASV_FTP    n_posix_literal( "pasv_ftp" )

#define N_NONNON_FTP_ERROR_INI       n_posix_literal( "Write an INI file, and try again." )
#define N_NONNON_FTP_ERROR_INIT      n_posix_literal( "Initialization failed." )
#define N_NONNON_FTP_ERROR_SESSION   n_posix_literal( "Connection failed." )
#define N_NONNON_FTP_ERROR_LOAD      n_posix_literal( "Please check." )
#define N_NONNON_FTP_ERROR_FAILED    n_posix_literal( "Failed." )
#define N_NONNON_FTP_ERROR_SUCCEEDED n_posix_literal( "Done!" )




typedef struct {

	n_win_txtbox txtbox;

	s32          minwsx,minwsy;

	n_posix_char hostname[ MAX_PATH ];
	n_posix_char username[ MAX_PATH ];
	n_posix_char password[ MAX_PATH ];
	n_posix_char pasv_ftp[ MAX_PATH ];

} n_nonnon_ftp;

#define n_nonnon_ftp_zero( p ) n_memory_zero( p, sizeof( n_nonnon_ftp ) )

static n_nonnon_ftp nonnon_ftp;




void
n_nonnon_ftp_item_add( n_nonnon_ftp *p, WIN32_FIND_DATA f )
{

	if ( n_string_is_same_literal( ".", f.cFileName ) )
	{

		//

	} else
	if ( n_string_is_same_literal( "..", f.cFileName ) )
	{

		n_win_txtbox_line_set( &p->txtbox, 0, n_posix_literal( "[b].." ) );

	} else {

		if ( f.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY )
		{
			n_posix_char str[ MAX_PATH * 2 ];
			n_posix_sprintf_literal( str, "%s%s", N_NONNON_FTP_STRING_FOLDER, f.cFileName );
			n_win_txtbox_line_set( &p->txtbox, 1,  str );
		} else {
			n_win_txtbox_line_set( &p->txtbox, p->txtbox.txt.sy, f.cFileName );
		}

	}


	return;
}

void
n_nonnon_ftp_item_sort( n_nonnon_ftp *p )
{

	if ( p->txtbox.txt.sy == 1 ) { return; }


	n_txt *txt = &p->txtbox.txt;


	size_t i, j;

	if ( n_string_is_same_literal( "[b]..", n_txt_get( txt, 0 ) ) )
	{
		i = 1;
	} else {
		i = 0;
	}

	j = i + 1;


	while( 1 )
	{

		if ( i >= txt->sy ) { break; }
		if ( j >= txt->sy ) { break; }


		n_posix_char *str_f = n_txt_get( txt, i );
		n_posix_char *str_t = n_txt_get( txt, j );

		if ( n_string_match( str_f, N_NONNON_FTP_STRING_FOLDER ) == n_string_match( str_t, N_NONNON_FTP_STRING_FOLDER ) )
		{
			if ( 1 == n_string_compare( str_f, str_t ) )
			{
				n_txt_swap( txt, i, j );
			}
		}

		j++;
		if ( j >= txt->sy )
		{
			i++;
			if ( i >= txt->sy ) { break; }

			j = i + 1;
		}

	}

	return;
}

bool
n_nonnon_ftp_load( n_nonnon_ftp *p, HINTERNET h_session )
{

	// [Needed] : INTERNET_FLAG_NO_CACHE_WRITE
	//
	//	not renewed at item addition/delettion

	WIN32_FIND_DATA f; ZeroMemory( &f, sizeof( WIN32_FIND_DATA ) );

	HINTERNET folder = FtpFindFirstFile
	(
		h_session,
		NULL,
		&f,
		INTERNET_FLAG_NO_CACHE_WRITE,
		0
	);
	if ( ERROR_NO_MORE_FILES == GetLastError() ) { return false; }

	if ( folder == NULL )
	{
//n_posix_debug_literal( " folder is NULL " );
		return true;
	}

	if ( GetLastError() )
	{
//n_posix_debug_literal( " Error Code %08x ", GetLastError() );
		return true;
	}


	n_win_txtbox_reset( &p->txtbox );

	while( 1 )
	{

		n_nonnon_ftp_item_add( p, f );

		bool ret = InternetFindNextFile( folder, &f );

		if ( ret == false ) { break; }
	}

	n_nonnon_ftp_item_sort( p );


	InternetCloseHandle( folder );


	return false;
}

n_posix_char*
n_nonnon_ftp_name_get( n_nonnon_ftp *p, HINTERNET h_session )
{

	size_t        cch = n_win_txtbox_selection_cch( &p->txtbox );
	n_posix_char *ret = n_string_path_new( cch );

	n_win_txtbox_selection_get( &p->txtbox, ret );

	if ( n_string_match( ret, N_NONNON_FTP_STRING_FOLDER ) )
	{
		n_posix_sprintf_literal( ret, "%s", &ret[ n_posix_strlen( N_NONNON_FTP_STRING_FOLDER ) ] );
	}


	return ret;
}

n_posix_char*
n_nonnon_ftp_localname( n_nonnon_ftp *p, const n_posix_char *fname )
{
//return;

	n_posix_char *ret = NULL;
	n_posix_char *dir = n_explorer_path_new( NULL );

	if ( false == n_string_is_empty( dir ) )
	{
		ret = n_string_path_make_new( dir, fname );
	}

	n_string_path_free( dir );


	return ret;
}




// internal
void
n_nonnon_ftp_ini_read( n_nonnon_ftp *p )
{

	n_win_exedir2curdir();

	n_posix_char *cmdline = n_win_commandline_new();

	bool is_allocated = true;

#ifdef N_APPS_NAME_FTP

	// [Needed] : for Nonnon Apps

	n_string_commandline_option( N_APPS_OPTION_FTP, cmdline );

#endif // #ifdef N_APPS_NAME_FTP


	if ( n_string_is_empty( cmdline ) )
	{
		cmdline = n_project_ini_name;
		is_allocated = false;
	}


	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, cmdline );

	n_posix_char *str_on = n_posix_literal( "on" );

	if ( n_ini_section_chk( &ini, N_NONNON_FTP_INI_SECTION ) )
	{
		n_ini_value_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_HOSTNAME, N_STRING_EMPTY, p->hostname, MAX_PATH );
		n_ini_value_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_USERNAME, N_STRING_EMPTY, p->username, MAX_PATH );
		n_ini_value_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_PASSWORD, N_STRING_EMPTY, p->password, MAX_PATH );
		n_ini_value_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_PASV_FTP,         str_on, p->pasv_ftp, MAX_PATH );
	} else {
		n_ini_section_add( &ini, N_NONNON_FTP_INI_SECTION );
		n_ini_key_add_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_HOSTNAME, N_STRING_EMPTY );
		n_ini_key_add_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_USERNAME, N_STRING_EMPTY );
		n_ini_key_add_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_PASSWORD, N_STRING_EMPTY );
		n_ini_key_add_str( &ini, N_NONNON_FTP_INI_SECTION, N_NONNON_FTP_INI_PASV_FTP,         str_on );
		n_ini_save( &ini, cmdline );
	}

	n_ini_free( &ini );


	if ( is_allocated ) { n_string_path_free( cmdline ); }


	return;
}




// internal
void
n_nonnon_ftp_resize( n_nonnon_ftp *p, HWND hwnd )
{

	const bool redraw = true;


	s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );


	static bool is_first = true;


	int nwset = N_WIN_SET_DEFAULT;

	s32 csx = -1;
	s32 csy = -1;

	if ( is_first )
	{

		is_first = false;

		nwset = N_WIN_SET_CENTERING;

		p->minwsy = csy = m + ( ctl * 2 ) + ( ctl * 7 ) + ( ctl * 1 );
		p->minwsx = csx = m + ( (double) csy * sqrt( 2 ) );

		n_win_minsize_proc_patch( hwnd, &csx, &csy );

	} else {

		nwset = n_project_n_win_set();

	}


	n_win w; n_win_set( hwnd, &w, csx,csy, nwset );


	MoveWindow( p->txtbox.hwnd, 0,0,w.csx,w.csy, redraw );


	//n_win_refresh( hwnd, true );


	return;
}




LRESULT CALLBACK
n_ftp_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HINTERNET h_inet    = NULL;
	static HINTERNET h_session = NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_project_darkmode();

		n_win_init_background( hwnd );

		n_win_stdfont_init( &nonnon_ftp.txtbox.hwnd, 1 );

		n_nonnon_ftp_resize( &nonnon_ftp, hwnd );

		n_win_refresh( hwnd, false );

	break;


	case WM_CREATE :

		// Global

		n_project_darkmode();


		n_nonnon_ftp_zero( &nonnon_ftp );


		n_nonnon_ftp_ini_read( &nonnon_ftp );

		if (
			( n_string_is_empty( nonnon_ftp.hostname ) )
			&&
			( n_string_is_empty( nonnon_ftp.username ) )
			&&
			( n_string_is_empty( nonnon_ftp.password ) )
		)
		{
			n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_INI );
			return -1;
		}


		h_inet = n_ftp_init( N_NONNON_FTP_AGENT );
		if ( h_inet == NULL )
		{
			n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_INIT );
			return -1;
		}

		h_session = n_ftp_session_init( h_inet, nonnon_ftp.hostname, nonnon_ftp.username, nonnon_ftp.password, nonnon_ftp.pasv_ftp );
		if ( h_session == NULL )
		{
			n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_SESSION );
			n_ftp_exit( h_inet );
			return -1;
		}


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_ime_disable( hwnd );


		// UI

		n_win_init( hwnd, N_NONNON_FTP_CAPTION, N_NONNON_FTP_ICON, N_STRING_EMPTY );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_BOLDTXT;

			n_win_txtbox_zero( &nonnon_ftp.txtbox );
			n_win_txtbox_init( &nonnon_ftp.txtbox, hwnd, style, style_option );

			n_win_stdfont_init( &nonnon_ftp.txtbox.hwnd, 1 );

		}


		//n_win_txtbox_line_set( &nonnon_ftp.txtbox, 0, L"[b].." );
		//n_win_txtbox_line_set( &nonnon_ftp.txtbox, 2, L"[b]folder" );
		//n_win_txtbox_line_set( &nonnon_ftp.txtbox, 3, L"file" );

		{

			n_win_cursor_add( NULL, IDC_WAIT );

			bool ret = n_nonnon_ftp_load( &nonnon_ftp, h_session );

			n_win_cursor_add( NULL, IDC_ARROW );

			if ( ret ) { n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_LOAD ); }

		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :

		n_nonnon_ftp_resize( &nonnon_ftp, hwnd );

	break;


	case WM_DROPFILES :
	{

		n_posix_char *multipath = n_win_dropfiles_multiple_new( hwnd, wparam );
//n_posix_debug_literal( "%s\n%d", path, n_ftp_session_is_exist( h_session, multipath ) ); break;

		int succeeded = 0;

		int count = n_string_path_multiple_count( multipath );

		int i = 0;
		while( 1 )
		{

			n_posix_char *path = n_string_path_multiple_new( multipath, i );
//n_posix_debug_literal( "%s", str );

			n_win_cursor_add( NULL, IDC_WAIT );

			bool ret0 = n_ftp_session_is_exist( h_session, path );

			n_win_cursor_add( NULL, IDC_ARROW );


			if ( ret0 )
			{

				n_posix_char *nam = n_string_path_name_new( path );
				int           cch = n_posix_strlen( n_project_string_overwrite ) + 2 + n_posix_strlen( nam );
				n_posix_char *str = n_string_new( cch );

				n_posix_sprintf_literal( str, "%s\n\n%s", n_project_string_overwrite, nam );

				if ( n_project_dialog_yesno( hwnd, str ) )
				{
					ret0 = false;
				}

				n_string_free( nam );
				n_string_free( str );

			}


			if ( ret0 == false )
			{

				n_win_cursor_add( NULL, IDC_WAIT );

				bool ret1 = n_ftp_session_upload( h_session, path );
				bool ret2 = n_nonnon_ftp_load( &nonnon_ftp, h_session );

				n_win_cursor_add( NULL, IDC_ARROW );


				if ( ret1 )
				{

					n_posix_char *nam = n_string_path_name_new( path );
					int           cch = n_posix_strlen( N_NONNON_FTP_ERROR_FAILED ) + 2 + n_posix_strlen( nam );
					n_posix_char *str = n_string_new( cch );

					n_posix_sprintf_literal( str, "%s\n\n%s", N_NONNON_FTP_ERROR_FAILED, nam );

					n_project_dialog_info( hwnd, str );

					n_string_free( nam );
					n_string_free( str );

				} else
				if ( ret2 )
				{

					n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_LOAD );

				} else {

					succeeded++;

					n_posix_char *name = n_string_path_name_new( path );
					if ( n_posix_stat_is_dir( path ) )
					{
						int           cch = n_posix_strlen( N_NONNON_FTP_STRING_FOLDER ) + n_posix_strlen( name );
						n_posix_char *str = n_string_new( cch );

						n_posix_sprintf_literal( str, "%s%s", N_NONNON_FTP_STRING_FOLDER, name );

						n_string_path_free( name );
						name = str;
					}
//n_posix_debug_literal( "%s", name );
					n_win_txtbox_str2index( &nonnon_ftp.txtbox, name, true );
					n_string_path_free( name );

				}

			}


			n_string_path_free( path );


			i++;
			if ( i >= count ) { break; }
		}


		if ( count == 1 )
		{

			if ( i == succeeded )
			{
				n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_SUCCEEDED );
			}

		} else {

			if ( 0 != succeeded )
			{
				int           cch = n_posix_strlen( N_NONNON_FTP_ERROR_SUCCEEDED ) + 2 + 100;
				n_posix_char *str = n_string_new( cch );

				n_posix_sprintf_literal( str, "%s\n\n%d/%d", N_NONNON_FTP_ERROR_SUCCEEDED, succeeded, count );

				n_project_dialog_info( hwnd, str );

				n_string_free( str );
			}

		}


		n_string_path_free( multipath );

	}
	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == nonnon_ftp.txtbox.hwnd )
		{

			if ( wparam == WM_LBUTTONDBLCLK )
			{

				n_win_cursor_add( NULL, IDC_WAIT );

				n_posix_char *name = n_nonnon_ftp_name_get( &nonnon_ftp, h_session );

				bool ret1 = false;
				bool ret2 = false;

				if ( n_ftp_session_is_folder( h_session, name ) )
				{

					ret1 = n_ftp_session_folder_set( h_session, name );
					ret2 = n_nonnon_ftp_load( &nonnon_ftp, h_session );

				} else {

					WIN32_FIND_DATA f = n_ftp_session_property( h_session, name );
//n_posix_debug_literal( "%d %d", (int) f.ftLastWriteTime.dwLowDateTime, (int) f.ftLastWriteTime.dwHighDateTime );

					FILETIME t = f.ftLastWriteTime;
					//FileTimeToLocalFileTime( &t, &t );

					SYSTEMTIME s;
					FileTimeToSystemTime( &t, &s );

					n_posix_char date[ 255 ], time[ 255 ];
					GetDateFormat( LOCALE_USER_DEFAULT, DATE_SHORTDATE, &s, NULL, date, 255 );
					GetTimeFormat( LOCALE_USER_DEFAULT,              0, &s, NULL, time, 255 );

					n_posix_char str[ MAX_PATH ];
					n_posix_sprintf_literal( str, "Modify : %s %s", date, time );
					n_project_dialog_info( hwnd, str );

				}

				n_string_path_free( name );

				n_win_cursor_add( NULL, IDC_ARROW );

				if ( ret1 )
				{
					n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_FAILED );
				} else 
				if ( ret2 )
				{
					n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_LOAD   );
				}

			} else
			if ( wparam == WM_MBUTTONDBLCLK )
			{

				n_win_cursor_add( NULL, IDC_WAIT );

				n_posix_char *name = n_nonnon_ftp_name_get( &nonnon_ftp, h_session );
				n_posix_char *desk = n_nonnon_ftp_localname( &nonnon_ftp, name );
//n_posix_debug_literal( " %s ", desk );

				bool ret = n_ftp_session_download( h_session, name, desk );

				n_string_path_free( name );
				n_string_path_free( desk );

				n_win_cursor_add( NULL, IDC_ARROW );

				if ( ret )
				{
					n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_FAILED    );
				} else {
					n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_SUCCEEDED );
				}

			} else
			if ( wparam == WM_RBUTTONDBLCLK )
			{

				n_win_cursor_add( NULL, IDC_WAIT );

				n_posix_char *name = n_nonnon_ftp_name_get( &nonnon_ftp, h_session );

				n_ftp_session_delete( h_session, name );
				bool ret = n_nonnon_ftp_load( &nonnon_ftp, h_session );

				n_string_path_free( name );

				n_win_cursor_add( NULL, IDC_ARROW );

				if ( ret ) { n_project_dialog_info( hwnd, N_NONNON_FTP_ERROR_LOAD ); }

			}

		}

	}
	break;


	case WM_CLOSE :

		n_win_stdfont_exit( &nonnon_ftp.txtbox.hwnd, 1 );
		n_win_txtbox_exit( &nonnon_ftp.txtbox );

		n_ftp_session_exit( h_session );

		n_ftp_exit( h_inet );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &nonnon_ftp.txtbox );

	
	n_win_minsize_proc( hwnd, msg, wparam, lparam, nonnon_ftp.minwsx, nonnon_ftp.minwsy );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef N_APPS_NAME_FTP

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_ftp_wndproc );
}

#endif // #ifndef N_APPS_NAME_FTP


