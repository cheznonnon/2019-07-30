// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_key_operation_path( n_oc_path *p, int vk )
{

	int p_focus = p->focus;


	if ( vk == VK_LEFT )
	{
		if ( p->focus == -1 )
		{
			p->focus = p->count - 1;
		} else {
			p->focus = n_posix_max( 0, p->focus - 1 );
		}
	} else
	if ( vk == VK_RIGHT )
	{
		if ( p->focus == -1 )
		{
			p->focus = p->count - 1;
		} else {
			p->focus = n_posix_min( p->count - 1, p->focus + 1 );
		}
	} else {
		return;
	}


	if ( ( p->focus != -1 )&&( p_focus != p->focus ) )
	{
		n_bmp_fade_go( &p->fade[ p->focus ], oc_color.path_hover );
		n_oc_path_draw( p );
	}


	return;
}

void
n_oc_key_operation_item( n_oc_item *p, int vk )
{

	if ( p->count == 0 ) { return; }


	// [Patch] : when multiple items are selected

	int count = n_oc_item_multifocus_count ( p );
	int focus = n_oc_item_multifocus_single( p );
//n_game_hwndprintf_literal( " Count %d : Curretnt %d ", count, focus );


	int index = focus;


	//p->patch_forced_hover          = -1;
	//p->patch_forced_focus[ index ] = false;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{

		if ( vk == VK_UP )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max( 0, focus - 1 );
			}
		} else
		if ( vk == VK_DOWN )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min( ( p->count - 1 ), focus + 1 );
			}
		} else
		if ( vk == VK_LEFT )
		{
			s32 ipl = p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max( focus % ipl, focus - ipl );
			}
		} else
		if ( vk == VK_RIGHT )
		{
			s32 ipl = p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				if ( ( focus + ipl ) < p->count )
				{
					index += ipl;
				} else
				if ( ( ( focus + ipl ) / ipl * ipl ) < p->count )
				{
					index = p->count - 1;
				}
			}
		} else {
			return;
		}

	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{

		if ( vk == VK_UP )
		{
			s32 ipl = p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max( focus % ipl, focus - ipl );
			}
		} else
		if ( vk == VK_DOWN )
		{
			s32 ipl = p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				if ( ( focus + ipl ) < p->count )
				{
					index += ipl;
				} else
				if ( ( ( focus + ipl ) / ipl * ipl ) < p->count )
				{
					index = p->count - 1;
				}
			}
		} else
		if ( vk == VK_LEFT )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max( 0, focus - 1 );
			}
		} else
		if ( vk == VK_RIGHT )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min( ( p->count - 1 ), focus + 1 );
			}
		} else {
			return;
		}

	} else {

		if ( vk == VK_UP )
		{
//n_game_hwndprintf_literal( " VK_UP " );

			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max( 0, focus - 1 );
			}
		} else
		if ( vk == VK_DOWN )
		{
//n_game_hwndprintf_literal( " VK_DOWN " );

			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min( ( p->count - 1 ), focus + 1 );
			}
		} else {
			return;
		}

	}


	n_oc_item_multifocus_off( p );
	p->multifocus[ index ] = true;

	p->hover_prv = -1;


	bool scroll_onoff = false;
	if (
		( false == n_oc_item_autoscroll_is_edge( p, index, NULL, NULL ) )
		&&
		( false == n_oc_item_autoscroll_is_inner( p, index ) )
	)
	{
		scroll_onoff = true;
	}
//n_game_hwndprintf_literal( " %d ", scroll_onoff );

	if ( scroll_onoff )
	{
		extern void n_oc_item_autoscroll_calculate( n_oc_item*, int, s32*, s32* );
		s32 x,y; n_oc_item_autoscroll_calculate( p, index, &x, &y );
//n_game_hwndprintf_literal( " %d %d ", x, y );

		s32 offset;
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			offset = x * p->cell_sx;
		} else {
			offset = y * p->cell_sy;
		}
//n_game_hwndprintf_literal( " %d %d %d ", y, offset, (int) p->sy );

		if ( offset > (int) p->sy )
		{
			n_win_scrollbar_scroll_unit( &oc.scrollbar,  p->cell_sy, N_WIN_SCROLLBAR_SCROLL_AUTO );
		} else
		if ( offset < (int) p->sy )
		{
			n_win_scrollbar_scroll_unit( &oc.scrollbar, -p->cell_sy, N_WIN_SCROLLBAR_SCROLL_AUTO );
		}

	}


	n_oc_item_autoscroll( p, index, N_OC_ITEM_AUTOSCROLL_DEFAULT );


	return;
}

void
n_oc_key_operation( int vk, bool forced_frame_onoff )
{

	if ( oc.view != N_ORANGECAT_VIEW_FILE ) { return; }


	if ( vk == VK_PRIOR   ) { return; }
	if ( vk == VK_NEXT    ) { return; }

	if ( vk == VK_CONTROL ) { return; }
	if ( vk == VK_SHIFT   ) { return; }

	if ( vk == VK_RETURN  ) { return; }

	if ( vk == VK_DELETE  ) { return; }

	if ( n_win_is_input( VK_CONTROL ) ) { return; }
	if ( n_win_is_input( VK_SHIFT   ) ) { return; }


	if (
		( vk == VK_TAB   )
		||
		( vk == VK_UP    )
		||
		( vk == VK_DOWN  )
		||
		( vk == VK_LEFT  )
		||
		( vk == VK_RIGHT )
	)
	{
		n_oc_key_operation_onoff( true );
		n_memory_zero( item.patch_forced_focus, sizeof( int ) * item.count );
	}


	if ( vk == VK_TAB )
	{

		// [Patch] : init code

		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
		{
			int count = n_oc_item_multifocus_count( &item );

			if ( count == 0 )
			{
				if ( item.count == 0 )
				{
					//
				} else {
					if ( item.multifocus[ 0 ] == false )
					{
						item.multifocus[ 0 ] = true;
					}
					oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;
				}
			}
		}


		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
		{

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;

			path.focus = path.count - 1;
			n_bmp_fade_go( &path.fade[ path.focus ], oc_color.path_hover );
			n_oc_path_draw( &path );

		} else
		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
		{

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

			path.focus = -1;

		} else {

			return;
		}

		n_oc_event_redraw_fast();

	}


//oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
//oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;

	if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
	{
		n_oc_key_operation_item( &item, vk );
	} else
	if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
	{
		n_oc_key_operation_path( &path, vk );
	}


	return;
}

