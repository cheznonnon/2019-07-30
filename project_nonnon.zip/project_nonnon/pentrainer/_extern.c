// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : gcc4 : don't use "extern" for global "static" variables




// pentrainer.c

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_PENTRAINER ( 0 )

#endif // #ifndef NONNON_APPS


#define N_PENTRAINER_APPNAME "Nonnon Pen Trainer"
#define N_PENTRAINER_INISECT N_PENTRAINER_APPNAME


#define N_PENTRAINER_REFRESH_NONE     ( 0 << 0 )
#define N_PENTRAINER_REFRESH_CLIENT   ( 1 << 0 )
#define N_PENTRAINER_REFRESH_WINDOW   ( 1 << 1 )
#define N_PENTRAINER_REFRESH_SCROLL   ( 1 << 2 )
#define N_PENTRAINER_REFRESH_ALL      ( 0xffff )

#define n_pentrainer_refresh_flush( mode ) n_pentrainer_refresh( 0,0, N_BMP_SX( &n_pentrainer_bmp_data ),N_BMP_SY( &n_pentrainer_bmp_data ), mode )
#define n_pentrainer_refresh_all()         n_pentrainer_refresh_flush( N_PENTRAINER_REFRESH_ALL    )
#define n_pentrainer_refresh_client()      n_pentrainer_refresh_flush( N_PENTRAINER_REFRESH_CLIENT )
#define n_pentrainer_refresh_window()      n_pentrainer_refresh_flush( N_PENTRAINER_REFRESH_WINDOW )
#define n_pentrainer_refresh_scroll()      n_pentrainer_refresh_flush( N_PENTRAINER_REFRESH_SCROLL )



// [!] : initialized by n_pentrainer_first() @ pentrainer.c

static HWND    n_pentrainer_hwnd_main;

static int     n_pentrainer_zoom;
static int     n_pentrainer_pensize;
static int     n_pentrainer_mix;
static int     n_pentrainer_edge;

static bool    n_pentrainer_grid_onoff;
static bool    n_pentrainer_pixelgrid_onoff;
static bool    n_pentrainer_frame_onoff;

static s32     n_pentrainer_size;
static u32     n_pentrainer_color_bg;
static u32     n_pentrainer_color_fg;
static u32     n_pentrainer_color_pen;


// [!] : initialized by n_pentrainer_wndproc() @ pentrainer.c

static n_win   nwin_main;

static HBITMAP n_pentrainer_dibsection;
static n_bmp   n_pentrainer_bmp_data;
static n_bmp   n_pentrainer_bmp_over;
static n_bmp   n_pentrainer_bmp_dbuf;


extern void n_pentrainer_canvaspos( s32*, s32* );


// [!] : canvas helper

static s32 n_pentrainer_std_icon_size;

static u32 n_pentrainer_canvas_color = n_bmp_rgb( 128,128,128 );

#define N_PENTRAINER_CANVAS_MARGIN 32

inline void
n_pentrainer_margin_get( s32 *sx, s32 *sy )
{

	double scale  = (double) n_win_dpi( n_pentrainer_hwnd_main ) / 96.0;
	double margin = (double) N_PENTRAINER_CANVAS_MARGIN * scale;

	//if ( n_direct2d_is_on() ) { margin = 0; }

	margin = n_posix_max_double( margin, n_pentrainer_std_icon_size );

	if ( sx != NULL ) { (*sx) = trunc( margin ); }
	if ( sy != NULL ) { (*sy) = trunc( margin ); }


	return;
}


// [!] : zoom in/out support helper

#define N_PENTRAINER_ZOOM_MAX  ( 200 )
#define N_PENTRAINER_ZOOM_ZERO ( N_PENTRAINER_ZOOM_MAX / 2 )

#define n_pentrainer_is_zoom_in(  zoom ) ( zoom > N_PENTRAINER_ZOOM_ZERO )
#define n_pentrainer_is_zoom_out( zoom ) ( zoom < N_PENTRAINER_ZOOM_ZERO )

int
n_pentrainer_zoom_get( int zoom )
{

	if ( n_pentrainer_is_zoom_in( zoom ) )
	{
		return ( zoom - N_PENTRAINER_ZOOM_ZERO );
	} else
	if ( n_pentrainer_is_zoom_out( zoom ) )
	{
		return ( N_PENTRAINER_ZOOM_ZERO - zoom );
	}


	return 0;
}

int
n_pentrainer_zoom_clamp( int prev, int zoom )
{

	if ( prev > N_PENTRAINER_ZOOM_ZERO )
	{
		if ( zoom < ( N_PENTRAINER_ZOOM_ZERO + 1 ) ) { zoom = N_PENTRAINER_ZOOM_ZERO - 2; }
	} else
	if ( prev < N_PENTRAINER_ZOOM_ZERO )
	{
		if ( zoom > ( N_PENTRAINER_ZOOM_ZERO - 2 ) ) { zoom = N_PENTRAINER_ZOOM_ZERO + 1; }
	}


	return zoom;
}

// internal
void
n_pentrainer_zoom_bitmap2canvas( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_pentrainer_zoom_get( n_pentrainer_zoom );


	if ( n_pentrainer_is_zoom_in( n_pentrainer_zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_pentrainer_is_zoom_out( n_pentrainer_zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}

// internal
void
n_pentrainer_zoom_canvas2bitmap( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_pentrainer_zoom_get( n_pentrainer_zoom );


	if ( n_pentrainer_is_zoom_out( n_pentrainer_zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_pentrainer_is_zoom_in( n_pentrainer_zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}


#define N_PENTRAINER_GRID_UNIT ( 10 )




// [!] : Pen Trainer


// [!] : initialized pentrainer_ini.c

static n_posix_char n_pentrainer_char[          10 ];
static n_posix_char n_pentrainer_font[ LF_FACESIZE ];
static n_posix_char n_pentrainer_mode[         100 ];

#ifdef _H_NONNON_WIN32_WIN_WINTAB

static n_wintab     n_pentrainer_wintab;
static bool         n_pentrainer_wintab_onoff = true;//false;

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


extern void n_pentrainer_bitmap( void );
extern void n_pentrainer_ui_draw( void );


bool
n_pentrainer_is_inner_canvas( void )
{

	s32 mx,my; n_pentrainer_margin_get( &mx, &my );
	s32 sx = nwin_main.csx - ( mx * 2 );
	s32 sy = nwin_main.csy - ( my * 2 );

	if ( n_win_is_hovered_offset( n_pentrainer_hwnd_main, mx,my,sx,sy ) )
	{
		return true;
	}


	return false;
}


#define N_PENTRAINER_DIGIT    n_posix_literal( "Digit" )
#define N_PENTRAINER_ROMAN    n_posix_literal( "Roman" )
#define N_PENTRAINER_CYRILLIC n_posix_literal( "Cyrillic" )
#define N_PENTRAINER_GREEK    n_posix_literal( "Greek" )
#define N_PENTRAINER_HIRAGANA n_posix_literal( "Hiragana" )
#define N_PENTRAINER_KATAKANA n_posix_literal( "Katakana" )

// internal
void
n_pentrainer_mode_init( void )
{

	if (  932 == GetACP() ) { n_posix_sprintf_literal( n_pentrainer_mode, "%s", N_PENTRAINER_HIRAGANA ); } else
	if ( 1251 == GetACP() ) { n_posix_sprintf_literal( n_pentrainer_mode, "%s", N_PENTRAINER_CYRILLIC ); } else
	if ( 1253 == GetACP() ) { n_posix_sprintf_literal( n_pentrainer_mode, "%s", N_PENTRAINER_GREEK    ); } else
	                        { n_posix_sprintf_literal( n_pentrainer_mode, "%s", N_PENTRAINER_ROMAN    ); }

//n_posix_sprintf_literal( n_pentrainer_mode, "%s", N_PENTRAINER_GREEK );
	return;
}

#define n_pentrainer_character_min( mode, ret ) n_pentrainer_character_minmax(  true, mode, ret )
#define n_pentrainer_character_max( mode, ret ) n_pentrainer_character_minmax( false, mode, ret )

// internal
void
n_pentrainer_character_minmax( bool is_min, const n_posix_char *mode, n_posix_char *ret )
{

#ifdef UNICODE

	ret[ 1 ] = 0;

	if ( n_string_is_same( mode, N_PENTRAINER_DIGIT ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x0030; } else { ret[ 0 ] = 0x0039; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_ROMAN ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x0041; } else { ret[ 0 ] = 0x007a; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_HIRAGANA ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x3041; } else { ret[ 0 ] = 0x3093; }
	} else
	if ( n_string_is_same( mode, N_PENTRAINER_KATAKANA ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x30a1; } else { ret[ 0 ] = 0x30f3; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_CYRILLIC ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x0410; } else { ret[ 0 ] = 0x044f; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_GREEK ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x0391; } else { ret[ 0 ] = 0x03c9; }
	}// else

#else  // #ifdef UNICODE

	ret[ 1 ] = 0;
	ret[ 2 ] = 0;

	if ( n_string_is_same( mode, N_PENTRAINER_DIGIT ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x30; } else { ret[ 0 ] = 0x39; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_ROMAN ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x41; } else { ret[ 0 ] = 0x7a; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_HIRAGANA ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x82; ret[ 1 ] = 0x9f; } else { ret[ 0 ] = 0x82; ret[ 1 ] = 0xf1; }
	} else
	if ( n_string_is_same( mode, N_PENTRAINER_KATAKANA ) )
	{
		if ( is_min ) { ret[ 0 ] = 0x83; ret[ 1 ] = 0x40; } else { ret[ 0 ] = 0x83; ret[ 1 ] = 0x93; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_CYRILLIC ) )
	{
		if ( is_min ) { ret[ 0 ] = 0xc0; } else { ret[ 0 ] = 0xff; }
	} else

	if ( n_string_is_same( mode, N_PENTRAINER_GREEK ) )
	{
		if ( is_min ) { ret[ 0 ] = 0xc1; } else { ret[ 0 ] = 0xf9; }
	}// else

#endif // #ifdef UNICODE


	return;
}

static int n_pentrainer_character_move_index = 0;

int n_pentrainer_character_move_kana[] = {

	 1, // "a"
	 3, // "i"
	 5, // "u"
	 7, // "e"
	 9, // "o"

	10, // "ka"
	12, // "ki"
	14, // "ku"
	16, // "ke"
	18, // "ko"

	20, // "sa"
	22, // "si"
	24, // "su"
	26, // "se"
	28, // "so"

	30, // "ta"
	32, // "ti"
	35, // "tu"
	37, // "te"
	39, // "to"

	41, // "na"
	42, // "ni"
	43, // "nu"
	44, // "ne"
	45, // "no"

	46, // "ha"
	49, // "hi"
	52, // "hu"
	55, // "he"
	58, // "ho"

	61, // "ma"
	62, // "mi"
	63, // "mu"
	64, // "me"
	65, // "mo"

	67, // "ya"
	69, // "yu"
	71, // "yo"

	72, // "ra"
	73, // "ri"
	74, // "ru"
	75, // "re"
	76, // "ro"

	78, // "wa"
	79, // "wi"
	80, // "we"
	81, // "wo"

	82, // "n"

};

int n_pentrainer_character_move_greek[] = {

	// [!] : min + offset

	 0, // ALPHA
	32, // alpha
	 1, // BETA
	33, // beta
	 2, // GAMMA
	34, // gamma
	 3, // DELTA
	35, // delta
	 4, // EPSILON
	36, // epsilon
	 5, // ZETA
	37, // zeta
	 6, // ETA
	38, // eta
	 7, // THETA
	39, // theta
	 8, // IOTA
	40, // iota
	 9, // KAPPA
	41, // kappa
	10, // LAMBDA
	42, // lambda
	11, // MU
	43, // mu
	12, // NU
	44, // nu
	13, // XI
	45, // xi
	14, // OMICRON
	46, // omicron
	15, // PI
	47, // pi
	16, // RHO
	48, // rho
	18, // SIGMA
	50, // sigma
	49, // sigma terminal form
	19, // TAU
	51, // tau
	20, // YPSILON
	52, // ypsilon
	21, // PHI
	53, // phi
	22, // CHI
	54, // chi
	23, // PSI
	55, // psi
	24, // OMEGA
	56, // omega

};

// internal
void
n_pentrainer_character_move( int delta )
{

	n_posix_char char_min[ 10 ]; n_pentrainer_character_min( n_pentrainer_mode, char_min );
	n_posix_char char_max[ 10 ]; n_pentrainer_character_max( n_pentrainer_mode, char_max );


	// [!] : for ANSI DBCS

	int index = 0;
	if ( char_min[ 1 ] != 0 ) { index = 1; }


	if ( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_DIGIT ) )
	{

		if ( delta < 0 )
		{
			n_pentrainer_char[ index ]--;
			if ( n_pentrainer_char[ index ] < char_min[ index ] )
			{
				n_pentrainer_char[ index ] = char_max[ index ];
			}
			n_pentrainer_bitmap();
		} else
		if ( delta > 0 )
		{
			n_pentrainer_char[ index ]++;
			if ( n_pentrainer_char[ index ] > char_max[ index ] )
			{
				n_pentrainer_char[ index ] = char_min[ index ];
			}
			n_pentrainer_bitmap();
		}

	} else

	if (
		( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_HIRAGANA ) )
		||
		( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_KATAKANA ) )
	)
	{

		if ( delta < 0 )
		{
			n_pentrainer_character_move_index--;
			if ( n_pentrainer_character_move_index < 0 )
			{
				n_pentrainer_character_move_index = 47;
			}
			n_pentrainer_char[ index ] = char_min[ index ] + n_pentrainer_character_move_kana[ n_pentrainer_character_move_index ];

			n_pentrainer_bitmap();
		} else
		if ( delta > 0 )
		{
			n_pentrainer_character_move_index++;
			if ( n_pentrainer_character_move_index >= 48 )
			{
				n_pentrainer_character_move_index = 0;
			}
			n_pentrainer_char[ index ] = char_min[ index ] + n_pentrainer_character_move_kana[ n_pentrainer_character_move_index ];

			n_pentrainer_bitmap();
		} else {
			n_pentrainer_character_move_index = 0;
			n_pentrainer_char[ index ] = char_min[ index ] + n_pentrainer_character_move_kana[ 0 ];
		}

	} else

	if ( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_ROMAN ) )
	{

		static bool is_captal = true;
		if ( n_pentrainer_char[ index ] == char_min[ index ] ) { is_captal = true; }

		if ( delta < 0 )
		{
			if ( is_captal )
			{
				is_captal = false;
				n_pentrainer_char[ index ] += 31;
			} else {
				is_captal = true;
				n_pentrainer_char[ index ] -= 32;
			}

			if ( n_pentrainer_char[ index ] == n_posix_literal( '`' ) )
			{
				n_pentrainer_char[ index ] = char_max[ index ];
			}

			n_pentrainer_bitmap();
		} else
		if ( delta > 0 )
		{
			if ( is_captal )
			{
				is_captal = false;
				n_pentrainer_char[ index ] += 32;
			} else {
				is_captal = true;
				n_pentrainer_char[ index ] -= 31;
			}

			if ( n_pentrainer_char[ index ] == n_posix_literal( '[' ) )
			{
				n_pentrainer_char[ index ] = char_min[ index ];
			}

			n_pentrainer_bitmap();
		}

	} else

	if ( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_CYRILLIC ) )
	{

		static bool is_captal = true;
		if ( n_pentrainer_char[ index ] == char_min[ index ] ) { is_captal = true; }

		if ( delta < 0 )
		{
			if ( is_captal )
			{
				is_captal = false;
				if ( n_pentrainer_char[ index ] == char_min[ index ] )
				{
					n_pentrainer_char[ index ] += 32;
				}
				n_pentrainer_char[ index ] += 31;
			} else {
				is_captal = true;
				n_pentrainer_char[ index ] -= 32;
			}

			n_pentrainer_bitmap();
		} else
		if ( delta > 0 )
		{
			if ( is_captal )
			{
				is_captal = false;
				n_pentrainer_char[ index ] += 32;
			} else {
				is_captal = true;
				if ( n_pentrainer_char[ index ] == char_max[ index ] )
				{
					n_pentrainer_char[ index ] -= 32;
				}
				n_pentrainer_char[ index ] -= 31;
			}

			n_pentrainer_bitmap();
		}

	} else

	if ( n_string_is_same( n_pentrainer_mode, N_PENTRAINER_GREEK ) )
	{

		if ( delta < 0 )
		{
			n_pentrainer_character_move_index--;
			if ( n_pentrainer_character_move_index < 0 )
			{
				n_pentrainer_character_move_index = 48;
			}
			n_pentrainer_char[ index ] = char_min[ index ] + n_pentrainer_character_move_greek[ n_pentrainer_character_move_index ];

			n_pentrainer_bitmap();
		} else
		if ( delta > 0 )
		{
			n_pentrainer_character_move_index++;
			if ( n_pentrainer_character_move_index >= 49 )
			{
				n_pentrainer_character_move_index = 0;
			}
			n_pentrainer_char[ index ] = char_min[ index ] + n_pentrainer_character_move_greek[ n_pentrainer_character_move_index ];

			n_pentrainer_bitmap();
		} else {
			n_pentrainer_character_move_index = 0;
		}

	}// else


	return;
}


