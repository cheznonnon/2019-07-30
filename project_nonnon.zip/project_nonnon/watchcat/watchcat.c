// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/com/IShellLink.c"

#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/sysinfo.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_iconbutton.c"
#include "../nonnon/win32/win_progressbar.c"
#include "../nonnon/win32/win_sizegrip.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




#include "./n_registry_startupcleaner.c"




// Watchcat

#define H_PROCLIST       watchcat.hgui[  0 ]
#define H_STATIC_CPU     watchcat.hgui[  1 ]
#define H_STATIC_MEM     watchcat.hgui[  2 ]
#define H_BTN_TOP        watchcat.hgui[  3 ]
#define H_BTN_NEKO       watchcat.hgui[  4 ]
#define H_BTN_INFO_1     watchcat.hgui[  5 ]
#define H_BTN_INFO_2     watchcat.hgui[  6 ]
#define H_SIZEGRIP_MAIN  watchcat.hgui[  7 ]
#define H_SIZEGRIP_DARK  watchcat.hgui[  8 ]
#define GUI_MAX                          9




#define N_WATCHCAT_APPNAME    n_posix_literal( "Watchcat" )
#define N_WATCHCAT_ICONNAME   n_posix_literal( "WATCHCAT_0_MAIN" )

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_WATCHCAT ( 0 )

#endif // #ifndef NONNON_APPS


#define N_WATCHCAT_TIMER_MSEC ( 1000 )



typedef struct {

	HWND                  hwnd;
	HWND                  hgui[ GUI_MAX ];
	n_win_txtbox          txtbox;

	n_win                 nwin;
	s32                   minwsx,minwsy;

	int                   cpu, mem;

	n_sysinfo_processlist proclist;

	bool                  topmost;
	bool                  watchcat;
	bool                  info_1;
	bool                  info_2;

	int                   icon_offset;

	UINT                  timer_id;

} n_watchcat;

#define n_watchcat_zero( p ) n_memory_zero( p, sizeof( n_watchcat ) )


static n_watchcat watchcat;




#include "./watchcat_sysmenu.c"





void
n_project_font_monospace( HWND hgui )
{

	HDC hdc = GetDC( hgui );

	LOGFONT lf_f; n_memory_zero( &lf_f, sizeof( LOGFONT ) ); 
	LOGFONT lf_t = n_win_font_hfont2logfont( n_win_stdfont_hfont() );

	// [x] : Win9x : "MS Gothic" is not available : a localized name is needed

	n_posix_char *fontname = n_gdi_font_find
	(
		n_posix_literal( "Consolas" ),
#ifdef UNICODE
		n_posix_literal( "\xff2d\xff33\x0020\x30b4\x30b7\x30c3\x30af" )           // Unicode LE
#else
		n_posix_literal( "\x82\x6c\x82\x72\x20\x83\x53\x83\x56\x83\x62\x83\x4e" ) // Shift-JIS
#endif
		n_posix_literal( "Courier New" ),
		n_posix_literal( "Courier" )
	);
	n_posix_sprintf_literal( lf_f.lfFaceName, "%s", fontname );
	bool ret = EnumFonts( hdc, NULL, n_gdi_font_enumfontsproc, (LPARAM) &lf_f );
//n_posix_debug_literal( "%d : %s", ret, lf_f.lfFaceName );
	ReleaseDC( hgui, hdc );

	if ( ret )
	{
		n_win_stdfont_init( &hgui, 1 );
	} else {
		n_posix_sprintf_literal( lf_t.lfFaceName, "%s", fontname );
		n_win_font_set( hgui, n_win_font_logfont2hfont( &lf_t ), true );
	}


	return;
}

void
n_watchcat_proclist_refresh( n_watchcat *p )
{
//return;

	n_sysinfo_processlist_make( &p->proclist );

	n_posix_char *str = n_win_txtbox_selection_new( &p->txtbox );

	s32 scr_y = 0; n_win_txtbox_scroll_get( &p->txtbox, NULL, &scr_y );

	n_win_txtbox_reset( &p->txtbox );

	size_t i = 0;
	while( 1 )
	{//break;

		size_t        str_cch = n_sysinfo_processlist_format_cch( &p->proclist, i );
		n_posix_char *str_fmt = n_string_new( str_cch ); n_sysinfo_processlist_format( &p->proclist, i, str_fmt );

		n_win_txtbox_line_set( &p->txtbox, i, str_fmt );

		n_string_free( str_fmt );

		i++;
		if ( i >= p->proclist.exe.sy ) { break; }
	}

	n_txt_sort_up( &p->txtbox.txt );


	int index = n_win_txtbox_str2index( &p->txtbox, str, false );
//n_win_hwndprintf_literal( p->hwnd, "%s : %d", str, index );

	n_string_path_free( str );


	n_win_txtbox_line_select( &p->txtbox, index );
	n_win_txtbox_scroll     ( &p->txtbox, 0, scr_y );

	n_win_scrollbar_refresh( &p->txtbox.vscr );


	n_win_txtbox_refresh( &p->txtbox );

//n_win_hwndprintf_literal( p->hwnd, " %d %f ", p->proclist.exe.sy, p->txtbox.vscr.rect_thumb.sy );
	return;
}

// internal
void
n_watchcat_cpumem_refresh( n_watchcat *p )
{

	static int p_cpu = -1;
	static int p_mem = -1;

	DWORD mem_total, mem_used;


	p->cpu = n_sysinfo_cpu_ratio();
	p->mem = n_sysinfo_memory( &mem_total, &mem_used, NULL );


	if ( p_cpu != p->cpu )
	{

		n_win_hwndprintf_literal( H_STATIC_CPU, "CPU %3d%%", p->cpu );

		p_cpu = p->cpu;
		n_win_message_send( H_STATIC_CPU, WM_PAINT, 0,0 );

	}

	if ( p_mem != p->mem )
	{

		n_win_hwndprintf_literal( H_STATIC_MEM, "MEM %3d%%", p->mem );

		p_mem = p->mem;
		n_win_message_send( H_STATIC_MEM, WM_PAINT, 0,0 );

	}


	return;
}

// internal
void
n_watchcat_resize( n_watchcat *p )
{

	const bool redraw = true;


	s32 ctl,ico,m; n_win_stdsize( p->hwnd, &ctl, &ico, &m );


	static bool is_first = true;

	int nwset = N_WIN_SET_DEFAULT;
	s32 csx   = -1;
	s32 csy   = -1;

	if ( is_first )
	{

		is_first = false;

		nwset = N_WIN_SET_CENTERING;

		csy  = m + ( ctl + ( ctl * 7 ) + ico );
		csx  = m + ( (double) csy * sqrt( 2 ) );

		p->minwsx = csx;
		p->minwsy = ctl;

#ifdef _MSC_VER

		s32 scale = ( n_win_dpi( p->hwnd ) / 96 ) - 1;

		if ( scale != 0 )
		{
			p->minwsy += ( 8 * scale ) + 2;
		} else {
			p->minwsy += m - 1;
		}

#else  // #ifdef _MSC_VER

		p->minwsy += m - 1;

#endif // #ifdef _MSC_VER

		n_win_minsize_proc_patch( p->hwnd, &csx, &csy );

	} else {

		nwset = n_project_n_win_set();

	}

	n_win_set( p->hwnd, &p->nwin, csx,csy, nwset );

	csx = p->nwin.csx - m;
	csy = p->nwin.csy - m;


	if ( p->nwin.csy < ( ctl + ctl + ico ) )
	{
		ShowWindow( H_PROCLIST, SW_HIDE   );
	} else {
		ShowWindow( H_PROCLIST, SW_NORMAL );
	}


	if ( p->nwin.state == SIZE_MAXIMIZED )
	{
		ShowWindow( H_SIZEGRIP_MAIN, SW_HIDE   );
		ShowWindow( H_SIZEGRIP_DARK, SW_HIDE   );
	} else {
		ShowWindow( H_SIZEGRIP_MAIN, SW_NORMAL );
		ShowWindow( H_SIZEGRIP_DARK, SW_NORMAL );
	}


	s32 grip  = n_win_sizegrip_stdsize();
	s32 list  = csy - ( ctl + n_posix_max_s32( ico, grip ) );
	s32 half  = csx / 2;
	s32 gripx = p->nwin.csx - grip;
	s32 gripy = p->nwin.csy - grip;

	if ( p->nwin.csy < ( ctl + ico  ) ) { ico  = 0; }
	if ( p->nwin.csy < ( ctl + grip ) ) { grip = 0; }

	n_win_move       ( H_STATIC_CPU,          0,       0, half,  ctl, redraw );
	n_win_move       ( H_STATIC_MEM,       half,       0, half,  ctl, redraw );
	n_win_move       ( H_PROCLIST,            0,     ctl,  csx, list, redraw );
	n_win_move       ( H_BTN_TOP,         0*ico, csy-ico,  ico,  ico, redraw );
	n_win_move       ( H_BTN_NEKO,        1*ico, csy-ico,  ico,  ico, redraw );
	n_win_move       ( H_BTN_INFO_1,      2*ico, csy-ico,  ico,  ico, redraw );
	n_win_move       ( H_BTN_INFO_2,      3*ico, csy-ico,  ico,  ico, redraw );
	n_win_move_simple( H_SIZEGRIP_MAIN, gripx+1,   gripy, grip, grip, redraw );
	n_win_move_simple( H_SIZEGRIP_DARK, gripx  ,   gripy, grip, grip, redraw );

	n_win_txtbox_refresh( &p->txtbox );


	return;
}

// internal
void
n_watchcat_terminate( n_watchcat *p )
{

	n_posix_char *str = n_win_txtbox_selection_new( &p->txtbox );
	DWORD         pid = n_posix_atoi( str );
	n_string_path_free( str );


	if ( watchcat.watchcat )
	{

		HANDLE hproc = OpenProcess( PROCESS_TERMINATE, false, pid );

		TerminateProcess( hproc, pid );

		CloseHandle( hproc );

	} else {

		HWND h = n_sysinfo_processlist_pid2hwnd( &p->proclist, pid );

		if ( h != NULL )
		{
			n_win_message_post( h, WM_CLOSE, 0,0 );
		}

	}


	return;
}

// internal
void
n_watchcat_info_refresh( n_watchcat *p )
{

	static int p_mode = 0;
	static int   mode = 0;


	bool proclist_onoff = ( ( p->info_1 | p->info_2 ) == false );

	if ( proclist_onoff )
	{

		mode = 0;

		watchcat.txtbox.style &= ~N_WIN_TXTBOX_STYLE_EDITBOX;
		watchcat.txtbox.style |=  N_WIN_TXTBOX_STYLE_LISTBOX;

		n_watchcat_proclist_refresh( p );

	} else
	if ( p->info_1 )
	{

		mode = 1;

		n_posix_char *str = n_string_new( N_SYSINFO_CCH );

		if ( n_sysinfo_window( p->hwnd, str ) )
		{
			watchcat.txtbox.style &= ~N_WIN_TXTBOX_STYLE_LISTBOX;
			watchcat.txtbox.style |=  N_WIN_TXTBOX_STYLE_EDITBOX;

			n_win_txtbox_reset( &p->txtbox );
			n_win_txtbox_txt_load_onmemory( &p->txtbox, str, n_string_cch2cb( str, n_posix_strlen( str ) ) );
			n_win_txtbox_refresh( &p->txtbox );
		}

	} else
	if ( p->info_2 )
	{

		mode = 1;

		n_posix_char *str = n_string_new( N_SYSINFO_CCH );

		if ( n_sysinfo_class( p->hwnd, str ) )
		{
			watchcat.txtbox.style &= ~N_WIN_TXTBOX_STYLE_LISTBOX;
			watchcat.txtbox.style |=  N_WIN_TXTBOX_STYLE_EDITBOX;

			n_win_txtbox_reset( &p->txtbox );
			n_win_txtbox_txt_load_onmemory( &p->txtbox, str, n_string_cch2cb( str, n_posix_strlen( str ) ) );
			n_win_txtbox_refresh( &p->txtbox );
		}

	}// else

	if ( p_mode != mode )
	{
		if ( mode == 0 )
		{
			n_win_stdfont_exit( &watchcat.txtbox.hwnd, 1 );
			n_win_stdfont_init( &watchcat.txtbox.hwnd, 1 );
		} else {
			n_win_stdfont_exit( &watchcat.txtbox.hwnd, 1 );
			n_project_font_monospace( H_PROCLIST );
		}
	}

	p_mode = mode;


	return;
}

void
n_watchcat_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, 500 );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, true );

		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_TOP    );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_NEKO   );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_INFO_1 );
		n_win_iconbutton_on_settingchange( hwnd, msg, wparam, lparam, H_BTN_INFO_2 );

		n_win_stdfont_init( watchcat.hgui, GUI_MAX );

		n_win_txtbox_on_settingchange( &watchcat.txtbox );

		n_watchcat_resize( &watchcat );

	break;


	} // switch


}

LRESULT CALLBACK
n_watchcat_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static bool is_wm_close = false;


	n_watchcat_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Instance

		n_win_exedir2curdir();

		n_project_darkmode();
		//n_win_darkmode_onoff = true;

		n_watchcat_zero( &watchcat );

		watchcat.hwnd = hwnd;


		// Window

		n_win_init( hwnd, N_WATCHCAT_APPNAME, N_WATCHCAT_ICONNAME, N_STRING_EMPTY );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_STATIC_CPU    );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_STATIC_MEM    );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_TOP       );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_NEKO      );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_INFO_1    );
		n_win_gui_literal( hwnd, FICOBTN, "", &H_BTN_INFO_2    );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_SIZEGRIP_DARK );
		n_win_gui_literal( hwnd, VSCROLL, "", &H_SIZEGRIP_MAIN );

		{

			n_posix_char *exe = n_win_exepath_new();

			n_win_icon_add( H_BTN_TOP,    exe, N_APPS_ICON_OFFSET_WATCHCAT + 4 );
			n_win_icon_add( H_BTN_NEKO,   exe, N_APPS_ICON_OFFSET_WATCHCAT + 3 );
			n_win_icon_add( H_BTN_INFO_1, exe, N_APPS_ICON_OFFSET_WATCHCAT + 1 );
			n_win_icon_add( H_BTN_INFO_2, exe, N_APPS_ICON_OFFSET_WATCHCAT + 2 );

			n_string_path_free( exe );

		}

		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			n_win_txtbox_zero( &watchcat.txtbox );
			n_win_txtbox_init( &watchcat.txtbox, hwnd, style, N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM );

			H_PROCLIST = watchcat.txtbox.hwnd;
//watchcat.txtbox.vscr.style = N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT;//VISUALSTYLE;
		}


		// Style

		n_project_window_resizable( hwnd );

		n_win_style_add( H_SIZEGRIP_MAIN, SBS_SIZEGRIP );

		n_win_iconbutton_init( hwnd, H_BTN_TOP    );
		n_win_iconbutton_init( hwnd, H_BTN_NEKO   );
		n_win_iconbutton_init( hwnd, H_BTN_INFO_1 );
		n_win_iconbutton_init( hwnd, H_BTN_INFO_2 );


		// Size

		n_win_stdfont_init( watchcat.hgui, GUI_MAX );

		n_watchcat_resize( &watchcat );


		// Watchcat

		n_sysinfo_sysmon_init();

		n_watchcat_info_refresh( &watchcat );
		n_watchcat_cpumem_refresh( &watchcat );

		if ( watchcat.timer_id == 0 ) { watchcat.timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, watchcat.timer_id, N_WATCHCAT_TIMER_MSEC );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;

/*
	case WM_ERASEBKGND :
	{

		HDC hdc = (HDC) wparam;

		RECT r; GetClientRect( hwnd, &r );
		if ( n_win_darkmode_onoff )
		{

			int i = 0;
			while( 1 )
			{
				n_win_on_erasebkgnd( watchcat.hgui[ i ], hdc );

				i++;
				if ( i >= GUI_MAX ) { break; }
			}

			n_win_box  ( hwnd, hdc, &r, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );

		} else {

			n_win_on_erasebkgnd( H_PROCLIST, hdc );

			n_win_clear( hwnd, hdc, &r, COLOR_BTNFACE );

		}

		return TRUE;

	}
	break;
*/


	case WM_SIZE :

		n_watchcat_resize( &watchcat );

	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_PROCLIST )
		{

			if ( wparam == WM_LBUTTONDBLCLK )
			{
				n_watchcat_terminate( &watchcat );
				n_watchcat_info_refresh( &watchcat );
			}

		} else

		if ( h == H_BTN_TOP )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 4;

			watchcat.topmost = n_win_iconbutton_checklike( h, f, f, watchcat.topmost );

			n_win_topmost( hwnd, watchcat.topmost );

		} else

		if ( h == H_BTN_NEKO )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 3;
			int t = N_APPS_ICON_OFFSET_WATCHCAT + 0;

			watchcat.watchcat = n_win_iconbutton_checklike( h, f, t, watchcat.watchcat );

		} else

		if ( h == H_BTN_INFO_1 )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 1;

			watchcat.info_1 = n_win_iconbutton_checklike( h, f, f, watchcat.info_1 );

			n_watchcat_info_refresh( &watchcat );

			if ( watchcat.info_1 )
			{
				EnableWindow( H_BTN_INFO_2, false );
			} else {
				EnableWindow( H_BTN_INFO_2,  true );
			}

			n_watchcat_resize( &watchcat );

		} else

		if ( h == H_BTN_INFO_2 )
		{

			int f = N_APPS_ICON_OFFSET_WATCHCAT + 2;

			watchcat.info_2 = n_win_iconbutton_checklike( h, f, f, watchcat.info_2 );

			n_watchcat_info_refresh( &watchcat );

			if ( watchcat.info_2 )
			{
				EnableWindow( H_BTN_INFO_1, false );
			} else {
				EnableWindow( H_BTN_INFO_1,  true );
			}

			n_watchcat_resize( &watchcat );

		}// else

	}
	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam != watchcat.timer_id ) { break; }


		n_watchcat_cpumem_refresh( &watchcat );
		n_watchcat_info_refresh( &watchcat );

	break;


	case WM_CLOSE :

		n_win_timer_exit( hwnd, watchcat.timer_id );


		n_sysinfo_processlist_exit( &watchcat.proclist );


		n_sysinfo_sysmon_exit();


		n_win_txtbox_exit( &watchcat.txtbox );


		n_win_iconbutton_exit( hwnd, H_BTN_TOP    );
		n_win_iconbutton_exit( hwnd, H_BTN_NEKO   );
		n_win_iconbutton_exit( hwnd, H_BTN_INFO_1 );
		n_win_iconbutton_exit( hwnd, H_BTN_INFO_2 );


		is_wm_close = true;
		n_win_stdfont_exit( watchcat.hgui, GUI_MAX );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch()


	n_win_minsize_proc( hwnd, msg, wparam, lparam, watchcat.minwsx, watchcat.minwsy );


	if ( is_wm_close == false )
	{

		n_win_txtbox_proc( hwnd, msg, wparam, lparam, &watchcat.txtbox );

		COLORREF bar_fg = n_win_darkmode_systemcolor( COLOR_HIGHLIGHT );
		COLORREF bar_bg = n_win_darkmode_systemcolor( COLOR_BTNFACE   );

		n_win_progressbar_proc( hwnd, msg, wparam, lparam, H_STATIC_CPU, EDGE_ETCHED, watchcat.cpu, bar_fg, bar_bg );
		n_win_progressbar_proc( hwnd, msg, wparam, lparam, H_STATIC_MEM, EDGE_ETCHED, watchcat.mem, bar_fg, bar_bg );

	}

	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_TOP    );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_NEKO   );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_INFO_1 );
	n_win_iconbutton_proc( hwnd, msg, wparam, lparam, H_BTN_INFO_2 );


	n_win_sizegrip_proc( hwnd, msg, wparam, lparam, H_SIZEGRIP_DARK );


	n_watchcat_sysmenu_proc( hwnd, msg, wparam, lparam );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( N_WATCHCAT_APPNAME, n_watchcat_wndproc );
}

#endif // #ifndef NONNON_APPS




#undef H_PROCLIST
#undef H_STATIC_CPU
#undef H_STATIC_MEM
#undef H_BTN_TOP
#undef H_BTN_NEKO
#undef H_BTN_INFO_1
#undef H_BTN_INFO_2
#undef H_SIZEGRIP_MAIN
#undef H_SIZEGRIP_DARK
#undef GUI_MAX


