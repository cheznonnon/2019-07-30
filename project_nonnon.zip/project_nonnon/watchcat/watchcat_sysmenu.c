// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/registry.c"

#include "../nonnon/win32/win_menu.c"




void
n_watchcat_fullcoloricon_set( void )
{

	// [Mechanism] : when this value is not exist
	//
	//	Win95    : 16 colors
	//	WinNT4.0 : 16 colors
	//	WinVista : always full color
	//
	//	"16"     : full color
	//	"4"      : index color


	if ( n_sysinfo_version_vista_or_later() ) { return; }


	n_posix_char *subkey  = n_posix_literal( "Control Panel\\Desktop\\WindowMetrics" );
	n_posix_char *section = n_posix_literal( "Shell Icon BPP" );


	n_posix_char str[ 100 ]; n_string_zero( str, 100 );


	n_registry_read( HKEY_CURRENT_USER, subkey, section, str, 100 * sizeof( n_posix_char ) );

	if ( 16 == n_posix_atoi( str ) ) { return; }


	n_string_copy_literal( "16", str );

	n_registry_write( HKEY_CURRENT_USER, subkey, section, REG_SZ, str, 0 );


	return;
}

#define N_WC_SYSMENU_STARTUP_CLEANER 0
#define N_WC_SYSMENU_FULLCOLOR_ICON  1
#define N_WC_SYSMENU_LINE_1          2

void
n_watchcat_sysmenu_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int menu_start = 0;

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Startup Cleaner" ) },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Full Color Icons"  ) },
		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---" ) },

		{ N_WIN_MENU_NONE,  false, false, NULL }

	};


	int ret = n_win_menu_system_proc( hwnd, msg, wparam, lparam, menu, menu_start );


	switch( ret ) {


	case N_WC_SYSMENU_STARTUP_CLEANER :

		n_registry_startupcleaner();
		n_explorer_refresh( false );

		n_win_exec_literal( "explorer.exe startup", SW_NORMAL );

	break;

	case N_WC_SYSMENU_FULLCOLOR_ICON :

		n_watchcat_fullcoloricon_set();

	break;

	case N_WC_SYSMENU_LINE_1 :

		// Line

	break;


	} // switch


	return;
}

